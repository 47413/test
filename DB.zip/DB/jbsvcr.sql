﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:50:45
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbsvcr`;

#
# Structure for table "agenda"
#

DROP TABLE IF EXISTS `jbsvcr`.`agenda`;
CREATE TABLE `jbsvcr`.`agenda` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tanggal` date NOT NULL,
  `judul` varchar(255) NOT NULL,
  `komentar` text NOT NULL,
  `idguru` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_agenda_ts` (`ts`,`issync`),
  KEY `FK_agenda_pegawai` (`idguru`),
  CONSTRAINT `FK_agenda_pegawai` FOREIGN KEY (`idguru`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "agenda"
#


#
# Structure for table "angket"
#

DROP TABLE IF EXISTS `jbsvcr`.`angket`;
CREATE TABLE `jbsvcr`.`angket` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL DEFAULT '',
  `tglmulai` date NOT NULL DEFAULT '0000-00-00',
  `tglakhir` date NOT NULL DEFAULT '0000-00-00',
  `jenis` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_angket_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "angket"
#


#
# Structure for table "beritaguru"
#

DROP TABLE IF EXISTS `jbsvcr`.`beritaguru`;
CREATE TABLE `jbsvcr`.`beritaguru` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(255) NOT NULL,
  `tanggal` datetime NOT NULL,
  `abstrak` text NOT NULL,
  `isi` text NOT NULL,
  `idguru` varchar(30) CHARACTER SET utf8 NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_beritaguru_ts` (`ts`,`issync`),
  KEY `FK_beritaguru_pegawai` (`idguru`),
  CONSTRAINT `FK_beritaguru_pegawai` FOREIGN KEY (`idguru`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "beritaguru"
#


#
# Structure for table "beritasekolah"
#

DROP TABLE IF EXISTS `jbsvcr`.`beritasekolah`;
CREATE TABLE `jbsvcr`.`beritasekolah` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(255) NOT NULL,
  `tanggal` datetime NOT NULL,
  `jenisberita` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `abstrak` text NOT NULL,
  `isi` text NOT NULL,
  `idpengirim` varchar(30) CHARACTER SET utf8 NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_beritasekolah_ts` (`ts`,`issync`),
  KEY `FK_beritasekolah_pegawai` (`idpengirim`),
  CONSTRAINT `FK_beritasekolah_pegawai` FOREIGN KEY (`idpengirim`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "beritasekolah"
#


#
# Structure for table "beritasiswa"
#

DROP TABLE IF EXISTS `jbsvcr`.`beritasiswa`;
CREATE TABLE `jbsvcr`.`beritasiswa` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(255) NOT NULL,
  `tanggal` datetime NOT NULL,
  `abstrak` text NOT NULL,
  `isi` text NOT NULL,
  `idpengirim` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idguru` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_beritasiswa_ts` (`ts`,`issync`),
  KEY `FK_beritasiswa_siswa` (`idpengirim`),
  KEY `FK_beritasiswa_pegawai` (`idguru`),
  CONSTRAINT `FK_beritasiswa_pegawai` FOREIGN KEY (`idguru`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_beritasiswa_siswa` FOREIGN KEY (`idpengirim`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "beritasiswa"
#


#
# Structure for table "buletin"
#

DROP TABLE IF EXISTS `jbsvcr`.`buletin`;
CREATE TABLE `jbsvcr`.`buletin` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tempatbuletin` varchar(50) NOT NULL,
  `tanggalbuletin` date NOT NULL,
  `judul` varchar(255) NOT NULL,
  `buletin` text NOT NULL,
  `idpengirim` varchar(20) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `gambar` mediumblob,
  `tanggalinput` datetime DEFAULT NULL,
  `idkategori` int(10) unsigned DEFAULT '0',
  `tampil` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '''0 Null, 1 Situs, 2 Jibas, 3 Situs&Jibas''',
  `clientid` varchar(5) DEFAULT NULL,
  `region` varchar(5) DEFAULT NULL,
  `location` varchar(5) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_buletin_1` (`idkategori`),
  KEY `IX_buletin_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "buletin"
#


#
# Structure for table "buletin_cmt"
#

DROP TABLE IF EXISTS `jbsvcr`.`buletin_cmt`;
CREATE TABLE `jbsvcr`.`buletin_cmt` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idbuletin` int(10) unsigned NOT NULL,
  `tglpost` datetime NOT NULL,
  `idpenilai` varchar(20) NOT NULL,
  `komentar` varchar(100) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_buletin_cmt_idbuletin` (`idbuletin`),
  KEY `IX_buletin_cmt_ts` (`ts`,`issync`),
  CONSTRAINT `FK_buletin_cmt_idbuletin` FOREIGN KEY (`idbuletin`) REFERENCES `jbsvcr`.`buletin` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "buletin_cmt"
#


#
# Structure for table "buletin_rate"
#

DROP TABLE IF EXISTS `jbsvcr`.`buletin_rate`;
CREATE TABLE `jbsvcr`.`buletin_rate` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idbuletin` int(10) unsigned NOT NULL,
  `tglpost` datetime NOT NULL,
  `idpenilai` varchar(20) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_buletin_rate_idbuletin` (`idbuletin`),
  KEY `IX_buletin_rate_ts` (`ts`,`issync`),
  CONSTRAINT `FK_buletin_rate_idbuletin` FOREIGN KEY (`idbuletin`) REFERENCES `jbsvcr`.`buletin` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "buletin_rate"
#


#
# Structure for table "catatankategori"
#

DROP TABLE IF EXISTS `jbsvcr`.`catatankategori`;
CREATE TABLE `jbsvcr`.`catatankategori` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `kategori` varchar(255) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_catatankategori_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "catatankategori"
#


#
# Structure for table "catatansiswa"
#

DROP TABLE IF EXISTS `jbsvcr`.`catatansiswa`;
CREATE TABLE `jbsvcr`.`catatansiswa` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idkategori` int(10) unsigned NOT NULL,
  `nis` varchar(30) CHARACTER SET utf8 NOT NULL,
  `idkelas` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `judul` varchar(255) NOT NULL,
  `catatan` text NOT NULL,
  `nip` varchar(30) CHARACTER SET utf8 NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_catatansiswa_idkat` (`idkategori`),
  KEY `IX_catatansiswa_ts` (`ts`,`issync`),
  KEY `FK_catatansiswa_siswa` (`nis`),
  KEY `FK_catatansiswa_pegawai` (`nip`),
  CONSTRAINT `FK_catatansiswa_idkat` FOREIGN KEY (`idkategori`) REFERENCES `jbsvcr`.`catatankategori` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_catatansiswa_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_catatansiswa_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "catatansiswa"
#


#
# Structure for table "chat"
#

DROP TABLE IF EXISTS `jbsvcr`.`chat`;
CREATE TABLE `jbsvcr`.`chat` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `id` varchar(50) NOT NULL,
  `waktukirim` date NOT NULL,
  `pesan` text NOT NULL,
  `chatgroup` text NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_chat_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "chat"
#


#
# Structure for table "dirshare"
#

DROP TABLE IF EXISTS `jbsvcr`.`dirshare`;
CREATE TABLE `jbsvcr`.`dirshare` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idroot` int(10) unsigned NOT NULL,
  `dirname` varchar(255) NOT NULL,
  `dirfullpath` varchar(255) NOT NULL,
  `idguru` varchar(20) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_dirshare_ts` (`ts`,`issync`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

#
# Data for table "dirshare"
#

INSERT INTO `dirshare` VALUES (1,'2010-03-02 10:08:16',60772,0,0,'root','root/',NULL,NULL,NULL,NULL,NULL),(2,'2010-03-12 09:49:11',0,0,1,'101','root/101/','101',NULL,NULL,NULL,NULL),(3,'2021-04-02 10:38:45',0,0,1,'2021118118','root/2021118118/','2021118118',NULL,NULL,NULL,NULL),(4,'2021-04-02 10:39:58',0,0,1,'1234567891','root/1234567891/','1234567891',NULL,NULL,NULL,NULL),(5,'2021-04-02 10:41:55',0,0,1,'2021051051','root/2021051051/','2021051051',NULL,NULL,NULL,NULL),(6,'2021-04-02 10:42:51',0,0,1,'2021117117','root/2021117117/','2021117117',NULL,NULL,NULL,NULL),(7,'2021-04-02 11:03:15',0,0,1,'2021041041','root/2021041041/','2021041041',NULL,NULL,NULL,NULL),(8,'2021-04-02 11:03:51',0,0,1,'2021093093','root/2021093093/','2021093093',NULL,NULL,NULL,NULL),(9,'2021-04-02 11:10:16',0,0,1,'2021121121','root/2021121121/','2021121121',NULL,NULL,NULL,NULL),(10,'2021-04-02 11:25:51',0,0,1,'2021127127','root/2021127127/','2021127127',NULL,NULL,NULL,NULL),(11,'2021-04-02 11:26:38',0,0,1,'2021102102','root/2021102102/','2021102102',NULL,NULL,NULL,NULL),(12,'2021-04-02 11:40:52',0,0,1,'2021132132','root/2021132132/','2021132132',NULL,NULL,NULL,NULL),(13,'2021-04-02 11:45:25',0,0,1,'20210135135','root/20210135135/','20210135135',NULL,NULL,NULL,NULL),(14,'2021-04-02 11:54:28',0,0,1,'2021003003','root/2021003003/','2021003003',NULL,NULL,NULL,NULL);

#
# Structure for table "draft"
#

DROP TABLE IF EXISTS `jbsvcr`.`draft`;
CREATE TABLE `jbsvcr`.`draft` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tanggalpesan` datetime NOT NULL,
  `judul` varchar(255) NOT NULL,
  `pesan` text NOT NULL,
  `idpemilik` varchar(20) NOT NULL,
  `idpengirim` varchar(25) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_draft_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "draft"
#


#
# Structure for table "fileshare"
#

DROP TABLE IF EXISTS `jbsvcr`.`fileshare`;
CREATE TABLE `jbsvcr`.`fileshare` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `iddir` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `filetime` datetime NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_fileshareguru_1` (`iddir`),
  KEY `IX_fileshare_ts` (`ts`,`issync`),
  CONSTRAINT `FK_fileshareguru_1` FOREIGN KEY (`iddir`) REFERENCES `jbsvcr`.`dirshare` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "fileshare"
#


#
# Structure for table "galerifoto"
#

DROP TABLE IF EXISTS `jbsvcr`.`galerifoto`;
CREATE TABLE `jbsvcr`.`galerifoto` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idguru` varchar(20) DEFAULT NULL,
  `foto` blob,
  `keterangan` varchar(255) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `fotokecil` blob,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_galerifoto_nip` (`idguru`),
  KEY `IX_galerifoto_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "galerifoto"
#


#
# Structure for table "gallery"
#

DROP TABLE IF EXISTS `jbsvcr`.`gallery`;
CREATE TABLE `jbsvcr`.`gallery` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `nis` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `kategori` varchar(10) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `fjudul` text NOT NULL,
  `keterangan` varchar(2000) NOT NULL,
  `fprevketerangan` varchar(2000) NOT NULL,
  `fketerangan` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `lastactive` datetime NOT NULL,
  `lastread` datetime NOT NULL,
  `nread` int(10) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(45) NOT NULL,
  `info2` varchar(45) NOT NULL,
  `info3` varchar(45) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_gallery_departemen` (`departemen`),
  KEY `FK_gallery_siswa` (`nis`),
  KEY `FK_gallery_pegawai` (`nip`),
  KEY `IX_gallery` (`tanggal`,`lastactive`,`kategori`),
  CONSTRAINT `FK_gallery_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_gallery_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_gallery_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "gallery"
#


#
# Structure for table "gallerycomment"
#

DROP TABLE IF EXISTS `jbsvcr`.`gallerycomment`;
CREATE TABLE `jbsvcr`.`gallerycomment` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `galleryid` int(10) unsigned NOT NULL,
  `nis` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `komen` varchar(1000) NOT NULL,
  `fkomen` text NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_gallerycomment_siswa` (`nis`),
  KEY `FK_gallerycomment_pegawai` (`nip`),
  KEY `FK_gallerycomment_notes` (`galleryid`),
  CONSTRAINT `FK_gallerycomment_notes` FOREIGN KEY (`galleryid`) REFERENCES `jbsvcr`.`gallery` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_gallerycomment_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_gallerycomment_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "gallerycomment"
#


#
# Structure for table "galleryfile"
#

DROP TABLE IF EXISTS `jbsvcr`.`galleryfile`;
CREATE TABLE `jbsvcr`.`galleryfile` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `galleryid` int(10) unsigned NOT NULL,
  `filename` varchar(100) NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `filetype` varchar(45) NOT NULL,
  `fileinfo` varchar(1000) DEFAULT NULL,
  `ffileinfo` text,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  `location` varchar(45) NOT NULL,
  `iscover` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_galleryfile_gallery` (`galleryid`),
  CONSTRAINT `FK_galleryfile_gallery` FOREIGN KEY (`galleryid`) REFERENCES `jbsvcr`.`gallery` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "galleryfile"
#


#
# Structure for table "gambarbuletin"
#

DROP TABLE IF EXISTS `jbsvcr`.`gambarbuletin`;
CREATE TABLE `jbsvcr`.`gambarbuletin` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idpengirim` varchar(20) NOT NULL,
  `foto` mediumblob,
  `keterangan` varchar(255) DEFAULT NULL,
  `namafile` varchar(100) NOT NULL,
  `bulan` tinyint(2) unsigned NOT NULL,
  `tahun` int(4) unsigned NOT NULL,
  `filename` varchar(100) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_gambarbuletin_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "gambarbuletin"
#


#
# Structure for table "gambarlogin"
#

DROP TABLE IF EXISTS `jbsvcr`.`gambarlogin`;
CREATE TABLE `jbsvcr`.`gambarlogin` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `direktori` varchar(255) NOT NULL,
  `namafile` varchar(255) NOT NULL,
  `aktif` tinyint(1) DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_gambarlogin_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "gambarlogin"
#


#
# Structure for table "gambartiny"
#

DROP TABLE IF EXISTS `jbsvcr`.`gambartiny`;
CREATE TABLE `jbsvcr`.`gambartiny` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idguru` varchar(20) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `foto` blob,
  `keterangan` varchar(255) DEFAULT NULL,
  `namagambar` varchar(100) DEFAULT NULL,
  `bulan` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `tahun` int(4) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_gambartiny_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "gambartiny"
#


#
# Structure for table "gambartinypesan"
#

DROP TABLE IF EXISTS `jbsvcr`.`gambartinypesan`;
CREATE TABLE `jbsvcr`.`gambartinypesan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idguru` varchar(20) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `namafile` varchar(255) DEFAULT NULL,
  `direktori` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `namagambar` varchar(100) DEFAULT NULL,
  `bulan` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `tahun` int(4) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_gambartinypesan_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "gambartinypesan"
#


#
# Structure for table "jawabanangket"
#

DROP TABLE IF EXISTS `jbsvcr`.`jawabanangket`;
CREATE TABLE `jbsvcr`.`jawabanangket` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjawab` int(10) unsigned NOT NULL DEFAULT '0',
  `idpertanyaan` int(10) unsigned NOT NULL DEFAULT '0',
  `idpilihan` int(10) unsigned DEFAULT NULL,
  `isian` text,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_jawabanangket_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "jawabanangket"
#


#
# Structure for table "jawabangket"
#

DROP TABLE IF EXISTS `jbsvcr`.`jawabangket`;
CREATE TABLE `jbsvcr`.`jawabangket` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idangket` int(10) unsigned NOT NULL DEFAULT '0',
  `nis` varchar(20) DEFAULT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_jawabangket_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "jawabangket"
#


#
# Structure for table "kategoribuletin"
#

DROP TABLE IF EXISTS `jbsvcr`.`kategoribuletin`;
CREATE TABLE `jbsvcr`.`kategoribuletin` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `kategori` varchar(100) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  UNIQUE KEY `Index_2` (`kategori`),
  KEY `IX_kategoribuletin_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "kategoribuletin"
#


#
# Structure for table "komentar"
#

DROP TABLE IF EXISTS `jbsvcr`.`komentar`;
CREATE TABLE `jbsvcr`.`komentar` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `nip` varchar(20) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `owner` varchar(20) DEFAULT NULL,
  `komentar` text,
  `tanggal` datetime NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_komentar_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "komentar"
#


#
# Structure for table "lampiranberitaguru"
#

DROP TABLE IF EXISTS `jbsvcr`.`lampiranberitaguru`;
CREATE TABLE `jbsvcr`.`lampiranberitaguru` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idberita` int(10) unsigned NOT NULL,
  `namafile` varchar(255) NOT NULL,
  `direktori` varchar(255) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_lampiranberitaguru_1` (`idberita`),
  KEY `IX_lampiranberitaguru_ts` (`ts`,`issync`),
  CONSTRAINT `FK_lampiranberitaguru_1` FOREIGN KEY (`idberita`) REFERENCES `jbsvcr`.`beritaguru` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "lampiranberitaguru"
#


#
# Structure for table "lampiranberitasiswa"
#

DROP TABLE IF EXISTS `jbsvcr`.`lampiranberitasiswa`;
CREATE TABLE `jbsvcr`.`lampiranberitasiswa` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idberita` int(10) unsigned NOT NULL,
  `namafile` varchar(255) NOT NULL,
  `direktori` varchar(255) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_lampiranberitasiswa_1` (`idberita`),
  KEY `IX_lampiranberitasiswa_ts` (`ts`,`issync`),
  CONSTRAINT `FK_lampiranberitasiswa_1` FOREIGN KEY (`idberita`) REFERENCES `jbsvcr`.`beritasiswa` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "lampiranberitasiswa"
#


#
# Structure for table "lampirandraft"
#

DROP TABLE IF EXISTS `jbsvcr`.`lampirandraft`;
CREATE TABLE `jbsvcr`.`lampirandraft` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idpesan` int(10) unsigned NOT NULL,
  `namafile` varchar(255) NOT NULL,
  `direktori` varchar(255) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_lampirandraft_idpesan` (`idpesan`),
  KEY `IX_lampirandraft_ts` (`ts`,`issync`),
  CONSTRAINT `FK_lampirandraft_idpesan` FOREIGN KEY (`idpesan`) REFERENCES `jbsvcr`.`draft` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "lampirandraft"
#


#
# Structure for table "mutiara"
#

DROP TABLE IF EXISTS `jbsvcr`.`mutiara`;
CREATE TABLE `jbsvcr`.`mutiara` (
  `clientid` varchar(5) DEFAULT NULL,
  `region` varchar(5) DEFAULT NULL,
  `location` varchar(5) DEFAULT NULL,
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `kata` varchar(255) NOT NULL DEFAULT '',
  `firstname` varchar(20) NOT NULL DEFAULT '',
  `lastname` varchar(25) NOT NULL DEFAULT '',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_mutiara_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "mutiara"
#


#
# Structure for table "new"
#

DROP TABLE IF EXISTS `jbsvcr`.`new`;
CREATE TABLE `jbsvcr`.`new` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `foto` longblob,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IX_new_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "new"
#


#
# Structure for table "notes"
#

DROP TABLE IF EXISTS `jbsvcr`.`notes`;
CREATE TABLE `jbsvcr`.`notes` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `nis` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `kategori` varchar(10) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `fjudul` text NOT NULL,
  `kepada` varchar(100) NOT NULL,
  `tema` varchar(7) NOT NULL,
  `pesan` varchar(2000) NOT NULL,
  `fprevpesan` varchar(2000) NOT NULL,
  `fpesan` text NOT NULL,
  `tautan` varchar(255) DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `lastactive` datetime NOT NULL,
  `lastread` datetime NOT NULL,
  `nread` int(10) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(45) NOT NULL,
  `info2` varchar(45) NOT NULL,
  `info3` varchar(45) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_notes_siswa` (`nis`),
  KEY `FK_notes_pegawai` (`nip`),
  KEY `FK_notes_departemen` (`departemen`),
  KEY `IX_notes_tanggal` (`lastactive`,`tanggal`,`kategori`) USING BTREE,
  CONSTRAINT `FK_notes_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_notes_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_notes_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "notes"
#


#
# Structure for table "notescomment"
#

DROP TABLE IF EXISTS `jbsvcr`.`notescomment`;
CREATE TABLE `jbsvcr`.`notescomment` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notesid` int(10) unsigned NOT NULL,
  `nis` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `komen` varchar(1000) NOT NULL,
  `fkomen` text NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_notescomment_siswa` (`nis`),
  KEY `FK_notescomment_pegawai` (`nip`),
  KEY `FK_notescomment_notes` (`notesid`),
  CONSTRAINT `FK_notescomment_notes` FOREIGN KEY (`notesid`) REFERENCES `jbsvcr`.`notes` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_notescomment_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_notescomment_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "notescomment"
#


#
# Structure for table "notesfile"
#

DROP TABLE IF EXISTS `jbsvcr`.`notesfile`;
CREATE TABLE `jbsvcr`.`notesfile` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notesid` int(10) unsigned NOT NULL,
  `filecate` varchar(5) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `filetype` varchar(45) NOT NULL,
  `fileinfo` varchar(1000) DEFAULT NULL,
  `ffileinfo` text,
  `location` varchar(45) NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_notesfile_notes` (`notesid`),
  CONSTRAINT `FK_notesfile_notes` FOREIGN KEY (`notesid`) REFERENCES `jbsvcr`.`notes` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "notesfile"
#


#
# Structure for table "pertanyaan"
#

DROP TABLE IF EXISTS `jbsvcr`.`pertanyaan`;
CREATE TABLE `jbsvcr`.`pertanyaan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idangket` int(10) unsigned NOT NULL DEFAULT '0',
  `pertanyaan` varchar(1000) NOT NULL DEFAULT '',
  `jenis` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pertanyaan_angket` (`idangket`),
  KEY `IX_pertanyaan_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pertanyaan_angket` FOREIGN KEY (`idangket`) REFERENCES `jbsvcr`.`angket` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pertanyaan"
#


#
# Structure for table "pesan"
#

DROP TABLE IF EXISTS `jbsvcr`.`pesan`;
CREATE TABLE `jbsvcr`.`pesan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tanggalpesan` datetime NOT NULL,
  `tanggaltampil` date DEFAULT NULL,
  `judul` varchar(255) NOT NULL,
  `pesan` text NOT NULL,
  `idguru` varchar(20) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `keguru` tinyint(1) unsigned DEFAULT '0',
  `kesiswa` tinyint(1) unsigned DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_pesan_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pesan"
#


#
# Structure for table "lampiranpesan"
#

DROP TABLE IF EXISTS `jbsvcr`.`lampiranpesan`;
CREATE TABLE `jbsvcr`.`lampiranpesan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idpesan` int(10) unsigned NOT NULL,
  `namafile` varchar(255) NOT NULL,
  `direktori` varchar(255) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_lampiranpesan_1` (`idpesan`),
  KEY `IX_lampiranpesan_ts` (`ts`,`issync`),
  CONSTRAINT `FK_lampiranpesan_1` FOREIGN KEY (`idpesan`) REFERENCES `jbsvcr`.`pesan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "lampiranpesan"
#


#
# Structure for table "pesanterkirim"
#

DROP TABLE IF EXISTS `jbsvcr`.`pesanterkirim`;
CREATE TABLE `jbsvcr`.`pesanterkirim` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(255) NOT NULL,
  `idpesan` int(10) unsigned NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_pesanterkirim_1` (`idpesan`),
  KEY `IX_pesanterkirim_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pesanterkirim_1` FOREIGN KEY (`idpesan`) REFERENCES `jbsvcr`.`pesan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pesanterkirim"
#


#
# Structure for table "pilihan"
#

DROP TABLE IF EXISTS `jbsvcr`.`pilihan`;
CREATE TABLE `jbsvcr`.`pilihan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idpertanyaan` int(10) unsigned NOT NULL DEFAULT '0',
  `pilihan` varchar(45) NOT NULL DEFAULT '',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pilihan_pertanyaan` (`idpertanyaan`),
  KEY `IX_pilihan_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pilihan_tanya` FOREIGN KEY (`idpertanyaan`) REFERENCES `jbsvcr`.`pertanyaan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pilihan"
#


#
# Structure for table "profil"
#

DROP TABLE IF EXISTS `jbsvcr`.`profil`;
CREATE TABLE `jbsvcr`.`profil` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `nip` varchar(20) DEFAULT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `telpon` varchar(45) DEFAULT NULL,
  `hp` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `hobi` text,
  `buku` text,
  `riwayat` text,
  `foto` mediumblob,
  `tentang` text,
  `nis` varchar(20) DEFAULT NULL,
  `bg` mediumblob,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_profil_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "profil"
#


#
# Structure for table "subkategoribuletin"
#

DROP TABLE IF EXISTS `jbsvcr`.`subkategoribuletin`;
CREATE TABLE `jbsvcr`.`subkategoribuletin` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `kategori` varchar(100) NOT NULL,
  `subkategori` varchar(100) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_subkategoribuletin_1` (`kategori`),
  KEY `IX_subkategoribuletin_ts` (`ts`,`issync`),
  CONSTRAINT `FK_subkategoribuletin_1` FOREIGN KEY (`kategori`) REFERENCES `jbsvcr`.`kategoribuletin` (`kategori`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "subkategoribuletin"
#


#
# Structure for table "tujuanpesan"
#

DROP TABLE IF EXISTS `jbsvcr`.`tujuanpesan`;
CREATE TABLE `jbsvcr`.`tujuanpesan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `idpesan` int(10) unsigned NOT NULL,
  `idpenerima` varchar(20) NOT NULL,
  `baru` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_tujuanpesan_1` (`idpesan`),
  KEY `IX_tujuanpesan_ts` (`ts`,`issync`),
  CONSTRAINT `FK_tujuanpesan_1` FOREIGN KEY (`idpesan`) REFERENCES `jbsvcr`.`pesan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "tujuanpesan"
#


#
# Structure for table "video"
#

DROP TABLE IF EXISTS `jbsvcr`.`video`;
CREATE TABLE `jbsvcr`.`video` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `nis` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `kategori` varchar(10) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `fjudul` text NOT NULL,
  `keterangan` varchar(2000) NOT NULL,
  `fprevketerangan` varchar(2000) NOT NULL,
  `fketerangan` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `filename` varchar(100) NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `filetype` varchar(45) NOT NULL,
  `fileinfo` varchar(1000) DEFAULT NULL,
  `ffileinfo` text,
  `location` varchar(45) NOT NULL,
  `lastactive` datetime NOT NULL,
  `lastread` datetime NOT NULL,
  `nread` int(10) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(45) NOT NULL,
  `info2` varchar(45) NOT NULL,
  `info3` varchar(45) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_video_departemen` (`departemen`),
  KEY `FK_video_siswa` (`nis`),
  KEY `FK_video_pegawai` (`nip`),
  KEY `IX_video` (`kategori`,`tanggal`,`lastactive`),
  CONSTRAINT `FK_video_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_video_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_video_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "video"
#


#
# Structure for table "videocomment"
#

DROP TABLE IF EXISTS `jbsvcr`.`videocomment`;
CREATE TABLE `jbsvcr`.`videocomment` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `videoid` int(10) unsigned NOT NULL,
  `nis` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `komen` varchar(1000) NOT NULL,
  `fkomen` text NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_videocomment_video` (`videoid`),
  KEY `FK_videocomment_siswa` (`nis`),
  KEY `FK_videocomment_pegawai` (`nip`),
  CONSTRAINT `FK_videocomment_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_videocomment_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_videocomment_video` FOREIGN KEY (`videoid`) REFERENCES `jbsvcr`.`video` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "videocomment"
#

