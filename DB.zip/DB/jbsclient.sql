﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:48:08
# Generator: MySQL-Front 6.0  (Build 2.20)


#
# Structure for table "deleteddata"
#

DROP TABLE IF EXISTS `deleteddata`;
CREATE TABLE `deleteddata` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dbname` varchar(50) NOT NULL,
  `tablename` varchar(50) NOT NULL,
  `dataid` varchar(50) NOT NULL,
  `datatoken` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_DELETEDDATA_SYNC` (`ts`,`issync`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#
# Data for table "deleteddata"
#

INSERT INTO `deleteddata` VALUES (1,'2021-04-02 11:26:38',14428,0,'jbsakad','guru','172',30846),(2,'2021-04-02 11:40:55',26493,0,'jbsakad','aturangrading','286',44471),(3,'2021-04-02 11:40:55',27728,0,'jbsakad','aturangrading','287',46798),(4,'2021-04-02 11:40:55',59159,0,'jbsakad','aturangrading','288',35047),(5,'2021-04-02 11:40:57',65336,0,'jbsakad','aturangrading','269',46741),(6,'2021-04-02 11:40:57',22335,0,'jbsakad','aturangrading','270',1339),(7,'2021-04-02 11:46:32',50764,0,'jbsakad','guru','124',9233),(8,'2021-04-02 11:46:39',52560,0,'jbsakad','aturannhb','266',4478),(9,'2021-04-02 11:46:39',19097,0,'jbsakad','aturannhb','267',36060),(10,'2021-04-02 11:46:39',3331,0,'jbsakad','aturannhb','268',35806),(11,'2021-04-02 11:47:11',35072,0,'jbsakad','guru','123',61330),(12,'2021-04-02 12:00:16',37513,0,'jbsakad','guru','56',23019),(13,'2021-04-02 12:05:27',43205,0,'jbsakad','phsiswa','72',42120),(14,'2021-04-02 12:05:27',61028,0,'jbsakad','phsiswa','73',31412),(15,'2021-04-02 12:05:27',44466,0,'jbsakad','phsiswa','74',30700),(16,'2021-04-02 12:05:27',39244,0,'jbsakad','phsiswa','75',59264),(17,'2021-04-02 12:05:27',62820,0,'jbsakad','phsiswa','76',7630),(18,'2021-04-02 12:05:27',65308,0,'jbsakad','phsiswa','77',56948),(19,'2021-04-02 12:05:27',7021,0,'jbsakad','phsiswa','78',65257),(20,'2021-04-02 12:05:27',35769,0,'jbsakad','phsiswa','79',24380),(21,'2021-04-02 12:05:27',26721,0,'jbsakad','phsiswa','80',57188),(22,'2021-04-02 12:05:27',26296,0,'jbsakad','phsiswa','81',16208),(23,'2021-04-02 12:05:27',51319,0,'jbsakad','phsiswa','82',40539),(24,'2021-04-02 12:05:27',46647,0,'jbsakad','phsiswa','83',23011),(25,'2021-04-02 12:05:27',13748,0,'jbsakad','phsiswa','84',58968),(26,'2021-04-02 12:05:27',59860,0,'jbsakad','phsiswa','85',29213),(27,'2021-04-02 12:05:27',61462,0,'jbsakad','phsiswa','86',34693),(28,'2021-04-02 12:05:27',62201,0,'jbsakad','phsiswa','87',20297),(29,'2021-04-02 12:05:27',61089,0,'jbsakad','phsiswa','88',62933),(30,'2021-04-02 12:05:27',53309,0,'jbsakad','phsiswa','89',57183),(31,'2021-04-02 12:05:27',17750,0,'jbsakad','phsiswa','90',31585),(32,'2021-04-02 12:05:27',59881,0,'jbsakad','phsiswa','91',51907),(33,'2021-04-02 12:05:27',49565,0,'jbsakad','phsiswa','92',33718),(34,'2021-04-02 12:05:27',2651,0,'jbsakad','phsiswa','93',12869),(35,'2021-04-02 12:05:27',61152,0,'jbsakad','phsiswa','94',28721),(36,'2021-04-02 12:05:27',35683,0,'jbsakad','phsiswa','95',39468),(37,'2021-04-02 12:05:27',60492,0,'jbsakad','phsiswa','96',45647),(38,'2021-04-02 12:05:27',64348,0,'jbsakad','phsiswa','97',44298),(39,'2021-04-02 12:05:27',9203,0,'jbsakad','phsiswa','98',19021),(40,'2021-04-02 12:05:27',49562,0,'jbsakad','phsiswa','99',27740),(41,'2021-04-02 12:05:27',23608,0,'jbsakad','phsiswa','100',16107),(42,'2021-04-02 12:05:27',34885,0,'jbsakad','phsiswa','101',62845),(43,'2021-04-02 12:05:27',38070,0,'jbsakad','phsiswa','102',3781),(44,'2021-04-02 12:05:27',20166,0,'jbsakad','phsiswa','103',26960),(45,'2021-04-02 12:05:27',52149,0,'jbsakad','phsiswa','104',57925),(46,'2021-04-02 12:05:27',3657,0,'jbsakad','phsiswa','105',12158),(47,'2021-04-02 12:05:27',58429,0,'jbsakad','phsiswa','106',18073),(48,'2021-04-02 12:05:27',19050,0,'jbsakad','presensiharian','3',59729),(49,'2021-04-02 21:45:03',18394,0,'jbsakad','tingkat','35',18050),(50,'2021-04-03 09:02:55',9645,0,'jbsakad','jadwal','15',37693),(51,'2021-04-03 09:02:58',6085,0,'jbsakad','jadwal','12',9604),(52,'2021-04-03 09:03:01',9318,0,'jbsakad','jadwal','17',47014),(53,'2021-04-03 09:03:08',26816,0,'jbsakad','jadwal','24',53023),(54,'2021-04-03 09:36:40',6104,0,'jbsakad','guru','208',25033),(55,'2021-04-03 09:36:51',52543,0,'jbsakad','guru','207',34767),(56,'2021-04-03 09:46:01',11282,0,'jbsakad','jadwal','13',32168),(57,'2021-04-03 09:46:04',39209,0,'jbsakad','jadwal','18',60652),(58,'2021-04-03 09:51:16',13784,0,'jbsakad','jadwal','14',26709),(59,'2021-04-03 09:51:24',37985,0,'jbsakad','jadwal','16',8266),(60,'2021-04-03 10:01:05',54205,0,'jbsakad','jadwal','39',3143),(61,'2021-04-03 10:03:14',21965,0,'jbsakad','guru','190',27651),(62,'2021-04-03 10:55:49',57732,0,'jbsakad','jadwal','26',35720),(63,'2021-04-04 10:36:38',19230,0,'jbsakad','guru','228',49438),(64,'2021-04-04 10:36:50',32112,0,'jbsakad','guru','229',60001),(65,'2021-04-04 11:35:46',3556,0,'jbsakad','guru','266',17339),(66,'2021-04-04 22:15:59',45559,0,'jbsakad','jadwal','126',33610),(67,'2021-04-05 09:44:22',14285,0,'jbsakad','jadwal','9',64126),(68,'2021-04-05 09:44:26',49064,0,'jbsakad','jadwal','8',55568),(69,'2021-04-05 09:44:28',53118,0,'jbsakad','jadwal','7',64855),(70,'2021-04-05 09:44:36',45848,0,'jbsakad','jadwal','3',64096),(71,'2021-04-05 09:44:40',30287,0,'jbsakad','jadwal','5',44931),(72,'2021-04-05 09:44:45',24045,0,'jbsakad','jadwal','11',42201),(73,'2021-04-05 09:44:50',18442,0,'jbsakad','jadwal','6',5614),(74,'2021-04-05 09:59:26',5700,0,'jbsakad','jadwal','240',42023),(75,'2021-04-05 10:18:48',34827,0,'jbsakad','jadwal','256',3350),(76,'2021-04-05 10:18:55',8572,0,'jbsakad','jadwal','257',33788),(77,'2021-04-05 10:57:36',63152,0,'jbsakad','jadwal','62',22171),(78,'2021-04-05 11:12:03',8252,0,'jbsakad','jadwal','305',58523),(79,'2021-04-05 11:47:16',23730,0,'jbsakad','jadwal','20',16351),(80,'2021-04-05 11:47:19',6876,0,'jbsakad','jadwal','21',24980),(81,'2021-04-05 11:47:25',40849,0,'jbsakad','jadwal','23',26285),(82,'2021-04-05 11:47:31',52763,0,'jbsakad','jadwal','19',24786),(83,'2021-04-05 11:47:34',6250,0,'jbsakad','jadwal','22',57718),(84,'2021-04-05 21:50:29',25768,0,'jbsakad','jadwal','412',47891),(85,'2021-04-08 10:04:59',13641,0,'jbsakad','jadwal','558',6138),(86,'2021-04-08 10:25:32',53165,0,'jbsakad','jadwal','596',20178),(87,'2021-04-08 14:34:00',58541,0,'jbsakad','jadwal','658',12505),(88,'2021-04-08 14:34:39',16435,0,'jbsakad','jadwal','659',24713),(89,'2021-04-08 14:35:03',55766,0,'jbsakad','jadwal','660',14758),(90,'2021-04-08 14:35:33',42740,0,'jbsakad','jadwal','661',63768),(91,'2021-04-08 15:19:34',24145,0,'jbsakad','jadwal','763',8158);

#
# Structure for table "exporthistory"
#

DROP TABLE IF EXISTS `exporthistory`;
CREATE TABLE `exporthistory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transferid` varchar(15) NOT NULL,
  `synctype` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `synctime` datetime NOT NULL,
  `syncfile` varchar(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Data for table "exporthistory"
#


#
# Structure for table "liveupdate"
#

DROP TABLE IF EXISTS `liveupdate`;
CREATE TABLE `liveupdate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `liveupdateid` int(10) unsigned NOT NULL,
  `info` varchar(255) NOT NULL,
  `tipe` varchar(3) NOT NULL,
  `versi` varchar(15) NOT NULL,
  `tanggal` date NOT NULL,
  `repl_targetfile` varchar(255) DEFAULT NULL,
  `repl_varname` varchar(255) DEFAULT NULL,
  `repl_searchstr` varchar(255) DEFAULT NULL,
  `repl_replacestr` varchar(255) DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 Disable, 1 Enable',
  `message` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`liveupdateid`),
  UNIQUE KEY `UX_liveupdate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "liveupdate"
#


#
# Structure for table "liveupdateconfig"
#

DROP TABLE IF EXISTS `liveupdateconfig`;
CREATE TABLE `liveupdateconfig` (
  `tipe` varchar(20) NOT NULL,
  `nilai` varchar(45) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tipe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "liveupdateconfig"
#

INSERT INTO `liveupdateconfig` VALUES ('MIN_UPDATE_ID','862','-');

#
# Structure for table "liveupdatefile"
#

DROP TABLE IF EXISTS `liveupdatefile`;
CREATE TABLE `liveupdatefile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `liveupdateid` int(10) unsigned NOT NULL,
  `berkas` varchar(255) NOT NULL,
  `targetdir` varchar(255) DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0 Disable 1 Enable',
  `tipe` varchar(4) NOT NULL DEFAULT 'DOWN' COMMENT 'DOWN | EXEC',
  PRIMARY KEY (`liveupdateid`),
  UNIQUE KEY `UX_liveupdatefile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "liveupdatefile"
#


#
# Structure for table "liveupdatefile2"
#

DROP TABLE IF EXISTS `liveupdatefile2`;
CREATE TABLE `liveupdatefile2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `liveupdateid` int(10) unsigned NOT NULL,
  `berkas` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_LIVEUPDATEID` (`liveupdateid`)
) ENGINE=MyISAM AUTO_INCREMENT=942 DEFAULT CHARSET=latin1;

#
# Data for table "liveupdatefile2"
#


#
# Structure for table "liveupdatefiledown"
#

DROP TABLE IF EXISTS `liveupdatefiledown`;
CREATE TABLE `liveupdatefiledown` (
  `liveupdateid` int(10) unsigned NOT NULL,
  `filename` varchar(150) NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `rectime` datetime NOT NULL,
  PRIMARY KEY (`liveupdateid`,`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for table "liveupdatefiledown"
#


#
# Structure for table "pkchanges"
#

DROP TABLE IF EXISTS `pkchanges`;
CREATE TABLE `pkchanges` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dbname` varchar(50) CHARACTER SET latin1 NOT NULL,
  `tablename` varchar(50) CHARACTER SET latin1 NOT NULL,
  `dataid` int(10) unsigned NOT NULL,
  `datatoken` smallint(5) unsigned NOT NULL,
  `newpk` varchar(100) CHARACTER SET latin1 NOT NULL,
  `oldpk` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_PKCHANGES_SYNC` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#
# Data for table "pkchanges"
#


#
# Structure for table "syncconfig"
#

DROP TABLE IF EXISTS `syncconfig`;
CREATE TABLE `syncconfig` (
  `tipe` varchar(20) NOT NULL,
  `nilai` varchar(45) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tipe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "syncconfig"
#

INSERT INTO `syncconfig` VALUES ('DATABASE_ID','TVQvIxw7my9elIfRnUYYY6Z1Gw9cpcdau4Kc8jUikXpUn','Please Don\'t Change OR Delete This Value');

#
# Structure for table "synchistory"
#

DROP TABLE IF EXISTS `synchistory`;
CREATE TABLE `synchistory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(15) NOT NULL,
  `transferid` varchar(15) NOT NULL,
  `synctype` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `starttime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `synctime` datetime NOT NULL,
  `syncfile` varchar(255) NOT NULL,
  `repopath` varchar(700) NOT NULL,
  `appid` varchar(5) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IX_SYNCHISTORY` (`method`,`synctype`,`starttime`,`appid`,`synctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "synchistory"
#


#
# Structure for table "vcontrol"
#

DROP TABLE IF EXISTS `vcontrol`;
CREATE TABLE `vcontrol` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c` varchar(5) NOT NULL,
  `v` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "vcontrol"
#


#
# Structure for table "version"
#

DROP TABLE IF EXISTS `version`;
CREATE TABLE `version` (
  `version` varchar(10) NOT NULL,
  `builddate` datetime NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "version"
#

INSERT INTO `version` VALUES ('24.0','2021-04-01 00:00:00');
