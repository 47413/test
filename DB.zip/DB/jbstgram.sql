﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:50:12
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbstgram`;

#
# Structure for table "bantuan"
#

DROP TABLE IF EXISTS `jbstgram`.`bantuan`;
CREATE TABLE `jbstgram`.`bantuan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bantuan` mediumtext NOT NULL,
  PRIMARY KEY (`replid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "bantuan"
#

INSERT INTO `bantuan` VALUES (1,'Terima kasih telah menggunakan {TGRAM_NAME}\r\n\r\nUntuk pertanyaan dan konsultasi mengenai ... silahkan hubungi\r\n1. \r\n2. \r\n3. \r\n\r\nUntuk informasi lebih lanjut, silahkan kunjungi situs kami di http://www.sekolah.id');

#
# Structure for table "berita"
#

DROP TABLE IF EXISTS `jbstgram`.`berita`;
CREATE TABLE `jbstgram`.`berita` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tanggal` datetime NOT NULL,
  `berita` varchar(450) NOT NULL,
  `operator` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_berita_pegawai` (`operator`),
  CONSTRAINT `FK_berita_pegawai` FOREIGN KEY (`operator`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "berita"
#


#
# Structure for table "callback"
#

DROP TABLE IF EXISTS `jbstgram`.`callback`;
CREATE TABLE `jbstgram`.`callback` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(20) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `chatid` bigint(20) unsigned NOT NULL,
  `token` varchar(10) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_callback` (`action`,`userid`,`chatid`,`token`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "callback"
#


#
# Structure for table "kelompokalumni"
#

DROP TABLE IF EXISTS `jbstgram`.`kelompokalumni`;
CREATE TABLE `jbstgram`.`kelompokalumni` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(255) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`replid`) USING BTREE,
  KEY `FK_kelompokalumni_departemen` (`departemen`),
  CONSTRAINT `FK_kelompokalumni_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "kelompokalumni"
#


#
# Structure for table "kelompoktujuan"
#

DROP TABLE IF EXISTS `jbstgram`.`kelompoktujuan`;
CREATE TABLE `jbstgram`.`kelompoktujuan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(100) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `deskripsi` varchar(2555) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `pemilik` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`replid`) USING BTREE,
  KEY `FK_kelompoktujuan_departemen` (`departemen`),
  KEY `FK_kelompoktujuan_pegawai` (`pemilik`),
  CONSTRAINT `FK_kelompoktujuan_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_kelompoktujuan_pegawai` FOREIGN KEY (`pemilik`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "kelompoktujuan"
#


#
# Structure for table "anggota"
#

DROP TABLE IF EXISTS `jbstgram`.`anggota`;
CREATE TABLE `jbstgram`.`anggota` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkelompok` int(10) unsigned NOT NULL,
  `jenis` tinyint(1) unsigned NOT NULL COMMENT '0 Siswa, 1 Pegawai, 2 Other, 3 Calon Siswa',
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nic` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nouser` varchar(30) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`replid`),
  KEY `FK_anggota_kelompokpeserta` (`idkelompok`),
  KEY `FK_anggota_siswa` (`nis`),
  KEY `FK_anggota_pegawai` (`nip`),
  KEY `FK_anggota_calonsiswa` (`nic`),
  CONSTRAINT `FK_anggota_calonsiswa` FOREIGN KEY (`nic`) REFERENCES `jbsakad`.`calonsiswa` (`nopendaftaran`) ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_kelompokpeserta` FOREIGN KEY (`idkelompok`) REFERENCES `jbstgram`.`kelompoktujuan` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "anggota"
#


#
# Structure for table "member"
#

DROP TABLE IF EXISTS `jbstgram`.`member`;
CREATE TABLE `jbstgram`.`member` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jenis` tinyint(3) unsigned NOT NULL COMMENT '1 Pegawai, 2 Siswa, 3 Calon Siswa, 4 Alumni',
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nic` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `kelompok` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 Sendiri, 2 Orangtua',
  `tgramname` varchar(255) NOT NULL,
  `chatid` bigint(20) unsigned NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `regdate` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `idalumni` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_member_siswa` (`nis`),
  KEY `FK_member_pegawai` (`nip`),
  KEY `FK_member_calonsiswa` (`nic`),
  KEY `IX_member` (`jenis`,`kelompok`,`chatid`),
  KEY `FK_member_kelompokalumni` (`idalumni`),
  CONSTRAINT `FK_member_calonsiswa` FOREIGN KEY (`nic`) REFERENCES `jbsakad`.`calonsiswa` (`nopendaftaran`) ON UPDATE CASCADE,
  CONSTRAINT `FK_member_kelompokalumni` FOREIGN KEY (`idalumni`) REFERENCES `jbstgram`.`kelompokalumni` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_member_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_member_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "member"
#


#
# Structure for table "send"
#

DROP TABLE IF EXISTS `jbstgram`.`send`;
CREATE TABLE `jbstgram`.`send` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msgdate` datetime NOT NULL,
  `destchatid` bigint(20) unsigned NOT NULL,
  `destname` varchar(255) NOT NULL,
  `srcchatid` bigint(20) unsigned NOT NULL,
  `msgtext` mediumtext,
  `msgdata` mediumblob,
  `msgfilename` varchar(255) DEFAULT NULL,
  `msgtype` tinyint(3) unsigned NOT NULL COMMENT '1 Text, 2 Object',
  `msgsource` varchar(50) NOT NULL,
  `isfetch` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_send` (`isfetch`,`msgdate`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "send"
#


#
# Structure for table "sendhistory"
#

DROP TABLE IF EXISTS `jbstgram`.`sendhistory`;
CREATE TABLE `jbstgram`.`sendhistory` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsend` int(10) unsigned NOT NULL,
  `msgdate` datetime NOT NULL,
  `destchatid` bigint(20) unsigned NOT NULL,
  `destname` varchar(255) NOT NULL,
  `srcchatid` bigint(20) unsigned NOT NULL,
  `msgtext` mediumtext,
  `msgdata` mediumblob,
  `msgfilename` varchar(255) DEFAULT NULL,
  `msgtype` tinyint(3) unsigned NOT NULL COMMENT '1 Text, 2 Object',
  `msgsource` varchar(50) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_sendhistory` (`msgdate`,`srcchatid`,`msgtype`,`msgsource`,`idsend`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "sendhistory"
#

