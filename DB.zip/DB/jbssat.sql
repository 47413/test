﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:49:42
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbssat`;

#
# Structure for table "franggota"
#

DROP TABLE IF EXISTS `jbssat`.`franggota`;
CREATE TABLE `jbssat`.`franggota` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkelompok` int(10) unsigned NOT NULL,
  `jenis` tinyint(1) unsigned NOT NULL COMMENT '0 Siswa, 1 Pegawai, 2 Other',
  `nis` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nouser` varchar(30) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_franggota_frkelompok` (`idkelompok`),
  KEY `FK_franggota_siswa` (`nis`),
  KEY `FK_franggota_pegawai` (`nip`),
  CONSTRAINT `FK_franggota_frkelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbssat`.`frkelompok` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_franggota_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_franggota_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "franggota"
#


#
# Structure for table "frconfigassms"
#

DROP TABLE IF EXISTS `jbssat`.`frconfigassms`;
CREATE TABLE `jbssat`.`frconfigassms` (
  `departemen` varchar(45) NOT NULL,
  `asin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `asout` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pengirim` varchar(45) NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  KEY `FK_frconfigassms_departemen` (`departemen`),
  CONSTRAINT `FK_frconfigassms_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frconfigassms"
#

INSERT INTO `frconfigassms` VALUES ('SMA',0,0,'JIBAS SPT FGR','0','00:00',NULL);

#
# Structure for table "frdata"
#

DROP TABLE IF EXISTS `jbssat`.`frdata`;
CREATE TABLE `jbssat`.`frdata` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ownertype` tinyint(1) unsigned NOT NULL COMMENT '0 = Siswa, 1 = Pegawai',
  `nis` varchar(30) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `departemen` varchar(50) DEFAULT NULL,
  `template` blob NOT NULL,
  `image` mediumblob NOT NULL,
  `fingerpos` varchar(4) NOT NULL,
  `description` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `lastpresence` datetime DEFAULT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `verify` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frdata_siswa` (`nis`),
  KEY `FK_frdata_pegawai` (`nip`),
  KEY `FK_frdata_departemen` (`departemen`),
  KEY `IX_frdata` (`ownertype`,`nis`,`nip`,`departemen`),
  CONSTRAINT `FK_frdata_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frdata_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frdata_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frdata"
#


#
# Structure for table "frformatsms"
#

DROP TABLE IF EXISTS `jbssat`.`frformatsms`;
CREATE TABLE `jbssat`.`frformatsms` (
  `smstype` varchar(10) NOT NULL,
  `smsformat` varchar(500) NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`smstype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frformatsms"
#

INSERT INTO `frformatsms` VALUES ('MASUK','Kami informasikan presensi {NAMA} tanggal {TANGGAL}/{BULAN}/{TAHUN}, masuk jam {JAM_MASUK}',NULL,NULL,NULL),('PULANG','Kami informasikan presensi {NAMA} tanggal {TANGGAL}/{BULAN}/{TAHUN}, masuk jam {JAM_MASUK} pulang jam {JAM_PULANG}',NULL,NULL,NULL),('TAKHADIR','Kami informasikan bahwa siswa {NAMA} tidak hadir di sekolah pada tanggal {TANGGAL}/{BULAN}/{TAHUN}',NULL,NULL,NULL),('TELAT','Kami informasikan presensi {NAMA} tanggal {TANGGAL}/{BULAN}/{TAHUN}, masuk jam {JAM_MASUK}, terlambat {MENIT_TELAT} menit',NULL,NULL,NULL);

#
# Structure for table "frformatsmsact"
#

DROP TABLE IF EXISTS `jbssat`.`frformatsmsact`;
CREATE TABLE `jbssat`.`frformatsmsact` (
  `smstype` varchar(10) NOT NULL,
  `smsformat` varchar(500) NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`smstype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frformatsmsact"
#

INSERT INTO `frformatsmsact` VALUES ('MASUK','Kami informasikan presensi {NAMA} di kegiatan {KEGIATAN} tanggal {TANGGAL}/{BULAN}/{TAHUN}, masuk jam {JAM_MASUK}',NULL,NULL,NULL),('PULANG','Kami informasikan presensi {NAMA} di kegiatan {KEGIATAN} tanggal {TANGGAL}/{BULAN}/{TAHUN}, masuk jam {JAM_MASUK} pulang jam {JAM_PULANG}',NULL,NULL,NULL),('TAKHADIR','Kami informasikan bahwa siswa {NAMA} di kegiatan {KEGIATAN} tidak hadir di sekolah pada tanggal {TANGGAL}/{BULAN}/{TAHUN}',NULL,NULL,NULL),('TELAT','Kami informasikan presensi {NAMA} di kegiatan {KEGIATAN} tanggal {TANGGAL}/{BULAN}/{TAHUN}, masuk jam {JAM_MASUK}, terlambat {MENIT_TELAT} menit',NULL,NULL,NULL);

#
# Structure for table "frfreetime"
#

DROP TABLE IF EXISTS `jbssat`.`frfreetime`;
CREATE TABLE `jbssat`.`frfreetime` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nip` varchar(30) CHARACTER SET utf8 NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `mintime` int(10) unsigned NOT NULL DEFAULT '1',
  `senin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `selasa` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `rabu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `kamis` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `jumat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sabtu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `minggu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keterangan` varchar(255) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frfreetime_pegawai` (`nip`),
  CONSTRAINT `FK_frfreetime_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frfreetime"
#


#
# Structure for table "frjadwalsekolah"
#

DROP TABLE IF EXISTS `jbssat`.`frjadwalsekolah`;
CREATE TABLE `jbssat`.`frjadwalsekolah` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 Siswa 1 Pegawai',
  `pos` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hari` tinyint(1) unsigned NOT NULL COMMENT '1 Minggu 2 Senin 7 Sabtu',
  `masukaw` varchar(7) NOT NULL,
  `masukak` varchar(7) NOT NULL,
  `telat` varchar(7) NOT NULL,
  `pulangaw` varchar(7) NOT NULL,
  `pulangak` varchar(7) NOT NULL,
  `pulangstd` varchar(7) NOT NULL,
  `mmasukaw` int(10) unsigned NOT NULL,
  `mmasukak` int(10) unsigned NOT NULL,
  `mtelat` int(10) unsigned NOT NULL,
  `mpulangaw` int(10) unsigned NOT NULL,
  `mpulangak` int(10) unsigned NOT NULL,
  `mpulangstd` int(10) unsigned NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frjadwalsekolah"
#


#
# Structure for table "frkelompok"
#

DROP TABLE IF EXISTS `jbssat`.`frkelompok`;
CREATE TABLE `jbssat`.`frkelompok` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(100) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `deskripsi` varchar(2555) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frkelompok_departemen` (`departemen`),
  CONSTRAINT `FK_frkelompok_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frkelompok"
#


#
# Structure for table "frkegiatan"
#

DROP TABLE IF EXISTS `jbssat`.`frkegiatan`;
CREATE TABLE `jbssat`.`frkegiatan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kegiatan` varchar(100) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `jeniswaktu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 Berbatas Waktu, 1 Tidak Berbatas Waktu',
  `tglawal` date DEFAULT NULL,
  `tglakhir` date DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `jenispeserta` tinyint(1) unsigned NOT NULL,
  `idkelompok` int(10) unsigned DEFAULT NULL,
  `iddepartemen` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `idtingkat` int(10) unsigned DEFAULT NULL,
  `idkelas` int(10) unsigned DEFAULT NULL,
  `kelompokpegawai` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 Akademik, 1 Non Akademik',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frkegiatan_kelompok` (`idkelompok`),
  KEY `FK_frkegiatan_departemen` (`iddepartemen`),
  KEY `FK_frkegiatan_tingkat` (`idtingkat`),
  KEY `FK_frkegiatan_kelas` (`idkelas`),
  KEY `FK_frkegiatan_departemenowner` (`departemen`),
  CONSTRAINT `FK_frkegiatan_departemen` FOREIGN KEY (`iddepartemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frkegiatan_departemenowner` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frkegiatan_kelas` FOREIGN KEY (`idkelas`) REFERENCES `jbsakad`.`kelas` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frkegiatan_kelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbssat`.`frkelompok` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frkegiatan_tingkat` FOREIGN KEY (`idtingkat`) REFERENCES `jbsakad`.`tingkat` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frkegiatan"
#


#
# Structure for table "frconfigassmsact"
#

DROP TABLE IF EXISTS `jbssat`.`frconfigassmsact`;
CREATE TABLE `jbssat`.`frconfigassmsact` (
  `idkegiatan` int(10) unsigned NOT NULL,
  `asin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `aslate` tinyint(1) unsigned NOT NULL,
  `asout` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pengirim` varchar(45) NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  KEY `FK_frconfigassmsact_kegiatan` (`idkegiatan`),
  CONSTRAINT `FK_frconfigassmsact_kegiatan` FOREIGN KEY (`idkegiatan`) REFERENCES `jbssat`.`frkegiatan` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frconfigassmsact"
#


#
# Structure for table "frjadwalkegiatan"
#

DROP TABLE IF EXISTS `jbssat`.`frjadwalkegiatan`;
CREATE TABLE `jbssat`.`frjadwalkegiatan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkegiatan` int(10) unsigned NOT NULL,
  `hari` tinyint(1) unsigned NOT NULL COMMENT '1 Minggu 2 Senin 7 Sabtu',
  `masukaw` varchar(7) NOT NULL,
  `masukak` varchar(7) NOT NULL,
  `telat` varchar(7) NOT NULL,
  `pulangaw` varchar(7) NOT NULL,
  `pulangak` varchar(7) NOT NULL,
  `pulangstd` varchar(7) NOT NULL,
  `mmasukaw` int(10) unsigned NOT NULL,
  `mmasukak` int(10) unsigned NOT NULL,
  `mtelat` int(10) unsigned NOT NULL,
  `mpulangaw` int(10) unsigned NOT NULL,
  `mpulangak` int(10) unsigned NOT NULL,
  `mpulangstd` int(10) unsigned NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frjadwalkegiatan_kegiatan` (`idkegiatan`),
  CONSTRAINT `FK_frjadwalkegiatan_kegiatan` FOREIGN KEY (`idkegiatan`) REFERENCES `jbssat`.`frkegiatan` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frjadwalkegiatan"
#


#
# Structure for table "frother"
#

DROP TABLE IF EXISTS `jbssat`.`frother`;
CREATE TABLE `jbssat`.`frother` (
  `nouser` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`nouser`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frother"
#


#
# Structure for table "frpeserta"
#

DROP TABLE IF EXISTS `jbssat`.`frpeserta`;
CREATE TABLE `jbssat`.`frpeserta` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkegiatan` int(10) unsigned NOT NULL,
  `nis` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nouser` varchar(10) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`replid`),
  KEY `FK_frpeserta_siswa` (`nis`),
  KEY `FK_frpeserta_pegawai` (`nip`),
  KEY `FK_frpeserta_frother` (`nouser`),
  KEY `FK_frpeserta_frkegiatan` (`idkegiatan`),
  CONSTRAINT `FK_frpeserta_frkegiatan` FOREIGN KEY (`idkegiatan`) REFERENCES `jbssat`.`frkegiatan` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_frpeserta_frother` FOREIGN KEY (`nouser`) REFERENCES `jbssat`.`frother` (`nouser`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpeserta_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpeserta_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "frpeserta"
#


#
# Structure for table "frpresensikegiatan"
#

DROP TABLE IF EXISTS `jbssat`.`frpresensikegiatan`;
CREATE TABLE `jbssat`.`frpresensikegiatan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkegiatan` int(10) unsigned NOT NULL,
  `nis` varchar(30) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nouser` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `date_in` date NOT NULL,
  `time_in` varchar(10) NOT NULL,
  `frid_in` int(10) unsigned DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `time_out` varchar(10) DEFAULT NULL,
  `frid_out` int(10) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `smssent` tinyint(1) unsigned DEFAULT '0',
  `smssenthome` tinyint(1) unsigned DEFAULT '0',
  `source` varchar(1) NOT NULL DEFAULT 'F',
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frpresensikegiatan_kegiatan` (`idkegiatan`),
  KEY `FK_frpresensikegiatan_siswa` (`nis`),
  KEY `FK_frpresensikegiatan_pegawai` (`nip`),
  KEY `FK_frpresensikegiatan_other` (`nouser`),
  KEY `FK_frpresensikegiatan_frdata_in` (`frid_in`),
  KEY `FK_frpresensikegiatan_frdata_out` (`frid_out`),
  CONSTRAINT `FK_frpresensikegiatan_frdata_in` FOREIGN KEY (`frid_in`) REFERENCES `jbssat`.`frdata` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresensikegiatan_frdata_out` FOREIGN KEY (`frid_out`) REFERENCES `jbssat`.`frdata` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresensikegiatan_kegiatan` FOREIGN KEY (`idkegiatan`) REFERENCES `jbssat`.`frkegiatan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresensikegiatan_other` FOREIGN KEY (`nouser`) REFERENCES `jbssat`.`frother` (`nouser`) ON UPDATE NO ACTION,
  CONSTRAINT `FK_frpresensikegiatan_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresensikegiatan_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frpresensikegiatan"
#


#
# Structure for table "frruntext"
#

DROP TABLE IF EXISTS `jbssat`.`frruntext`;
CREATE TABLE `jbssat`.`frruntext` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`replid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "frruntext"
#

INSERT INTO `frruntext` VALUES (1,'JIBAS Sistem Presensi Terpadu Fingerprint');

#
# Structure for table "frsisforeport"
#

DROP TABLE IF EXISTS `jbssat`.`frsisforeport`;
CREATE TABLE `jbssat`.`frsisforeport` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` int(10) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `startdate` tinyint(3) unsigned NOT NULL,
  `enddate` tinyint(3) unsigned NOT NULL,
  `h` int(10) unsigned NOT NULL,
  `i` int(10) unsigned NOT NULL,
  `s` int(10) unsigned NOT NULL,
  `c` int(10) unsigned NOT NULL,
  `a` int(10) unsigned NOT NULL,
  `departemen` varchar(45) NOT NULL,
  `idtingkat` int(10) unsigned NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frsisforeport_departemen` (`departemen`),
  KEY `FK_frsisforeport_tingkat` (`idtingkat`),
  CONSTRAINT `FK_frsisforeport_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frsisforeport_tingkat` FOREIGN KEY (`idtingkat`) REFERENCES `jbsakad`.`tingkat` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frsisforeport"
#


#
# Structure for table "frsisforeportemp"
#

DROP TABLE IF EXISTS `jbssat`.`frsisforeportemp`;
CREATE TABLE `jbssat`.`frsisforeportemp` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` int(10) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `startdate` tinyint(3) unsigned NOT NULL,
  `enddate` tinyint(3) unsigned NOT NULL,
  `h` int(10) unsigned NOT NULL,
  `i` int(10) unsigned NOT NULL,
  `s` int(10) unsigned NOT NULL,
  `c` int(10) unsigned NOT NULL,
  `a` int(10) unsigned NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frsisforeportemp"
#


#
# Structure for table "frabsence"
#

DROP TABLE IF EXISTS `jbssat`.`frabsence`;
CREATE TABLE `jbssat`.`frabsence` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(30) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `departemen` varchar(50) DEFAULT NULL,
  `idtingkat` int(10) unsigned DEFAULT NULL,
  `idkelas` int(10) unsigned DEFAULT NULL,
  `datenop` date NOT NULL,
  `status` varchar(7) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `idreportsisfo` int(10) unsigned DEFAULT NULL,
  `idreportsisfoemp` int(10) unsigned DEFAULT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frabsence_siswa` (`nis`),
  KEY `FK_frabsence_pegawai` (`nip`),
  KEY `FK_frabsence_frsisforeport` (`idreportsisfo`),
  KEY `FK_frabsence_departemen` (`departemen`),
  KEY `FK_frabsence_frsisforeportemp` (`idreportsisfoemp`),
  KEY `FK_frabsence_tingkat` (`idtingkat`),
  KEY `FK_frabsence_kelas` (`idkelas`),
  KEY `IX_freabsence` (`datenop`,`nip`,`nis`) USING BTREE,
  CONSTRAINT `FK_frabsence_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frabsence_frsisforeport` FOREIGN KEY (`idreportsisfo`) REFERENCES `jbssat`.`frsisforeport` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frabsence_frsisforeportemp` FOREIGN KEY (`idreportsisfoemp`) REFERENCES `jbssat`.`frsisforeportemp` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frabsence_kelas` FOREIGN KEY (`idkelas`) REFERENCES `jbsakad`.`kelas` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frabsence_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frabsence_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frabsence_tingkat` FOREIGN KEY (`idtingkat`) REFERENCES `jbsakad`.`tingkat` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frabsence"
#


#
# Structure for table "frpresence"
#

DROP TABLE IF EXISTS `jbssat`.`frpresence`;
CREATE TABLE `jbssat`.`frpresence` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(30) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `departemen` varchar(50) DEFAULT NULL,
  `idtingkat` int(10) unsigned DEFAULT NULL,
  `idkelas` int(10) unsigned DEFAULT NULL,
  `date_in` date NOT NULL,
  `time_in` varchar(10) NOT NULL,
  `frid_in` int(10) unsigned DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `time_out` varchar(10) DEFAULT NULL,
  `frid_out` int(10) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `smssent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `smssenthome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `source` varchar(2) NOT NULL DEFAULT 'F' COMMENT 'F -> Fingerprint, M -< Manual',
  `reportsisfo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `idreportsisfo` int(10) unsigned DEFAULT NULL,
  `idreportsisfoemp` int(10) unsigned DEFAULT NULL,
  `idpetugas` varchar(30) DEFAULT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_frpresence_frsisforeport` (`idreportsisfo`),
  KEY `FK_frpresence_pegawai` (`nip`),
  KEY `IX_frpresence_date` (`nis`,`nip`,`date_in`,`smssent`,`smssenthome`,`reportsisfo`) USING BTREE,
  KEY `FK_frpresence_departemen` (`departemen`),
  KEY `FK_frpresence_frsisforeportemp` (`idreportsisfoemp`),
  KEY `FK_frpresence_tingkat` (`idtingkat`),
  KEY `FK_frpresence_kelas` (`idkelas`),
  KEY `FK_frpresence_petugas` (`idpetugas`),
  KEY `FK_frpresence_frdata_in` (`frid_in`),
  KEY `FK_frpresence_frdata_out` (`frid_out`),
  CONSTRAINT `FK_frpresence_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_frdata_in` FOREIGN KEY (`frid_in`) REFERENCES `jbssat`.`frdata` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_frdata_out` FOREIGN KEY (`frid_out`) REFERENCES `jbssat`.`frdata` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_frsisforeport` FOREIGN KEY (`idreportsisfo`) REFERENCES `jbssat`.`frsisforeport` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_frsisforeportemp` FOREIGN KEY (`idreportsisfoemp`) REFERENCES `jbssat`.`frsisforeportemp` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_kelas` FOREIGN KEY (`idkelas`) REFERENCES `jbsakad`.`kelas` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_petugas` FOREIGN KEY (`idpetugas`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_frpresence_tingkat` FOREIGN KEY (`idtingkat`) REFERENCES `jbsakad`.`tingkat` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "frpresence"
#


#
# Structure for table "fruser"
#

DROP TABLE IF EXISTS `jbssat`.`fruser`;
CREATE TABLE `jbssat`.`fruser` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(45) NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `userlevel` tinyint(1) unsigned NOT NULL COMMENT '1 -> Manager, 2 -> Client',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `lastlogin` datetime DEFAULT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_fruser_pegawai` (`userid`),
  CONSTRAINT `FK_fruser_pegawai` FOREIGN KEY (`userid`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "fruser"
#


#
# Structure for table "fruseraccess"
#

DROP TABLE IF EXISTS `jbssat`.`fruseraccess`;
CREATE TABLE `jbssat`.`fruseraccess` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iduser` int(10) unsigned NOT NULL,
  `departemen` varchar(45) NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_fruseraccess_fruser` (`iduser`),
  KEY `FK_fruseraccess_departemen` (`departemen`),
  CONSTRAINT `FK_fruseraccess_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_fruseraccess_fruser` FOREIGN KEY (`iduser`) REFERENCES `jbssat`.`fruser` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "fruseraccess"
#

