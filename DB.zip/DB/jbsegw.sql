﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:48:19
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbsegw`;

#
# Structure for table "emailinfo"
#

DROP TABLE IF EXISTS `jbsegw`.`emailinfo`;
CREATE TABLE `jbsegw`.`emailinfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tanggal` datetime NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` mediumtext NOT NULL,
  `idfile` varchar(255) NOT NULL,
  `idlaporan` varchar(5) NOT NULL,
  `jenis` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Informasi 1 Laporan',
  `target` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Dept 1 Tingkat 2 Kelas 3 Kelompok 4 Kelompok Cs 5 Pegawai 6 Lainnya',
  `jenisjadwal` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Sekarang, 1 Terjadwal',
  `jadwal` datetime DEFAULT NULL,
  `pembuat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `cc` varchar(500) NOT NULL,
  `bcc` varchar(500) NOT NULL,
  `jenispenerima` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Semua, 1 Siswa saja, 2 Ortu saja',
  PRIMARY KEY (`id`),
  KEY `FK_emailinfo_pegawai` (`pembuat`),
  CONSTRAINT `FK_emailinfo_pegawai` FOREIGN KEY (`pembuat`) REFERENCES `jbssdm`.`pegawai` (`nip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "emailinfo"
#


#
# Structure for table "jadwal"
#

DROP TABLE IF EXISTS `jbsegw`.`jadwal`;
CREATE TABLE `jbsegw`.`jadwal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `target` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Siswa, 1 Calon Siswa, 2 Pegawai',
  `idlaporan` varchar(5) NOT NULL,
  `rentang` varchar(5) NOT NULL,
  `kelompoktarget` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Dept 1 Tingkat 2 Kelas 3 Kelompok 4 Kelompok Cs 5 Pegawai 6 Lainnya',
  `departemen` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `daftarpenerima` mediumtext,
  `bagianpegawai` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Semua, 1 Akademik, 2 Non Akademik',
  `kepada` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Semua, 1 Siswa saja, 2 Ortu saja',
  `email` mediumtext NOT NULL,
  `jsonjadwal` varchar(2000) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `aktif` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `pembuat` varchar(30) DEFAULT NULL,
  `tglbuat` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_jadwal_departemen` (`departemen`),
  CONSTRAINT `FK_jadwal_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "jadwal"
#


#
# Structure for table "jadwallog"
#

DROP TABLE IF EXISTS `jbsegw`.`jadwallog`;
CREATE TABLE `jbsegw`.`jadwallog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjadwal` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `keterangan` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_jadwallog_jadwal` (`idjadwal`),
  CONSTRAINT `FK_jadwallog_jadwal` FOREIGN KEY (`idjadwal`) REFERENCES `jbsegw`.`jadwal` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "jadwallog"
#


#
# Structure for table "kelompokpenerima"
#

DROP TABLE IF EXISTS `jbsegw`.`kelompokpenerima`;
CREATE TABLE `jbsegw`.`kelompokpenerima` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(100) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `deskripsi` varchar(2555) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_kelompokpenerima_departemen` (`departemen`),
  CONSTRAINT `FK_kkelompokpenerima_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "kelompokpenerima"
#


#
# Structure for table "emailinfotarget"
#

DROP TABLE IF EXISTS `jbsegw`.`emailinfotarget`;
CREATE TABLE `jbsegw`.`emailinfotarget` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idemailinfo` int(10) unsigned DEFAULT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `idtingkat` int(10) unsigned DEFAULT NULL,
  `idkelas` int(10) unsigned DEFAULT NULL,
  `idkelompok` int(10) unsigned DEFAULT NULL,
  `idkelompokcs` int(10) unsigned DEFAULT NULL,
  `bagianpegawai` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Semua 1 Akademik 2 Non Akademik',
  `userlist` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_emailinfotarget_departemen` (`departemen`),
  KEY `FK_emailinfotarget_tingkat` (`idtingkat`),
  KEY `FK_emailinfotarget_kelas` (`idkelas`),
  KEY `FK_emailinfotarget_kelompokpenerima` (`idkelompok`),
  KEY `FK_emailinfotarget_kelompokcs` (`idkelompokcs`),
  KEY `FK_emailinfotarget_emailinfo` (`idemailinfo`),
  CONSTRAINT `FK_emailinfotarget_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_emailinfotarget_emailinfo` FOREIGN KEY (`idemailinfo`) REFERENCES `jbsegw`.`emailinfo` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_emailinfotarget_kelas` FOREIGN KEY (`idkelas`) REFERENCES `jbsakad`.`kelas` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_emailinfotarget_kelompokcs` FOREIGN KEY (`idkelompokcs`) REFERENCES `jbsakad`.`kelompokcalonsiswa` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_emailinfotarget_kelompokpenerima` FOREIGN KEY (`idkelompok`) REFERENCES `jbsegw`.`kelompokpenerima` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_emailinfotarget_tingkat` FOREIGN KEY (`idtingkat`) REFERENCES `jbsakad`.`tingkat` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "emailinfotarget"
#


#
# Structure for table "anggota"
#

DROP TABLE IF EXISTS `jbsegw`.`anggota`;
CREATE TABLE `jbsegw`.`anggota` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkelompok` int(10) unsigned NOT NULL,
  `jenis` tinyint(1) unsigned NOT NULL COMMENT '0 Siswa, 1 Pegawai, 2 Other, 3 Calon Siswa',
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nic` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nouser` varchar(30) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_anggota_kelompokpeserta` (`idkelompok`),
  KEY `FK_anggota_siswa` (`nis`),
  KEY `FK_anggota_pegawai` (`nip`),
  KEY `FK_anggota_calonsiswa` (`nic`),
  CONSTRAINT `FK_anggota_calonsiswa` FOREIGN KEY (`nic`) REFERENCES `jbsakad`.`calonsiswa` (`nopendaftaran`) ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_kelompokpenerima` FOREIGN KEY (`idkelompok`) REFERENCES `jbsegw`.`kelompokpenerima` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "anggota"
#


#
# Structure for table "send"
#

DROP TABLE IF EXISTS `jbsegw`.`send`;
CREATE TABLE `jbsegw`.`send` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idemailinfo` int(10) unsigned NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` mediumtext NOT NULL,
  `idfileattach` varchar(500) NOT NULL,
  `kepada` varchar(500) NOT NULL,
  `cc` varchar(500) NOT NULL,
  `bcc` varchar(500) NOT NULL,
  `jadwalkirim` datetime NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `prio` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Reguler 1 Priority',
  `ntry` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IX_send` (`idemailinfo`,`jadwalkirim`,`status`,`prio`),
  CONSTRAINT `FK_send_emailinfo` FOREIGN KEY (`idemailinfo`) REFERENCES `jbsegw`.`emailinfo` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "send"
#


#
# Structure for table "sendhistory"
#

DROP TABLE IF EXISTS `jbsegw`.`sendhistory`;
CREATE TABLE `jbsegw`.`sendhistory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idemailinfo` int(10) unsigned NOT NULL,
  `idsend` int(10) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(255) NOT NULL,
  `isi` mediumtext NOT NULL,
  `idfileattach` varchar(500) NOT NULL,
  `kepada` varchar(500) NOT NULL,
  `cc` varchar(500) NOT NULL,
  `bcc` varchar(500) NOT NULL,
  `jadwalkirim` datetime NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `prio` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Reguler 1 Priority',
  `info` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_sendsendhistory_emailinfo` (`idemailinfo`),
  KEY `IX_sendhistory` (`idemailinfo`,`idsend`),
  CONSTRAINT `FK_sendhistory_emailinfo` FOREIGN KEY (`idemailinfo`) REFERENCES `jbsegw`.`emailinfo` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "sendhistory"
#


#
# Structure for table "signature"
#

DROP TABLE IF EXISTS `jbsegw`.`signature`;
CREATE TABLE `jbsegw`.`signature` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `signature` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "signature"
#

INSERT INTO `signature` VALUES (1,' ');
