﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:48:50
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbsfina`;

#
# Structure for table "auditbesarjttcalon"
#

DROP TABLE IF EXISTS `jbsfina`.`auditbesarjttcalon`;
CREATE TABLE `jbsfina`.`auditbesarjttcalon` (
  `statusdata` tinyint(1) NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idcalon` int(10) unsigned NOT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `besar` decimal(15,0) NOT NULL,
  `lunas` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keterangan` varchar(255) DEFAULT NULL,
  `pengguna` varchar(100) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditbesarjttcalon_auditinfo` (`idaudit`),
  KEY `IX_auditbesarjttcalon_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditbesarjttcalon_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditbesarjttcalon"
#


#
# Structure for table "auditinfo"
#

DROP TABLE IF EXISTS `jbsfina`.`auditinfo`;
CREATE TABLE `jbsfina`.`auditinfo` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sumber` varchar(100) NOT NULL,
  `idsumber` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `petugas` varchar(100) NOT NULL,
  `departemen` varchar(50) NOT NULL,
  `alasan` varchar(500) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_auditinfo_departemen` (`departemen`),
  KEY `IX_auditinfo_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditinfo_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

#
# Data for table "auditinfo"
#

INSERT INTO `auditinfo` VALUES (1,'besarjtt',53,'2021-04-03 11:06:47','Rika Erliani Harahap S. Hum','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-03 11:06:47',0,0),(2,'besarjtt',582,'2021-04-03 12:00:47','Rika Erliani Harahap S. Hum','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-03 12:00:47',0,0),(3,'besarjtt',582,'2021-04-03 12:04:01','Rika Erliani Harahap S. Hum','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-03 12:04:01',0,0),(4,'besarjtt',583,'2021-04-03 12:16:22','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-03 12:16:22',0,0),(5,'besarjtt',583,'2021-04-03 12:17:57','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-03 12:17:57',0,0),(6,'besarjtt',595,'2021-04-04 09:23:59','Rika Erliani Harahap S. Hum','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-04 09:23:59',0,0),(7,'besarjtt',624,'2021-04-05 10:03:59','Rika Erliani Harahap S. Hum','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-05 10:03:59',0,0),(8,'besarjtt',624,'2021-04-05 10:05:35','Rika Erliani Harahap S. Hum','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-05 10:05:35',0,0),(9,'besarjtt',638,'2021-04-05 20:42:41','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-05 20:42:41',0,0),(10,'besarjtt',653,'2021-04-05 22:05:08','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-05 22:05:08',0,0),(11,'besarjtt',638,'2021-04-07 15:31:49','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-07 15:31:49',0,0),(12,'besarjtt',674,'2021-04-15 13:32:53','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-15 13:32:53',0,0),(13,'besarjtt',702,'2021-04-16 19:11:49','Jahratul Jannah','TSANAWIYAH','',NULL,NULL,NULL,'2021-04-16 19:11:49',0,0),(14,'besarjtt',776,'2021-07-12 21:35:58','Jahratul Jannah S.Pd','ALIYAH','',NULL,NULL,NULL,'2021-07-12 21:35:58',0,0);

#
# Structure for table "auditbesarjtt"
#

DROP TABLE IF EXISTS `jbsfina`.`auditbesarjtt`;
CREATE TABLE `jbsfina`.`auditbesarjtt` (
  `statusdata` tinyint(1) NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `nis` varchar(20) NOT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `besar` decimal(15,0) NOT NULL,
  `lunas` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keterangan` varchar(255) DEFAULT NULL,
  `pengguna` varchar(100) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditbesarjtt_auditinfo` (`idaudit`),
  KEY `IX_auditbesarjtt_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditbesarjtt_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditbesarjtt"
#

INSERT INTO `auditbesarjtt` VALUES (0,1,53,'20.3415',16,7200000,0,'SUDAH  BAYAR SAMPAI BULAN MARET 2021 DI BUKU KUNING','Rika Erliani Harahap S. Hum','105','2',NULL,'2021-04-03 11:06:47',0,0),(1,1,53,'20.3415',16,7200000,0,'SUDAH  BAYAR SAMPAI BULAN MARET 2021 DI BUKU KUNING','Rika Erliani Harahap S. Hum','105','2',NULL,'2021-04-03 11:06:47',0,0),(0,2,582,'20.3425',16,4500000,0,'','Rika Erliani Harahap S. Hum','868','2',NULL,'2021-04-03 12:00:47',0,0),(1,2,582,'20.3425',16,4500000,0,'DAPAT DISPEN KURANG MAMPU, DARI BULAN OKTOBER','Rika Erliani Harahap S. Hum','868','2',NULL,'2021-04-03 12:00:47',0,0),(0,3,582,'20.3425',16,4500000,0,'DAPAT DISPEN KURANG MAMPU, DARI BULAN OKTOBER','Rika Erliani Harahap S. Hum','868','2',NULL,'2021-04-03 12:04:01',0,0),(1,3,582,'20.3425',16,4500000,0,'DAPAT DISPEN KURANG MAMPU, DARI BULAN OKTOBER','Rika Erliani Harahap S. Hum','868','2',NULL,'2021-04-03 12:04:01',0,0),(0,4,583,'19.3013',16,6900000,0,'SANTRI DISPEN Rp. 200.000 KURANG MAMPU','Jahratul Jannah','870','2',NULL,'2021-04-03 12:16:22',0,0),(1,4,583,'19.3013',16,5400000,0,'SANTRI DISPEN Rp. 200.000 KURANG MAMPU','Jahratul Jannah','870','2',NULL,'2021-04-03 12:16:22',0,0),(0,5,583,'19.3013',16,5400000,0,'SANTRI DISPEN Rp. 200.000 KURANG MAMPU','Jahratul Jannah','870','2',NULL,'2021-04-03 12:17:57',0,0),(1,5,583,'19.3013',16,5100000,0,'SANTRI DISPEN Rp. 200.000 KURANG MAMPU','Jahratul Jannah','870','2',NULL,'2021-04-03 12:17:57',0,0),(0,6,595,'20.3436',16,7200000,0,'','Rika Erliani Harahap S. Hum','894','2',NULL,'2021-04-04 09:23:59',0,0),(1,6,595,'20.3436',16,7200000,0,'lunas','Rika Erliani Harahap S. Hum','894','2',NULL,'2021-04-04 09:23:59',0,0),(0,7,624,'20.3836',16,7200000,0,'','Rika Erliani Harahap S. Hum','953','2',NULL,'2021-04-05 10:03:59',0,0),(1,7,624,'20.3836',16,6600000,0,'Baru Masuk di Bulan Agustus','Rika Erliani Harahap S. Hum','953','2',NULL,'2021-04-05 10:03:59',0,0),(0,8,624,'20.3836',16,6600000,0,'Baru Masuk di Bulan Agustus','Rika Erliani Harahap S. Hum','953','2',NULL,'2021-04-05 10:05:35',0,0),(1,8,624,'20.3836',16,6600000,0,'Baru Masuk di Bulan Agustus','Rika Erliani Harahap S. Hum','953','2',NULL,'2021-04-05 10:05:35',0,0),(0,9,638,'19.3040',16,6900000,0,'','Jahratul Jannah','980','2',NULL,'2021-04-05 20:42:41',0,0),(1,9,638,'19.3040',16,6290000,0,'','Jahratul Jannah','980','2',NULL,'2021-04-05 20:42:41',0,0),(0,10,653,'19.3215',16,5100000,1,'','Jahratul Jannah','1009','2',NULL,'2021-04-05 22:05:08',0,0),(1,10,653,'19.3215',16,6900000,0,'','Jahratul Jannah','1009','2',NULL,'2021-04-05 22:05:08',0,0),(0,11,638,'19.3040',16,6290000,0,'','Jahratul Jannah','980','2',NULL,'2021-04-07 15:31:49',0,0),(1,11,638,'19.3040',16,6290000,0,'DIESPEN 50.000','Jahratul Jannah','980','2',NULL,'2021-04-07 15:31:49',0,0),(0,12,674,'19.3228',16,6900000,0,'','Jahratul Jannah','1063','2',NULL,'2021-04-15 13:32:53',0,0),(1,12,674,'19.3228',16,6900000,0,'','Jahratul Jannah','1063','2',NULL,'2021-04-15 13:32:53',0,0),(0,13,702,'19.3060',16,6900000,0,'','Jahratul Jannah','1119','2',NULL,'2021-04-16 19:11:49',0,0),(1,13,702,'19.3060',16,6310000,0,'','Jahratul Jannah','1119','2',NULL,'2021-04-16 19:11:49',0,0),(0,14,776,'20.2484',15,7200000,0,'','Jahratul Jannah S.Pd','1270','1',NULL,'2021-07-12 21:35:58',0,0),(1,14,776,'20.2484',15,7200000,0,'','Jahratul Jannah S.Pd','1270','1',NULL,'2021-07-12 21:35:58',0,0);

#
# Structure for table "auditjurnal"
#

DROP TABLE IF EXISTS `jbsfina`.`auditjurnal`;
CREATE TABLE `jbsfina`.`auditjurnal` (
  `status` tinyint(1) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `transaksi` varchar(255) NOT NULL,
  `petugas` varchar(100) NOT NULL,
  `nokas` varchar(100) NOT NULL,
  `idtahunbuku` int(10) unsigned NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `sumber` varchar(40) NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditjurnal_auditinfo` (`idaudit`),
  KEY `IX_auditjurnal_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditjurnal_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

#
# Data for table "auditjurnal"
#


#
# Structure for table "auditjurnaldetail"
#

DROP TABLE IF EXISTS `jbsfina`.`auditjurnaldetail`;
CREATE TABLE `jbsfina`.`auditjurnaldetail` (
  `status` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjurnal` int(10) unsigned NOT NULL,
  `koderek` varchar(15) NOT NULL,
  `debet` decimal(15,0) NOT NULL DEFAULT '0',
  `kredit` decimal(15,0) NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_auditjurnaldetail_auditinfo` (`idaudit`),
  KEY `IX_auditjurnaldetail_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditjurnaldetail_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditjurnaldetail"
#


#
# Structure for table "auditpenerimaaniuran"
#

DROP TABLE IF EXISTS `jbsfina`.`auditpenerimaaniuran`;
CREATE TABLE `jbsfina`.`auditpenerimaaniuran` (
  `statusdata` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `nis` varchar(20) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditpenerimaaniuran_auditinfo` (`idaudit`),
  KEY `IX_auditpenerimaaniuran_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditpenerimaaniuran_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditpenerimaaniuran"
#


#
# Structure for table "auditpenerimaaniurancalon"
#

DROP TABLE IF EXISTS `jbsfina`.`auditpenerimaaniurancalon`;
CREATE TABLE `jbsfina`.`auditpenerimaaniurancalon` (
  `statusdata` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `idcalon` int(10) unsigned NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditpenerimaaniurancalon_audit` (`idaudit`),
  KEY `IX_auditpenerimaaniurancalon_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditpenerimaaniurancalon_audit` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditpenerimaaniurancalon"
#


#
# Structure for table "auditpenerimaanjtt"
#

DROP TABLE IF EXISTS `jbsfina`.`auditpenerimaanjtt`;
CREATE TABLE `jbsfina`.`auditpenerimaanjtt` (
  `statusdata` tinyint(1) NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idbesarjtt` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditpenerimaanjtt_auditinfo` (`idaudit`),
  KEY `IX_auditpenerimaanjtt_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditpenerimaanjtt_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditpenerimaanjtt"
#


#
# Structure for table "auditpenerimaanjttcalon"
#

DROP TABLE IF EXISTS `jbsfina`.`auditpenerimaanjttcalon`;
CREATE TABLE `jbsfina`.`auditpenerimaanjttcalon` (
  `statusdata` tinyint(1) NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idbesarjttcalon` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditpenerimaanjttcalon_auditinfo` (`idaudit`),
  KEY `IX_auditpenerimaanjttcalon_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditpenerimaanjttcalon_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditpenerimaanjttcalon"
#


#
# Structure for table "auditpenerimaanlain"
#

DROP TABLE IF EXISTS `jbsfina`.`auditpenerimaanlain`;
CREATE TABLE `jbsfina`.`auditpenerimaanlain` (
  `statusdata` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `sumber` varchar(100) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditpenerimaanlain_auditinfo` (`idaudit`),
  KEY `IX_auditpenerimaanlain_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditpenerimaanlain_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditpenerimaanlain"
#


#
# Structure for table "auditpengeluaran"
#

DROP TABLE IF EXISTS `jbsfina`.`auditpengeluaran`;
CREATE TABLE `jbsfina`.`auditpengeluaran` (
  `statusdata` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `replid` int(10) unsigned NOT NULL,
  `idpengeluaran` int(10) unsigned NOT NULL,
  `keperluan` varchar(255) NOT NULL,
  `jenispemohon` tinyint(1) unsigned NOT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `pemohonlain` int(10) unsigned DEFAULT NULL,
  `penerima` varchar(100) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `tanggalkeluar` datetime NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `petugas` varchar(45) DEFAULT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `keterangan` text,
  `namapemohon` varchar(100) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_auditpengeluaran_auditinfo` (`idaudit`),
  KEY `IX_auditpengeluaran_ts` (`ts`,`issync`),
  CONSTRAINT `FK_auditpengeluaran_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "auditpengeluaran"
#


#
# Structure for table "audittabungan"
#

DROP TABLE IF EXISTS `jbsfina`.`audittabungan`;
CREATE TABLE `jbsfina`.`audittabungan` (
  `statusdata` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `idtabungan` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `nis` varchar(20) CHARACTER SET utf8 NOT NULL,
  `debet` decimal(15,0) NOT NULL,
  `kredit` decimal(15,0) NOT NULL,
  `petugas` varchar(30) CHARACTER SET utf8 NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_audittabungan_auditinfo` (`idaudit`),
  CONSTRAINT `FK_audittabungan_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "audittabungan"
#


#
# Structure for table "audittabunganp"
#

DROP TABLE IF EXISTS `jbsfina`.`audittabunganp`;
CREATE TABLE `jbsfina`.`audittabunganp` (
  `statusdata` tinyint(1) unsigned NOT NULL,
  `idaudit` int(10) unsigned NOT NULL,
  `idtabungan` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `nip` varchar(20) CHARACTER SET utf8 NOT NULL,
  `debet` decimal(15,0) NOT NULL,
  `kredit` decimal(15,0) NOT NULL,
  `petugas` varchar(30) CHARACTER SET utf8 NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `FK_audittabunganp_auditinfo` (`idaudit`),
  CONSTRAINT `FK_audittabunganp_auditinfo` FOREIGN KEY (`idaudit`) REFERENCES `jbsfina`.`auditinfo` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "audittabunganp"
#


#
# Structure for table "autotrans"
#

DROP TABLE IF EXISTS `jbsfina`.`autotrans`;
CREATE TABLE `jbsfina`.`autotrans` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `kelompok` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 Siswa, 2 Calon Siswa',
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `urutan` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `smsinfo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_autotrans_departemen` (`departemen`),
  CONSTRAINT `FK_autotrans_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "autotrans"
#


#
# Structure for table "datadsp"
#

DROP TABLE IF EXISTS `jbsfina`.`datadsp`;
CREATE TABLE `jbsfina`.`datadsp` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) NOT NULL,
  `dsp` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `operator` varchar(50) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_datadsp_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "datadsp"
#


#
# Structure for table "formatsms"
#

DROP TABLE IF EXISTS `jbsfina`.`formatsms`;
CREATE TABLE `jbsfina`.`formatsms` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jenis` varchar(10) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `format` varchar(255) NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`) USING BTREE,
  KEY `FK_formatsms_departemen` (`departemen`),
  KEY `IX_formatsms` (`jenis`),
  CONSTRAINT `FK_formatsms_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

#
# Data for table "formatsms"
#

INSERT INTO `formatsms` VALUES (1,'SISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(2,'CSISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(3,'SISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(8,'CSISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(13,'SISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(18,'CSISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(23,'SISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(24,'CSISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(25,'SISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(26,'CSISPAY','SMA','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL),(27,'SISPAY','TSANAWIYAH','Terima kasih, kami telah menerima pembayaran dari {NAMA} tanggal {TANGGAL} sebesar {BESAR} untuk {PEMBAYARAN} - Bag. Keuangan',NULL,NULL,NULL);

#
# Structure for table "groupbarang"
#

DROP TABLE IF EXISTS `jbsfina`.`groupbarang`;
CREATE TABLE `jbsfina`.`groupbarang` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keterangan` varchar(45) DEFAULT NULL,
  `namagroup` varchar(45) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_groupbarang_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "groupbarang"
#


#
# Structure for table "kategoripenerimaan"
#

DROP TABLE IF EXISTS `jbsfina`.`kategoripenerimaan`;
CREATE TABLE `jbsfina`.`kategoripenerimaan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(10) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `urutan` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `siswa` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`kode`),
  UNIQUE KEY `Index_1` (`replid`),
  KEY `IX_kategoripenerimaan_ts` (`ts`,`issync`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Data for table "kategoripenerimaan"
#

INSERT INTO `kategoripenerimaan` VALUES (4,'CSSKR','Iuran Sukarela Calon Siswa',4,1,NULL,NULL,NULL,'2010-03-02 10:06:52',31230,0),(3,'CSWJB','Iuran Wajib Calon Siswa',3,1,NULL,NULL,NULL,'2010-03-02 10:06:52',37247,0),(1,'JTT','Iuran Wajib Siswa',1,1,NULL,NULL,NULL,'2010-03-02 10:06:52',27011,0),(5,'LNN','Penerimaan Lainnya',5,1,NULL,NULL,NULL,'2010-03-02 10:06:52',23315,0),(2,'SKR','Iuran Sukarela Siswa',2,1,NULL,NULL,NULL,'2010-03-02 10:06:52',35541,0);

#
# Structure for table "katerekakun"
#

DROP TABLE IF EXISTS `jbsfina`.`katerekakun`;
CREATE TABLE `jbsfina`.`katerekakun` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) NOT NULL,
  `urutan` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`kategori`),
  UNIQUE KEY `Index_1` (`replid`),
  KEY `IX_katerekakun_ts` (`ts`,`issync`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

#
# Data for table "katerekakun"
#

INSERT INTO `katerekakun` VALUES (7,'BIAYA',7,NULL,NULL,NULL,'2010-03-02 10:06:52',42231,0),(1,'HARTA',1,NULL,NULL,NULL,'2010-03-02 10:06:52',38999,0),(3,'INVENTARIS',3,NULL,NULL,NULL,'2010-03-02 10:06:52',2775,0),(5,'MODAL',5,NULL,NULL,NULL,'2010-03-02 10:06:52',27935,0),(6,'PENDAPATAN',6,NULL,NULL,NULL,'2010-03-02 10:06:52',289,0),(2,'PIUTANG',2,NULL,NULL,NULL,'2010-03-02 10:06:52',48701,0),(4,'UTANG',4,NULL,NULL,NULL,'2010-03-02 10:06:52',46047,0);

#
# Structure for table "kelompokbarang"
#

DROP TABLE IF EXISTS `jbsfina`.`kelompokbarang`;
CREATE TABLE `jbsfina`.`kelompokbarang` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(255) NOT NULL,
  `keterangan` varchar(45) DEFAULT NULL,
  `idgroup` int(10) unsigned NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_kelompokbarang_group` (`idgroup`),
  KEY `IX_kelompokbarang_ts` (`ts`,`issync`),
  CONSTRAINT `FK_kelompokbarang_group` FOREIGN KEY (`idgroup`) REFERENCES `jbsfina`.`groupbarang` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "kelompokbarang"
#


#
# Structure for table "barang"
#

DROP TABLE IF EXISTS `jbsfina`.`barang`;
CREATE TABLE `jbsfina`.`barang` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkelompok` int(10) unsigned NOT NULL,
  `kode` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kondisi` varchar(255) DEFAULT NULL,
  `jumlah` int(10) NOT NULL DEFAULT '0',
  `tglperolehan` date NOT NULL DEFAULT '0000-00-00',
  `foto` blob,
  `keterangan` varchar(255) DEFAULT NULL,
  `satuan` varchar(20) DEFAULT 'unit',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_barang_kelompok` (`idkelompok`),
  KEY `IX_barang_ts` (`ts`,`issync`),
  CONSTRAINT `FK_barang_kelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbsfina`.`kelompokbarang` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "barang"
#


#
# Structure for table "paymentid"
#

DROP TABLE IF EXISTS `jbsfina`.`paymentid`;
CREATE TABLE `jbsfina`.`paymentid` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jenis` tinyint(3) unsigned NOT NULL COMMENT '1 Pegawai, 2 Siswa',
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `paymentid` varchar(10) NOT NULL,
  `tanggal` datetime NOT NULL,
  `aktif` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`replid`),
  KEY `FK_paymentid_siswa` (`nis`),
  KEY `FK_paymentid_pegawai` (`nip`),
  CONSTRAINT `FK_paymentid_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymentid_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "paymentid"
#


#
# Structure for table "pemohonlain"
#

DROP TABLE IF EXISTS `jbsfina`.`pemohonlain`;
CREATE TABLE `jbsfina`.`pemohonlain` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `IX_pemohonlain_ts` (`ts`,`issync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "pemohonlain"
#


#
# Structure for table "pengguna"
#

DROP TABLE IF EXISTS `jbsfina`.`pengguna`;
CREATE TABLE `jbsfina`.`pengguna` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nip` varchar(30) NOT NULL,
  `tingkat` tinyint(1) unsigned NOT NULL,
  `departemen` varchar(50) CHARACTER SET latin1 NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pengguna_pegawai` (`nip`),
  KEY `IX_pengguna_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pengguna_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "pengguna"
#


#
# Structure for table "rekakun"
#

DROP TABLE IF EXISTS `jbsfina`.`rekakun`;
CREATE TABLE `jbsfina`.`rekakun` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(15) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`kode`),
  UNIQUE KEY `UX_rekakun` (`replid`),
  KEY `FK_rekakun_katerekakun` (`kategori`),
  KEY `IX_rekakun_ts` (`ts`,`issync`),
  CONSTRAINT `FK_rekakun_katerekakun` FOREIGN KEY (`kategori`) REFERENCES `jbsfina`.`katerekakun` (`kategori`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

#
# Data for table "rekakun"
#

INSERT INTO `rekakun` VALUES (1,'111','HARTA','Kas','Kas yang ada disekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',18600,0),(2,'112','HARTA','Kas Bank','Kas yang ada di bank yang digunakan sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',20390,0),(3,'113','HARTA','Kas BOS','Kas yang diterima dari sumbangan Bantuan Operasional Sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',46147,0),(4,'150','PIUTANG','Piutang Siswa','Piutang siswa kepada sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',38508,0),(5,'151','PIUTANG','Piutang Karyawan','Piutang karyawan kepada sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',54096,0),(6,'152','PIUTANG','Piutang Usaha','Piutang yang lain kepada sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',23895,0),(24,'153','PIUTANG','Piutang Calon Siswa','',NULL,NULL,NULL,'2012-01-02 07:58:13',0,0),(27,'154','PIUTANG','Piutang BOS','',NULL,NULL,NULL,'2012-01-02 08:00:51',0,0),(7,'411','PENDAPATAN','Pendapatan SPP','Pendapatan dari pembayaran SPP siswa',NULL,NULL,NULL,'2010-03-02 10:06:53',22719,0),(8,'412','PENDAPATAN','Pendapatan DSP','Pendapatan dari pembayaran DSP siswa',NULL,NULL,NULL,'2010-03-02 10:06:53',41907,0),(9,'413','PENDAPATAN','Pendapatan Sukarela Siswa','Pendapatan dari perolehan dana sukarela',NULL,NULL,NULL,'2010-03-02 10:06:53',10317,0),(10,'414','PENDAPATAN','Pendapatan BOS','Pendaptan dari penerimaan sumbangan Bantuan Operasional Sekolah (BOS)',NULL,NULL,NULL,'2010-03-02 10:06:53',56924,0),(25,'415','PENDAPATAN','Pendapatan Sukarela Calon Siswa','',NULL,NULL,NULL,'2012-01-02 07:58:41',0,0),(20,'421','PENDAPATAN','Diskon SPP','',NULL,NULL,NULL,'2012-01-02 07:14:27',0,0),(21,'422','PENDAPATAN','Diskon DSP','',NULL,NULL,NULL,'2012-01-02 07:56:29',0,0),(22,'423','PENDAPATAN','Diskon Sukarela Siswa','',NULL,NULL,NULL,'2012-01-02 07:56:43',0,0),(23,'424','PENDAPATAN','Diskon BOS','',NULL,NULL,NULL,'2012-01-02 07:56:53',0,0),(26,'425','PENDAPATAN','Diskon Sukarela Calon Siswa','',NULL,NULL,NULL,'2012-01-02 07:59:15',0,0),(11,'500','BIAYA','Beban Transportasi','Beban yang dikeluarkan untuk pembiayaan transportasi',NULL,NULL,NULL,'2010-03-02 10:06:53',57077,0),(12,'501','BIAYA','Beban Listrik','Beban yang dikeluarkan untuk melunasi tagihan PLN',NULL,NULL,NULL,'2010-03-02 10:06:53',49084,0),(13,'502','BIAYA','Beban Telpon','Beban yang dikeluarkan untuk pembiayaan tagihan telpon',NULL,NULL,NULL,'2010-03-02 10:06:53',8658,0),(14,'503','BIAYA','Beban Internet','Beban yang dikeluarkan untuk pembiayaan taghan Internet',NULL,NULL,NULL,'2010-03-02 10:06:53',27097,0),(15,'504','BIAYA','Beban ATK','Beban yang dikeluarkan untuk pembelian rutin ATK',NULL,NULL,NULL,'2010-03-02 10:06:53',43981,0),(16,'611','INVENTARIS','Peralatan Mengajar','Inventaris alat-alat kegiatan belajar mengajar',NULL,NULL,NULL,'2010-03-02 10:06:53',7554,0),(17,'612','INVENTARIS','Kendaraan','Inventaris kendaraan sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',36888,0),(18,'700','MODAL','Modal Usaha','Modal yang ditanamkan oleh pemodal kepada sekolah',NULL,NULL,NULL,'2010-03-02 10:06:53',30715,0),(19,'900','UTANG','Utang Usaha','Utang sekolah kepada kreditur',NULL,NULL,NULL,'2010-03-02 10:06:53',42913,0);

#
# Structure for table "datapenerimaan"
#

DROP TABLE IF EXISTS `jbsfina`.`datapenerimaan`;
CREATE TABLE `jbsfina`.`datapenerimaan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `besar` decimal(15,0) DEFAULT NULL,
  `idkategori` varchar(15) NOT NULL,
  `rekkas` varchar(15) NOT NULL,
  `rekpendapatan` varchar(15) NOT NULL,
  `rekpiutang` varchar(15) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `departemen` varchar(50) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_datapenerimaan_rekakun_kas` (`rekkas`),
  KEY `FK_datapenerimaan_rekakun_pendapatan` (`rekpendapatan`),
  KEY `FK_datapenerimaan_rekakun_piutang` (`rekpiutang`),
  KEY `FK_datapenerimaan_kategoripenerimaan` (`idkategori`),
  KEY `FK_datapenerimaan_departemen` (`departemen`),
  KEY `IX_datapenerimaan_ts` (`ts`,`issync`),
  CONSTRAINT `FK_datapenerimaan_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datapenerimaan_kategoripenerimaan` FOREIGN KEY (`idkategori`) REFERENCES `jbsfina`.`kategoripenerimaan` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datapenerimaan_rekakun_kas` FOREIGN KEY (`rekkas`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datapenerimaan_rekakun_pendapatan` FOREIGN KEY (`rekpendapatan`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datapenerimaan_rekakun_piutang` FOREIGN KEY (`rekpiutang`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

#
# Data for table "datapenerimaan"
#

INSERT INTO `datapenerimaan` VALUES (9,'SPP Bulanan',NULL,'JTT','111','411','150',1,'Sekedar contoh. Menu ini mengatur setiap jenis penerimaan yang mungkin diterima sekolah. Anda harus menentukan rekening Kas, Pendapatan dan Piutang untuk setiap transaksi penerimaan.','SMA','421',NULL,NULL,'2012-01-02 07:14:49',41237,0),(11,'Dana Sumbangan Pendidikan',NULL,'CSWJB','111','412','153',1,'Sekedar contoh. Menu ini mengatur setiap jenis penerimaan yang mungkin diterima sekolah. Anda harus menentukan rekening Kas, Pendapatan dan Piutang untuk setiap transaksi penerimaan.','SMA','422',NULL,NULL,'2012-01-02 07:59:59',12756,0),(12,'Sumbangan BOS',NULL,'LNN','113','414','154',1,'Sekedar contoh. Menu ini mengatur setiap jenis penerimaan yang mungkin diterima sekolah. Anda harus menentukan rekening Kas, Pendapatan dan Piutang untuk setiap transaksi penerimaan.','SMA','424',NULL,NULL,'2012-01-02 08:01:04',5601,0),(13,'Tabungan Siswa',NULL,'SKR','112','413','150',1,'Sekedar contoh. Menu ini mengatur setiap jenis penerimaan yang mungkin diterima sekolah. Anda harus menentukan rekening Kas, Pendapatan dan Piutang untuk setiap transaksi penerimaan.','SMA','423',NULL,NULL,'2012-01-02 07:57:14',55264,0),(14,'Sumbangan Pendidikan',NULL,'CSSKR','112','415','153',1,'Sekedar contoh. Menu ini mengatur setiap jenis penerimaan yang mungkin diterima sekolah. Anda harus menentukan rekening Kas, Pendapatan dan Piutang untuk setiap transaksi penerimaan.','SMA','425',NULL,NULL,'2012-01-02 07:59:39',62929,0),(15,'SPP Bulanan MA',NULL,'JTT','111','411','150',1,'','ALIYAH','421','0',NULL,'2021-04-01 23:02:51',33198,0),(16,'SPP Bulanan MTs',NULL,'JTT','111','411','150',1,'','TSANAWIYAH','421','0',NULL,'2021-04-01 23:03:43',7875,0),(17,'Dana Sumbangan Pembangunan',NULL,'CSWJB','111','412','153',1,'','SD IP','422','0',NULL,'2021-04-01 23:05:02',40008,0);

#
# Structure for table "besarjttcalon"
#

DROP TABLE IF EXISTS `jbsfina`.`besarjttcalon`;
CREATE TABLE `jbsfina`.`besarjttcalon` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idcalon` int(10) unsigned NOT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `besar` decimal(15,0) NOT NULL,
  `cicilan` decimal(15,0) NOT NULL DEFAULT '0',
  `lunas` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keterangan` varchar(255) DEFAULT NULL,
  `pengguna` varchar(100) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_besarjttcalon_penerimaan` (`idpenerimaan`),
  KEY `FK_besarjttcalon_calonsiswa` (`idcalon`),
  KEY `IX_besarjttcalon_ts` (`ts`,`issync`),
  CONSTRAINT `FK_besarjttcalon_calonsiswa` FOREIGN KEY (`idcalon`) REFERENCES `jbsakad`.`calonsiswa` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_besarjttcalon_penerimaan` FOREIGN KEY (`idpenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "besarjttcalon"
#


#
# Structure for table "besarjtt"
#

DROP TABLE IF EXISTS `jbsfina`.`besarjtt`;
CREATE TABLE `jbsfina`.`besarjtt` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) NOT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `besar` decimal(15,0) NOT NULL,
  `cicilan` decimal(15,0) NOT NULL DEFAULT '0',
  `lunas` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keterangan` varchar(255) DEFAULT NULL,
  `pengguna` varchar(100) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pembayaranjtt_siswa` (`nis`),
  KEY `FK_pembayaranjtt_penerimaan` (`idpenerimaan`),
  KEY `IX_besarjtt_ts` (`ts`,`issync`),
  CONSTRAINT `FK_besarjtt_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pembayaranjtt_penerimaan` FOREIGN KEY (`idpenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=777 DEFAULT CHARSET=utf8;

#
# Data for table "besarjtt"
#

INSERT INTO `besarjtt` VALUES (36,'19.2243',15,6600000,600000,0,'','Supria Ningsih','71','1',NULL,'2021-04-01 23:07:10',16612,0),(37,'19.2245',15,6600000,600000,0,'','Supria Ningsih','73','1',NULL,'2021-04-01 23:07:10',45536,0),(38,'19.2246',15,6600000,600000,0,'','Supria Ningsih','75','1',NULL,'2021-04-01 23:07:10',60368,0),(39,'19.2247',15,6600000,600000,0,'','Supria Ningsih','77','1',NULL,'2021-04-01 23:07:10',16343,0),(40,'19.2250',15,6600000,600000,0,'','Supria Ningsih','79','1',NULL,'2021-04-01 23:07:10',29311,0),(41,'19.2254',15,6600000,600000,0,'','Supria Ningsih','81','1',NULL,'2021-04-01 23:07:10',16631,0),(42,'19.2256',15,6600000,600000,0,'','Supria Ningsih','83','1',NULL,'2021-04-01 23:07:10',52194,0),(43,'19.2259',15,6600000,600000,0,'','Supria Ningsih','85','1',NULL,'2021-04-01 23:07:10',55635,0),(44,'19.2260',15,6600000,600000,0,'','Supria Ningsih','87','1',NULL,'2021-04-01 23:07:10',63081,0),(45,'19.2261',15,6600000,600000,0,'','Supria Ningsih','89','1',NULL,'2021-04-01 23:07:10',42510,0),(46,'19.2263',15,6600000,600000,0,'','Supria Ningsih','91','1',NULL,'2021-04-01 23:07:10',43370,0),(47,'19.2278',15,6600000,600000,0,'','Supria Ningsih','93','1',NULL,'2021-04-01 23:07:10',48261,0),(48,'19.2281',15,6600000,600000,0,'','Supria Ningsih','95','1',NULL,'2021-04-01 23:07:10',2374,0),(49,'19.2283',15,6600000,600000,0,'','Supria Ningsih','97','1',NULL,'2021-04-01 23:07:10',3934,0),(50,'19.2288',15,6600000,600000,0,'','Supria Ningsih','99','1',NULL,'2021-04-01 23:07:10',53383,0),(51,'19.2290',15,6600000,600000,0,'','Supria Ningsih','101','1',NULL,'2021-04-01 23:07:10',61449,0),(52,'19.2298',15,6600000,600000,0,'','Supria Ningsih','103','1',NULL,'2021-04-01 23:07:10',31784,0),(53,'20.3415',16,7200000,600000,0,'SUDAH  BAYAR SAMPAI BULAN MARET 2021 DI BUKU KUNING','Rika Erliani Harahap S. Hum','105','2','','2021-04-03 11:06:47',6504,0),(54,'20.3417',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','107','2',NULL,'2021-04-03 11:14:51',50337,0),(55,'20.3418',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','109','2',NULL,'2021-04-03 11:21:54',24494,0),(56,'20.3420',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','111','2',NULL,'2021-04-03 11:28:00',23640,0),(511,'20.3421',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','794','2',NULL,'2021-04-03 11:36:53',48597,0),(512,'19.3010',16,6900000,600000,0,'SUDAH MEMBAYAR DARI JULI SAMPAI DENGAN FEBRUARI','Jahratul Jannah','795','2',NULL,'2021-04-03 11:38:48',35969,0),(513,'20.3422',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','797','2',NULL,'2021-04-03 11:40:05',62242,0),(581,'19.3012',16,6900000,600000,0,'','Jahratul Jannah','866','2',NULL,'2021-04-03 11:46:51',33747,0),(582,'20.3425',16,4500000,300000,0,'DAPAT DISPEN KURANG MAMPU, DARI BULAN OKTOBER','Rika Erliani Harahap S. Hum','868','2','','2021-04-03 12:04:01',57641,0),(583,'19.3013',16,5100000,400000,0,'SANTRI DISPEN Rp. 200.000 KURANG MAMPU','Jahratul Jannah','870','2','','2021-04-03 12:17:57',64714,0),(584,'20.3423',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','872','2',NULL,'2021-04-03 12:25:39',11306,0),(585,'20.3424',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','874','2',NULL,'2021-04-03 12:31:28',60566,0),(586,'20.3426',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','876','2',NULL,'2021-04-03 12:35:46',18056,0),(587,'20.3428',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','878','2',NULL,'2021-04-03 12:41:02',45175,0),(588,'20.3427',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','880','2',NULL,'2021-04-03 12:44:38',16151,0),(589,'20.3429',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','882','2',NULL,'2021-04-03 12:53:07',61391,0),(590,'20.3430',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','884','2',NULL,'2021-04-03 13:14:36',22503,0),(591,'18.2155',15,7200000,0,0,'','Rika Erliani Harahap','886','1',NULL,'2021-04-03 23:02:18',21912,0),(592,'20.3431',16,7200000,0,0,'','Rika Erliani Harahap S. Hum','888','2',NULL,'2021-04-04 08:06:38',46164,0),(593,'20.3433',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','890','2',NULL,'2021-04-04 09:13:59',40374,0),(594,'20.3435',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','892','2',NULL,'2021-04-04 09:19:52',24655,0),(595,'20.3436',16,7200000,600000,0,'lunas','Rika Erliani Harahap S. Hum','894','2','','2021-04-04 09:23:59',50087,0),(596,'19.3016',16,6900000,600000,0,'-','Jahratul Jannah','896','2',NULL,'2021-04-05 07:38:24',45323,0),(597,'19.3017',16,6900000,600000,0,'-','Jahratul Jannah','898','2',NULL,'2021-04-05 07:49:12',23839,0),(598,'19.3018',16,6900000,600000,0,'-','Jahratul Jannah','900','2',NULL,'2021-04-05 07:51:11',39799,0),(599,'19.3019',16,6900000,600000,1,'-','Jahratul Jannah','902','2',NULL,'2021-04-05 07:56:23',30884,0),(600,'19.3020',16,6900000,600000,0,'-','Jahratul Jannah','905','2',NULL,'2021-04-05 08:04:50',61686,0),(601,'20.3437',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','907','2',NULL,'2021-04-05 08:13:11',32377,0),(602,'19.3022',16,6860000,600000,0,'BULAN AGUS DAN SEPTEMBER MASIH 580.000 KARNA ADIK KAKAK BELUM NAIK BULANAN','Jahratul Jannah','909','2',NULL,'2021-04-05 08:16:14',49112,0),(603,'20.3438',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','910','2',NULL,'2021-04-05 08:17:04',4089,0),(604,'20.3439',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','912','2',NULL,'2021-04-05 08:22:08',62055,0),(605,'20.3440',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','914','2',NULL,'2021-04-05 08:30:45',49139,0),(606,'19.3023',16,6900000,600000,0,'','Jahratul Jannah','916','2',NULL,'2021-04-05 08:31:33',21368,0),(607,'20.3441',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','918','2',NULL,'2021-04-05 08:33:36',43459,0),(608,'20.3442',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','920','2',NULL,'2021-04-05 08:36:11',13561,0),(609,'20.3443',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','923','2',NULL,'2021-04-05 08:38:25',41356,0),(610,'20.3444',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','925','2',NULL,'2021-04-05 08:42:02',42913,0),(611,'20.3445',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','927','2',NULL,'2021-04-05 08:44:22',8376,0),(612,'20.3446',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','929','2',NULL,'2021-04-05 08:56:58',8537,0),(613,'20.3447',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','931','2',NULL,'2021-04-05 09:29:15',6557,0),(614,'20.3448',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','933','2',NULL,'2021-04-05 09:31:08',42845,0),(615,'20.3449',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','935','2',NULL,'2021-04-05 09:36:06',57221,0),(616,'20.3450',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','937','2',NULL,'2021-04-05 09:38:26',11028,0),(617,'20.3451',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','939','2',NULL,'2021-04-05 09:42:43',54384,0),(618,'20.3452',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','941','2',NULL,'2021-04-05 09:44:37',39595,0),(619,'20.3453',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','943','2',NULL,'2021-04-05 09:47:05',48327,0),(620,'20.3454',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','945','2',NULL,'2021-04-05 09:49:20',29210,0),(621,'20.3455',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','947','2',NULL,'2021-04-05 09:52:16',12129,0),(622,'20.3456',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','949','2',NULL,'2021-04-05 09:54:51',10938,0),(623,'20.3626',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','951','2',NULL,'2021-04-05 09:56:55',136,0),(624,'20.3836',16,6600000,600000,0,'Baru Masuk di Bulan Agustus','Rika Erliani Harahap S. Hum','953','2','','2021-04-05 10:05:35',56809,0),(625,'20.2433',15,7200000,600000,0,'','Jahratul Jannah S.Pd','955','1',NULL,'2021-04-05 10:29:35',25961,0),(626,'19.3209',16,6900000,600000,0,'','Jahratul Jannah','957','2',NULL,'2021-04-05 19:50:40',45499,0),(627,'19.3026',16,6900000,600000,0,'','Jahratul Jannah','959','2',NULL,'2021-04-05 19:54:35',37539,0),(628,'19.3027',16,6900000,600000,0,'','Jahratul Jannah','961','2',NULL,'2021-04-05 19:57:21',6447,0),(629,'19.3028',16,6900000,600000,0,'','Jahratul Jannah','963','2',NULL,'2021-04-05 19:59:11',21080,0),(630,'19.3029',16,6900000,600000,0,'','Jahratul Jannah','965','2',NULL,'2021-04-05 20:01:07',6702,0),(631,'19.3031',16,6900000,600000,0,'','Jahratul Jannah','967','2',NULL,'2021-04-05 20:02:58',31642,0),(632,'19.3032',16,6900000,600000,0,'','Jahratul Jannah','969','2',NULL,'2021-04-05 20:08:25',48120,0),(633,'19.3033',16,6900000,600000,0,'','Jahratul Jannah','970','2',NULL,'2021-04-05 20:11:05',16658,0),(634,'19.3034',16,6900000,600000,0,'','Jahratul Jannah','972','2',NULL,'2021-04-05 20:13:18',53980,0),(635,'193413',16,6900000,600000,0,'','Jahratul Jannah','974','2',NULL,'2021-04-05 20:15:26',38299,0),(636,'19.3036',16,6900000,600000,0,'','Jahratul Jannah','976','2',NULL,'2021-04-05 20:34:13',63489,0),(637,'19.3037',16,6900000,600000,0,'','Jahratul Jannah','978','2',NULL,'2021-04-05 20:37:03',19170,0),(638,'19.3040',16,6290000,550000,0,'DIESPEN 50.000','Jahratul Jannah','980','2','','2021-04-07 15:31:49',61224,0),(639,'19.3039',16,6900000,600000,0,'','Jahratul Jannah','982','2',NULL,'2021-04-05 20:52:52',57564,0),(640,'19.3041',16,6900000,600000,0,'','Jahratul Jannah','984','2',NULL,'2021-04-05 20:59:47',47758,0),(641,'19.3042',16,0,0,2,'','Jahratul Jannah','986','2',NULL,'2021-04-05 21:03:51',390,0),(642,'19.3043',16,6900000,600000,0,'','Jahratul Jannah','987','2',NULL,'2021-04-05 21:05:21',23158,0),(643,'19.3044',16,6900000,600000,0,'','Jahratul Jannah','989','2',NULL,'2021-04-05 21:08:39',44822,0),(644,'19.3045',16,6900000,600000,0,'','Jahratul Jannah','991','2',NULL,'2021-04-05 21:13:13',47946,0),(645,'19.3046',16,6900000,600000,0,'','Jahratul Jannah','993','2',NULL,'2021-04-05 21:17:03',24225,0),(646,'19.3078',16,6900000,600000,0,'','Jahratul Jannah','995','2',NULL,'2021-04-05 21:19:35',39466,0),(647,'20.3841',16,3000000,600000,0,'Santri baru masuk bulan Februari 2021','Jahratul Jannah','997','2',NULL,'2021-04-05 21:25:24',62913,0),(648,'19.3210',16,6900000,600000,0,'','Jahratul Jannah','999','2',NULL,'2021-04-05 21:31:30',64435,0),(649,'19.3211',16,6900000,600000,0,'','Jahratul Jannah','1001','2',NULL,'2021-04-05 21:34:41',16991,0),(650,'19.3212',16,6900000,600000,0,'','Jahratul Jannah','1003','2',NULL,'2021-04-05 21:37:24',13987,0),(651,'19.3213',16,6900000,600000,0,'','Jahratul Jannah','1005','2',NULL,'2021-04-05 21:47:25',25222,0),(652,'19.3214',16,6900000,600000,0,'','Jahratul Jannah','1007','2',NULL,'2021-04-05 21:55:16',5013,0),(653,'19.3215',16,6900000,600000,0,'','Jahratul Jannah','1009','2','','2021-04-05 22:05:08',49755,0),(654,'20.3416',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','1011','2',NULL,'2021-04-06 09:38:59',32515,0),(655,'20.3457',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','1013','2',NULL,'2021-04-06 09:42:02',55262,0),(656,'20.3458',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','1015','2',NULL,'2021-04-06 10:37:55',22184,0),(657,'20.3459',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','1017','2',NULL,'2021-04-06 10:39:58',49172,0),(658,'20.3460',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','1019','2',NULL,'2021-04-06 10:42:12',42878,0),(659,'20.3461',16,7200000,600000,1,'','Rika Erliani Harahap S. Hum','1021','2',NULL,'2021-04-06 10:50:29',13389,0),(660,'20.3462',16,6850000,0,0,'ADA DISPEN 50 RIBU DIMULAI DARI BULAN DESEMBER 2020 (DISPEN KARENA ADIK/KK)','Rika Erliani Harahap S. Hum','1023','2',NULL,'2021-04-06 10:59:46',55288,0),(661,'20.3463',16,7200000,600000,0,'','Rika Erliani Harahap S. Hum','1025','2',NULL,'2021-04-06 11:12:29',35062,0),(662,'19.3247',16,6900000,600000,0,'','Jahratul Jannah','1039','2',NULL,'2021-04-07 15:40:58',8131,0),(663,'19.3246',16,6900000,600000,0,'','Jahratul Jannah','1041','2',NULL,'2021-04-07 15:44:03',24358,0),(664,'19.3216',16,6900000,600000,0,'','Jahratul Jannah','1043','2',NULL,'2021-04-15 13:08:40',7672,0),(665,'19.3217',16,6900000,600000,0,'','Jahratul Jannah','1045','2',NULL,'2021-04-15 13:11:36',109,0),(666,'19.3218',16,6900000,600000,0,'','Jahratul Jannah','1047','2',NULL,'2021-04-15 13:14:42',5055,0),(667,'19.3219',16,6900000,600000,0,'','Jahratul Jannah','1049','2',NULL,'2021-04-15 13:16:52',60062,0),(668,'19.3220',16,6900000,600000,0,'','Jahratul Jannah','1051','2',NULL,'2021-04-15 13:18:46',56694,0),(669,'19.3221',16,6900000,600000,0,'','Jahratul Jannah','1053','2',NULL,'2021-04-15 13:20:40',10453,0),(670,'19.3223',16,6900000,600000,0,'','Jahratul Jannah','1055','2',NULL,'2021-04-15 13:22:21',57389,0),(671,'19.3224',16,6900000,600000,0,'','Jahratul Jannah','1057','2',NULL,'2021-04-15 13:23:46',51115,0),(672,'19.3225',16,6900000,600000,0,'','Jahratul Jannah','1059','2',NULL,'2021-04-15 13:25:36',31344,0),(673,'19.3226',16,6250000,550000,0,'adik kakak','Jahratul Jannah','1061','2',NULL,'2021-04-15 13:29:28',28857,0),(674,'19.3228',16,6900000,600000,0,'','Jahratul Jannah','1063','2','','2021-04-15 13:32:53',16293,0),(675,'19.3229',16,6900000,600000,0,'','Jahratul Jannah','1065','2',NULL,'2021-04-15 13:34:28',3267,0),(676,'19.3230',16,6900000,600000,0,'','Jahratul Jannah','1067','2',NULL,'2021-04-15 13:36:12',20179,0),(677,'19.3231',16,6900000,600000,0,'','Jahratul Jannah','1069','2',NULL,'2021-04-15 13:37:58',7855,0),(678,'19.3232',16,6900000,600000,0,'','Jahratul Jannah','1071','2',NULL,'2021-04-15 13:43:28',53820,0),(679,'19.3233',16,6900000,600000,0,'','Jahratul Jannah','1073','2',NULL,'2021-04-15 13:44:42',21125,0),(680,'19.3235',16,6900000,600000,0,'','Jahratul Jannah','1075','2',NULL,'2021-04-15 13:45:58',57333,0),(681,'19.3237',16,6900000,600000,0,'','Jahratul Jannah','1077','2',NULL,'2021-04-15 13:47:37',13619,0),(682,'19.3236',16,6900000,600000,0,'','Jahratul Jannah','1079','2',NULL,'2021-04-15 13:48:21',34421,0),(683,'19.3238',16,6900000,600000,0,'','Jahratul Jannah','1081','2',NULL,'2021-04-15 13:49:33',46334,0),(684,'19.3239',16,6900000,600000,0,'','Jahratul Jannah','1083','2',NULL,'2021-04-15 13:51:00',12053,0),(685,'19.3240',16,6900000,600000,0,'','Jahratul Jannah','1085','2',NULL,'2021-04-15 13:52:24',57930,0),(686,'19.3241',16,6900000,600000,0,'','Jahratul Jannah','1087','2',NULL,'2021-04-15 13:55:12',27425,0),(687,'19.3242',16,6900000,600000,0,'','Jahratul Jannah','1089','2',NULL,'2021-04-15 13:56:31',34764,0),(688,'19.3243',16,6900000,600000,0,'','Jahratul Jannah','1091','2',NULL,'2021-04-15 13:57:44',38240,0),(689,'19.3244',16,6900000,600000,0,'','Jahratul Jannah','1093','2',NULL,'2021-04-15 13:59:46',24265,0),(690,'19.3245',16,6900000,600000,0,'','Jahratul Jannah','1095','2',NULL,'2021-04-15 14:01:22',47764,0),(691,'19.3049',16,6290000,550000,0,'','Jahratul Jannah','1097','2',NULL,'2021-04-15 20:18:48',40292,0),(692,'19.3050',16,6900000,600000,0,'','Jahratul Jannah','1099','2',NULL,'2021-04-15 20:21:29',30148,0),(693,'19.3051',16,6900000,600000,0,'','Jahratul Jannah','1101','2',NULL,'2021-04-15 20:23:55',39766,0),(694,'19.3052',16,6900000,600000,0,'','Jahratul Jannah','1103','2',NULL,'2021-04-15 20:25:31',7961,0),(695,'19.3053',16,6900000,600000,0,'','Jahratul Jannah','1105','2',NULL,'2021-04-15 20:27:36',19296,0),(696,'19.3054',16,6900000,600000,0,'','Jahratul Jannah','1107','2',NULL,'2021-04-15 20:29:03',873,0),(697,'19.3055',16,6900000,600000,0,'','Jahratul Jannah','1109','2',NULL,'2021-04-15 20:31:04',37794,0),(698,'19.3056',16,6900000,600000,0,'','Jahratul Jannah','1111','2',NULL,'2021-04-15 20:32:54',61956,0),(699,'19.3401',16,6900000,600000,0,'','Jahratul Jannah','1113','2',NULL,'2021-04-15 20:36:38',45775,0),(700,'20.3842',16,6000000,600000,0,'','Jahratul Jannah','1115','2',NULL,'2021-04-15 20:40:31',23692,0),(701,'19.3058',16,6900000,600000,0,'','Jahratul Jannah','1117','2',NULL,'2021-04-16 19:07:59',49732,0),(702,'19.3060',16,6310000,550000,0,'','Jahratul Jannah','1119','2','','2021-04-16 19:11:49',28932,0),(703,'19.3061',16,6900000,600000,0,'','Jahratul Jannah','1121','2',NULL,'2021-04-16 19:13:41',30999,0),(704,'19.3062',16,6900000,600000,0,'','Jahratul Jannah','1123','2',NULL,'2021-04-16 19:15:24',63993,0),(705,'19.3063',16,6900000,600000,0,'','Jahratul Jannah','1125','2',NULL,'2021-04-16 19:18:30',24078,0),(706,'19.3064',16,6900000,600000,0,'','Jahratul Jannah','1127','2',NULL,'2021-04-16 19:21:25',40757,0),(707,'19.3065',16,6900000,600000,0,'','Jahratul Jannah','1129','2',NULL,'2021-04-16 19:23:13',40407,0),(708,'19.3066',16,6900000,600000,0,'','Jahratul Jannah','1131','2',NULL,'2021-04-16 19:31:20',20748,0),(709,'19.3067',16,6900000,600000,0,'','Jahratul Jannah','1133','2',NULL,'2021-04-16 19:32:53',38346,0),(710,'19.3068',16,6900000,600000,0,'','Jahratul Jannah','1135','2',NULL,'2021-04-16 19:36:11',32681,0),(711,'19.3071',16,6900000,600000,0,'','Jahratul Jannah','1137','2',NULL,'2021-04-16 21:04:50',18196,0),(712,'19.3072',16,6900000,600000,0,'','Jahratul Jannah','1139','2',NULL,'2021-04-16 21:08:47',13565,0),(713,'19.3073',16,6900000,600000,0,'','Jahratul Jannah','1141','2',NULL,'2021-04-16 21:10:44',36681,0),(714,'19.3074',16,6900000,600000,0,'','Jahratul Jannah','1143','2',NULL,'2021-04-16 21:11:59',33887,0),(715,'19.3075',16,6900000,600000,0,'','Jahratul Jannah','1145','2',NULL,'2021-04-16 21:15:29',53421,0),(716,'19.3077',16,6900000,600000,0,'','Jahratul Jannah','1147','2',NULL,'2021-04-16 21:18:54',3421,0),(717,'19.3079',16,6900000,600000,0,'','Jahratul Jannah','1149','2',NULL,'2021-04-16 21:21:11',37697,0),(718,'19.3080',16,6900000,600000,0,'','Jahratul Jannah','1151','2',NULL,'2021-04-16 21:22:55',6682,0),(719,'19.3081',16,6900000,600000,0,'','Jahratul Jannah','1153','2',NULL,'2021-04-16 21:27:49',17787,0),(720,'19.3082',16,6900000,600000,0,'','Jahratul Jannah','1155','2',NULL,'2021-04-16 21:29:50',49393,0),(721,'19.3083',16,6900000,600000,0,'','Jahratul Jannah','1157','2',NULL,'2021-04-16 21:32:19',6085,0),(722,'19.3084',16,6900000,600000,0,'','Jahratul Jannah','1159','2',NULL,'2021-04-16 21:34:28',41080,0),(723,'19.3085',16,6900000,600000,0,'','Jahratul Jannah','1161','2',NULL,'2021-04-16 21:36:45',23328,0),(724,'19.3086',16,6900000,600000,0,'','Jahratul Jannah','1163','2',NULL,'2021-04-16 21:38:13',26289,0),(725,'19.3087',16,6900000,600000,0,'','Jahratul Jannah','1165','2',NULL,'2021-04-16 21:39:41',19571,0),(726,'19.3168',16,6900000,600000,0,'','Jahratul Jannah','1167','2',NULL,'2021-04-16 21:42:08',39955,0),(727,'19.3102',16,6900000,600000,0,'','Jahratul Jannah','1169','2',NULL,'2021-04-16 21:43:39',58923,0),(728,'20.3840',16,4800000,600000,0,'','Jahratul Jannah','1171','2',NULL,'2021-04-16 21:46:02',58357,0),(729,'18.2709',16,6900000,600000,0,'','Jahratul Jannah','1173','2',NULL,'2021-04-16 21:48:21',57254,0),(730,'19.3248',16,6900000,600000,1,'','Jahratul Jannah','1175','2',NULL,'2021-04-17 18:42:26',7328,0),(731,'19.3249',16,6900000,600000,0,'','Jahratul Jannah','1177','2',NULL,'2021-04-17 18:42:50',30984,0),(732,'19.3250',16,6310000,550000,0,'','Jahratul Jannah','1179','2',NULL,'2021-04-17 18:52:17',8974,0),(733,'19.3251',16,6900000,600000,0,'','Jahratul Jannah','1181','2',NULL,'2021-04-17 19:50:10',43835,0),(734,'19.3253',16,6900000,600000,0,'','Jahratul Jannah','1183','2',NULL,'2021-04-17 20:39:28',29032,0),(735,'19.3254',16,6900000,600000,0,'','Jahratul Jannah','1185','2',NULL,'2021-04-18 09:22:59',48438,0),(736,'19.3255',16,6900000,600000,0,'','Jahratul Jannah','1187','2',NULL,'2021-04-18 09:25:43',54383,0),(737,'19.3256',16,6900000,600000,0,'','Jahratul Jannah','1189','2',NULL,'2021-04-18 09:27:02',16100,0),(738,'19.3257',16,6900000,600000,0,'','Jahratul Jannah','1191','2',NULL,'2021-04-18 09:32:20',2306,0),(739,'19.3258',16,6310000,550000,0,'abang adik','Jahratul Jannah','1193','2',NULL,'2021-04-18 09:36:32',56351,0),(740,'19.3259',16,6900000,600000,0,'','Jahratul Jannah','1195','2',NULL,'2021-04-18 09:39:03',24636,0),(741,'19.3260',16,6900000,600000,0,'','Jahratul Jannah','1197','2',NULL,'2021-04-18 09:40:43',10204,0),(742,'19.3415',16,4200000,350000,0,'Dispensasi','Jahratul Jannah','1199','2',NULL,'2021-04-18 09:43:01',29140,0),(743,'19.3261',16,6900000,600000,0,'','Jahratul Jannah','1201','2',NULL,'2021-04-18 09:48:43',40691,0),(744,'19.3262',16,6900000,600000,0,'','Jahratul Jannah','1203','2',NULL,'2021-04-18 10:16:59',9159,0),(745,'19.3264',16,6900000,600000,0,'','Jahratul Jannah','1205','2',NULL,'2021-04-18 10:18:34',63692,0),(746,'19.3266',16,2400000,200000,0,'Yatim Piatu','Jahratul Jannah','1207','2',NULL,'2021-04-18 10:20:17',58785,0),(747,'19.3267',16,6900000,600000,0,'','Jahratul Jannah','1209','2',NULL,'2021-04-18 10:22:01',19387,0),(748,'19.3268',16,6900000,600000,0,'','Jahratul Jannah','1211','2',NULL,'2021-04-18 10:25:00',23028,0),(749,'19.3269',16,6900000,600000,0,'','Jahratul Jannah','1213','2',NULL,'2021-04-18 10:26:57',39291,0),(750,'19.3270',16,2400000,200000,0,'','Jahratul Jannah','1215','2',NULL,'2021-04-18 10:29:32',9799,0),(751,'19.3271',16,6900000,600000,0,'','Jahratul Jannah','1217','2',NULL,'2021-04-18 10:37:14',28367,0),(752,'19.3272',16,5580000,480000,0,'','Jahratul Jannah','1219','2',NULL,'2021-04-18 10:39:13',59241,0),(753,'19.3273',16,6900000,600000,0,'','Jahratul Jannah','1221','2',NULL,'2021-04-18 10:41:40',40435,0),(754,'19.3274',16,6900000,600000,0,'','Jahratul Jannah','1223','2',NULL,'2021-04-18 10:48:12',8588,0),(755,'19.3275',16,6900000,600000,0,'','Jahratul Jannah','1225','2',NULL,'2021-04-18 10:51:54',36494,0),(756,'19.3276',16,6900000,600000,0,'','Jahratul Jannah','1227','2',NULL,'2021-04-18 10:53:28',3630,0),(757,'19.3278',16,6900000,600000,0,'','Jahratul Jannah','1229','2',NULL,'2021-04-18 11:15:08',12898,0),(758,'19.3279',16,6900000,600000,0,'','Jahratul Jannah','1231','2',NULL,'2021-04-18 11:17:28',23186,0),(759,'19.3280',16,6900000,600000,0,'','Jahratul Jannah','1233','2',NULL,'2021-04-18 11:19:00',56621,0),(760,'19.3281',16,6310000,550000,0,'','Jahratul Jannah','1235','2',NULL,'2021-04-18 11:20:51',35880,0),(761,'19.3282',16,6900000,600000,0,'','Jahratul Jannah','1237','2',NULL,'2021-04-18 11:22:43',35790,0),(762,'19.3283',16,6900000,600000,0,'','Jahratul Jannah','1239','2',NULL,'2021-04-18 11:24:24',19016,0),(763,'19.3284',16,6900000,600000,0,'','Jahratul Jannah','1241','2',NULL,'2021-04-18 11:25:48',55859,0),(764,'19.3285',16,6900000,600000,0,'','Jahratul Jannah','1243','2',NULL,'2021-04-18 11:27:41',25903,0),(765,'19.3286',16,6900000,600000,0,'','Jahratul Jannah','1245','2',NULL,'2021-04-18 11:29:08',12767,0),(766,'19.3048',16,6900000,600000,0,'','Jahratul Jannah','1247','2',NULL,'2021-04-18 11:32:33',40077,0),(767,'19.3088',16,6900000,600000,0,'','Jahratul Jannah','1249','2',NULL,'2021-04-18 11:33:42',61106,0),(768,'19.3089',16,6900000,600000,0,'','Jahratul Jannah','1251','2',NULL,'2021-04-18 11:34:47',371,0),(769,'19.3090',16,6900000,600000,0,'','Jahratul Jannah','1253','2',NULL,'2021-04-18 11:35:51',57928,0),(770,'19.3091',16,6900000,600000,0,'','Jahratul Jannah','1258','2',NULL,'2021-04-19 11:16:09',5046,0),(771,'19.3092',16,6900000,600000,0,'','Jahratul Jannah','1260','2',NULL,'2021-04-19 11:22:53',37084,0),(772,'19.2368',15,7200000,600000,0,'','Jahratul Jannah S.Pd','1262','1',NULL,'2021-07-12 20:50:24',61818,0),(773,'20.2531',15,7200000,600000,0,'','Jahratul Jannah S.Pd','1264','1',NULL,'2021-07-12 20:55:07',33033,0),(774,'19.2394',15,7200000,600000,0,'','Jahratul Jannah S.Pd','1266','1',NULL,'2021-07-12 21:33:48',8777,0),(775,'20.2493',15,7200000,600000,0,'','Jahratul Jannah S.Pd','1268','1',NULL,'2021-07-12 21:34:34',53887,0),(776,'20.2484',15,7200000,600000,1,'','Jahratul Jannah S.Pd','1270','1','','2021-07-12 21:37:25',63668,0);

#
# Structure for table "autotransdata"
#

DROP TABLE IF EXISTS `jbsfina`.`autotransdata`;
CREATE TABLE `jbsfina`.`autotransdata` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idautotrans` int(10) unsigned NOT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `besar` decimal(15,2) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) NOT NULL,
  `urutan` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_autotransdata_autotrans` (`idautotrans`),
  KEY `FK_autotransdata_datapenerimaan` (`idpenerimaan`),
  CONSTRAINT `FK_autotransdata_autotrans` FOREIGN KEY (`idautotrans`) REFERENCES `jbsfina`.`autotrans` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_autotransdata_datapenerimaan` FOREIGN KEY (`idpenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "autotransdata"
#


#
# Structure for table "datatabunganp"
#

DROP TABLE IF EXISTS `jbsfina`.`datatabunganp`;
CREATE TABLE `jbsfina`.`datatabunganp` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `rekkas` varchar(15) NOT NULL,
  `rekutang` varchar(15) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `departemen` varchar(50) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_datatabunganp_rekakun_kas` (`rekkas`),
  KEY `FK_datatabunganp_rekakun_utang` (`rekutang`),
  KEY `FK_datatabunganp_departemen` (`departemen`),
  KEY `IX_datatabunganp_ts` (`ts`,`issync`),
  CONSTRAINT `FK_datatabunganp_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datatabunganp_rekakun_kas` FOREIGN KEY (`rekkas`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datatabunganp_rekakun_utang` FOREIGN KEY (`rekutang`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "datatabunganp"
#


#
# Structure for table "datatabungan"
#

DROP TABLE IF EXISTS `jbsfina`.`datatabungan`;
CREATE TABLE `jbsfina`.`datatabungan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `rekkas` varchar(15) NOT NULL,
  `rekutang` varchar(15) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `departemen` varchar(50) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_datatabungan_rekakun_kas` (`rekkas`),
  KEY `FK_datatabungan_rekakun_utang` (`rekutang`),
  KEY `FK_datatabungan_departemen` (`departemen`),
  KEY `IX_datatabungan_ts` (`ts`,`issync`),
  CONSTRAINT `FK_datatabungan_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datatabungan_rekakun_kas` FOREIGN KEY (`rekkas`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datatabungan_rekakun_utang` FOREIGN KEY (`rekutang`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "datatabungan"
#


#
# Structure for table "paymenttabungan"
#

DROP TABLE IF EXISTS `jbsfina`.`paymenttabungan`;
CREATE TABLE `jbsfina`.`paymenttabungan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jenis` tinyint(1) unsigned NOT NULL COMMENT '1 Pegawai, 2 Siswa',
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `idtabungan` int(10) unsigned DEFAULT NULL,
  `idtabunganp` int(10) unsigned DEFAULT NULL,
  `rekkasvendor` varchar(15) CHARACTER SET utf8 NOT NULL,
  `rekutangvendor` varchar(15) CHARACTER SET utf8 NOT NULL,
  `maxtransvendor` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_paymenttabungan_departemen` (`departemen`),
  KEY `FK_paymenttabungan_tabungan` (`idtabungan`),
  KEY `FK_paymenttabungan_tabunganp` (`idtabunganp`),
  KEY `FK_paymenttabungan_rekkas` (`rekkasvendor`),
  KEY `FK_paymenttabungan_rekutang` (`rekutangvendor`),
  CONSTRAINT `FK_paymenttabungan_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttabungan_rekkas` FOREIGN KEY (`rekkasvendor`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttabungan_rekutang` FOREIGN KEY (`rekutangvendor`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttabungan_tabungan` FOREIGN KEY (`idtabungan`) REFERENCES `jbsfina`.`datatabungan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttabungan_tabunganp` FOREIGN KEY (`idtabunganp`) REFERENCES `jbsfina`.`datatabunganp` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "paymenttabungan"
#


#
# Structure for table "datapengeluaran"
#

DROP TABLE IF EXISTS `jbsfina`.`datapengeluaran`;
CREATE TABLE `jbsfina`.`datapengeluaran` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `rekdebet` varchar(15) NOT NULL,
  `rekkredit` varchar(15) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keterangan` varchar(255) DEFAULT NULL,
  `besar` decimal(15,0) NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_datapengeluaran_departemen` (`departemen`),
  KEY `FK_datapengeluaran_rekakun` (`rekdebet`),
  KEY `FK_datapengeluaran_rekakun2` (`rekkredit`),
  KEY `IX_datapengeluaran_ts` (`ts`,`issync`),
  CONSTRAINT `FK_datapengeluaran_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datapengeluaran_rekakun` FOREIGN KEY (`rekdebet`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE,
  CONSTRAINT `FK_datapengeluaran_rekakun2` FOREIGN KEY (`rekkredit`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "datapengeluaran"
#

INSERT INTO `datapengeluaran` VALUES (4,'SMA','Bayar Listrik','501','111',1,'Sekedar contoh. Menu ini mengatur setiap jenis pengeluaran yang mungkin dikeluarkan sekolah. Anda harus menentukan rekening Kas dan Beban untuk setiap transaksi pengeluaran.',0,NULL,NULL,NULL,'2010-03-02 10:06:52',17792,0);

#
# Structure for table "tahunbuku"
#

DROP TABLE IF EXISTS `jbsfina`.`tahunbuku`;
CREATE TABLE `jbsfina`.`tahunbuku` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tahunbuku` varchar(100) NOT NULL,
  `awalan` varchar(5) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `cacah` bigint(20) unsigned NOT NULL DEFAULT '0',
  `departemen` varchar(50) NOT NULL,
  `tanggalmulai` date NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_tahunbuku_departemen` (`departemen`),
  KEY `IX_tahunbuku_ts` (`ts`,`issync`),
  CONSTRAINT `FK_tahunbuku_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "tahunbuku"
#

INSERT INTO `tahunbuku` VALUES (1,'2020','2020',1,'',48,'ALIYAH','2021-04-01',NULL,NULL,NULL,'2021-07-12 21:37:25',39597,0),(2,'2020','2020',1,'',405,'TSANAWIYAH','2021-04-01',NULL,NULL,NULL,'2021-04-19 11:24:14',42891,0),(3,'2021','2021',1,'',0,'SD IP','2021-04-01',NULL,NULL,NULL,'2021-04-01 23:01:02',15376,0);

#
# Structure for table "multitransinfo"
#

DROP TABLE IF EXISTS `jbsfina`.`multitransinfo`;
CREATE TABLE `jbsfina`.`multitransinfo` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idtahunbuku` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nic` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `petugas` varchar(100) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `paymentstatus` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `paymentdate` datetime DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_multitransinfo_siswa` (`nis`),
  KEY `FK_multitransinfo_calonsiswa` (`nic`),
  KEY `FK_multitransinfo_tahunbuku` (`idtahunbuku`),
  CONSTRAINT `FK_multitransinfo_calonsiswa` FOREIGN KEY (`nic`) REFERENCES `jbsakad`.`calonsiswa` (`nopendaftaran`) ON UPDATE CASCADE,
  CONSTRAINT `FK_multitransinfo_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_multitransinfo_tahunbuku` FOREIGN KEY (`idtahunbuku`) REFERENCES `jbsfina`.`tahunbuku` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "multitransinfo"
#


#
# Structure for table "multitransdata"
#

DROP TABLE IF EXISTS `jbsfina`.`multitransdata`;
CREATE TABLE `jbsfina`.`multitransdata` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idinfo` int(10) unsigned NOT NULL,
  `notrans` varchar(100) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_multitransdata_multitransinfo` (`idinfo`),
  CONSTRAINT `FK_multitransdata_multitransinfo` FOREIGN KEY (`idinfo`) REFERENCES `jbsfina`.`multitransinfo` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "multitransdata"
#


#
# Structure for table "jurnal"
#

DROP TABLE IF EXISTS `jbsfina`.`jurnal`;
CREATE TABLE `jbsfina`.`jurnal` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `transaksi` varchar(255) NOT NULL,
  `idpetugas` varchar(30) DEFAULT NULL,
  `petugas` varchar(100) NOT NULL,
  `nokas` varchar(100) NOT NULL,
  `idtahunbuku` int(10) unsigned NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `sumber` varchar(40) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_jurnal_tahunbuku` (`idtahunbuku`),
  KEY `IX_jurnal_tanggal` (`tanggal`),
  KEY `IX_jurnal_idtahunbuku` (`idtahunbuku`),
  KEY `IX_jurnal_ts` (`ts`,`issync`),
  KEY `FK_jurnal_pegawai` (`idpetugas`),
  KEY `IX_jurnal` (`nokas`,`sumber`),
  CONSTRAINT `FK_jurnal_pegawai` FOREIGN KEY (`idpetugas`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_jurnal_tahunbuku` FOREIGN KEY (`idtahunbuku`) REFERENCES `jbsfina`.`tahunbuku` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1272 DEFAULT CHARSET=utf8;

#
# Data for table "jurnal"
#

INSERT INTO `jurnal` VALUES (71,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ADNAN HALIM HUSNI (19.2243)','2021003004','Supria Ningsih','2021000001',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(72,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ADNAN HALIM HUSNI (19.2243)','2021003004','Supria Ningsih','2021000002',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(73,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD DANI (19.2245)','2021003004','Supria Ningsih','2021000003',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(74,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD DANI (19.2245)','2021003004','Supria Ningsih','2021000004',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(75,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD HASROH SIREGAR (19.2246)','2021003004','Supria Ningsih','2021000005',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(76,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD HASROH SIREGAR (19.2246)','2021003004','Supria Ningsih','2021000006',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(77,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD RIZKY FAHLEVI HARAHAP (19.2247)','2021003004','Supria Ningsih','2021000007',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(78,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD RIZKY FAHLEVI HARAHAP (19.2247)','2021003004','Supria Ningsih','2021000008',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(79,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AL HAYDI FAUZAN NASUTION (19.2250)','2021003004','Supria Ningsih','2021000009',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(80,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AL HAYDI FAUZAN NASUTION (19.2250)','2021003004','Supria Ningsih','2021000010',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(81,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AWALUDDIN AHMAD (19.2254)','2021003004','Supria Ningsih','2021000011',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(82,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AWALUDDIN AHMAD (19.2254)','2021003004','Supria Ningsih','2021000012',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(83,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa DANANG FERIAWAN (19.2256)','2021003004','Supria Ningsih','2021000013',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(84,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa DANANG FERIAWAN (19.2256)','2021003004','Supria Ningsih','2021000014',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(85,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ERI GUNTUR MANURUNG (19.2259)','2021003004','Supria Ningsih','2021000015',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(86,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ERI GUNTUR MANURUNG (19.2259)','2021003004','Supria Ningsih','2021000016',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(87,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FAISAL (19.2260)','2021003004','Supria Ningsih','2021000017',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(88,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FAISAL (19.2260)','2021003004','Supria Ningsih','2021000018',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(89,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FARIS ANWAR (19.2261)','2021003004','Supria Ningsih','2021000019',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(90,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FARIS ANWAR (19.2261)','2021003004','Supria Ningsih','2021000020',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(91,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FIKRI ADTYA PRANANTA (19.2263)','2021003004','Supria Ningsih','2021000021',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(92,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FIKRI ADTYA PRANANTA (19.2263)','2021003004','Supria Ningsih','2021000022',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(93,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIDHO KURNIA (19.2278)','2021003004','Supria Ningsih','2021000023',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(94,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIDHO KURNIA (19.2278)','2021003004','Supria Ningsih','2021000024',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(95,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIO BARUARA TAMBUNAN (19.2281)','2021003004','Supria Ningsih','2021000025',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(96,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIO BARUARA TAMBUNAN (19.2281)','2021003004','Supria Ningsih','2021000026',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(97,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIZKY ARDIANSYAH SIREGAR (19.2283)','2021003004','Supria Ningsih','2021000027',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(98,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIZKY ARDIANSYAH SIREGAR (19.2283)','2021003004','Supria Ningsih','2021000028',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(99,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RAMADANI SYAFITRA SIREGAR (19.2288)','2021003004','Supria Ningsih','2021000029',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(100,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RAMADANI SYAFITRA SIREGAR (19.2288)','2021003004','Supria Ningsih','2021000030',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(101,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ABDUL KHALIQ LUBIS (19.2290)','2021003004','Supria Ningsih','2021000031',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(102,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ABDUL KHALIQ LUBIS (19.2290)','2021003004','Supria Ningsih','2021000032',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(103,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ASBI NASUTION (19.2298)','2021003004','Supria Ningsih','2021000033',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(104,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ASBI NASUTION (19.2298)','2021003004','Supria Ningsih','2021000034',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(105,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDUL HAFIZ (20.3415)','2021007007','Rika Erliani Harahap S. Hum','2020000001',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:03:41',0,0),(106,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL HAFIZ (20.3415)','2021007007','Rika Erliani Harahap S. Hum','2020000002',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:11:50',0,0),(107,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABGI MALLDANO KESUMA (20.3417)','2021007007','Rika Erliani Harahap S. Hum','2020000003',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:14:51',0,0),(108,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABGI MALLDANO KESUMA (20.3417)','2021007007','Rika Erliani Harahap S. Hum','2020000004',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:17:54',0,0),(109,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABI HAQQI AZZUHDA (20.3418)','2021007007','Rika Erliani Harahap S. Hum','2020000005',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:21:54',0,0),(110,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABI HAQQI AZZUHDA (20.3418)','2021007007','Rika Erliani Harahap S. Hum','2020000006',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:26:01',0,0),(111,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABY FERDINAL ROHENDY (20.3420)','2021007007','Rika Erliani Harahap S. Hum','2020000007',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:28:00',0,0),(793,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABY FERDINAL ROHENDY (20.3420)','2021007007','Rika Erliani Harahap S. Hum','2020000008',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:36:10',0,0),(794,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ACHMAD SATRIA (20.3421)','2021007007','Rika Erliani Harahap S. Hum','2020000009',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:36:53',0,0),(795,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDUL AZIS DAULAY (19.3010)','2021055055','Jahratul Jannah','2020000010',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:38:48',0,0),(796,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ACHMAD SATRIA (20.3421)','2021007007','Rika Erliani Harahap S. Hum','2020000011',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:39:15',0,0),(797,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ADIMAS PRISKA (20.3422)','2021007007','Rika Erliani Harahap S. Hum','2020000012',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:40:05',0,0),(865,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL AZIS DAULAY (19.3010)','2021055055','Jahratul Jannah','2020000013',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:43:47',0,0),(866,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDUL GHANI AMENDA (19.3012)','2021055055','Jahratul Jannah','2020000014',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:46:51',0,0),(867,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL GHANI AMENDA (19.3012)','2021055055','Jahratul Jannah','2020000015',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:51:38',0,0),(868,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AFRIZAL ARBI (20.3425)','2021007007','Rika Erliani Harahap S. Hum','2020000016',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 11:59:14',0,0),(869,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AFRIZAL ARBI (20.3425)','2021007007','Rika Erliani Harahap S. Hum','2020000017',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:02:53',0,0),(870,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDUL KHALIQ PINEM (19.3013)','2021055055','Jahratul Jannah','2020000018',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:10:09',0,0),(871,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ADIMAS PRISKA (20.3422)','2021007007','Rika Erliani Harahap S. Hum','2020000019',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:24:46',0,0),(872,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa ADITIYA FREDDY WINATA (20.3423)','2021007007','Rika Erliani Harahap S. Hum','2020000020',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:25:39',0,0),(873,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ADITIYA FREDDY WINATA (20.3423)','2021007007','Rika Erliani Harahap S. Hum','2020000021',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:30:40',0,0),(874,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AFIQ ALFIANSYAH (20.3424)','2021007007','Rika Erliani Harahap S. Hum','2020000022',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:31:28',0,0),(875,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AFIQ ALFIANSYAH (20.3424)','2021007007','Rika Erliani Harahap S. Hum','2020000023',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:34:43',0,0),(876,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AFWAN FAKHRI RAMADHAN (20.3426)','2021007007','Rika Erliani Harahap S. Hum','2020000024',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:35:46',0,0),(877,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AFWAN FAKHRI RAMADHAN (20.3426)','2021007007','Rika Erliani Harahap S. Hum','2020000025',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:39:15',0,0),(878,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD FAISAL (20.3428)','2021007007','Rika Erliani Harahap S. Hum','2020000026',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:41:02',0,0),(879,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FAISAL (20.3428)','2021007007','Rika Erliani Harahap S. Hum','2020000027',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:44:08',0,0),(880,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD FAISAL (20.3427)','2021007007','Rika Erliani Harahap S. Hum','2020000028',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:44:38',0,0),(881,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FAISAL (20.3427)','2021007007','Rika Erliani Harahap S. Hum','2020000029',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:49:22',0,0),(882,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD FAISAL HARAHAP (20.3429)','2021007007','Rika Erliani Harahap S. Hum','2020000030',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:53:07',0,0),(883,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FAISAL HARAHAP (20.3429)','2021007007','Rika Erliani Harahap S. Hum','2020000031',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 12:56:41',0,0),(884,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD FARID AHYAR SIREGAR (20.3430)','2021007007','Rika Erliani Harahap S. Hum','2020000032',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 13:14:36',0,0),(885,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FARID AHYAR SIREGAR (20.3430)','2021007007','Rika Erliani Harahap S. Hum','2020000033',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 14:11:24',0,0),(886,'2021-04-03','Pendataan besar pembayaran SPP Bulanan MA siswa ANNISA DWI AMALIA (18.2155)','2021056056','Rika Erliani Harahap','2020000035',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 23:02:18',0,0),(887,'2021-04-03','Pembayaran ke-1 SPP Bulanan MA siswa ANNISA DWI AMALIA (18.2155)','2021056056','Rika Erliani Harahap','2020000036',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-03 23:04:22',0,0),(888,'2021-04-04','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD FIKRI (20.3431)','2021007007','Rika Erliani Harahap S. Hum','2020000034',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 08:06:38',0,0),(889,'2021-04-04','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FIKRI (20.3431)','2021007007','Rika Erliani Harahap S. Hum','2020000035',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 09:12:45',0,0),(890,'2021-04-04','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD HUSAIN SIMBOLON (20.3433)','2021007007','Rika Erliani Harahap S. Hum','2020000036',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 09:13:59',0,0),(891,'2021-04-04','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD HUSAIN SIMBOLON (20.3433)','2021007007','Rika Erliani Harahap S. Hum','2020000037',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 09:17:10',0,0),(892,'2021-04-04','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD KOMARUDDIN (20.3435)','2021007007','Rika Erliani Harahap S. Hum','2020000038',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 09:19:52',0,0),(893,'2021-04-04','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD KOMARUDDIN (20.3435)','2021007007','Rika Erliani Harahap S. Hum','2020000039',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 09:22:52',0,0),(894,'2021-04-04','Pendataan besar pembayaran SPP Bulanan MTs siswa AHMAD RIZKY MAULANA (20.3436)','2021007007','Rika Erliani Harahap S. Hum','2020000040',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-04 09:23:26',0,0),(895,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL KHALIQ PINEM (19.3013)','2021055055','Jahratul Jannah','2020000041',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:37:40',0,0),(896,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDULLAH ABROR TAMBAK (19.3016)','2021055055','Jahratul Jannah','2020000042',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:38:24',0,0),(897,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ABDULLAH ABROR TAMBAK (19.3016)','2021055055','Jahratul Jannah','2020000043',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:48:42',0,0),(898,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDULLAH AL FARUQ NST (19.3017)','2021055055','Jahratul Jannah','2020000044',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:49:12',0,0),(899,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ABDULLAH AL FARUQ NST (19.3017)','2021055055','Jahratul Jannah','2020000045',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:50:31',0,0),(900,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ACHMAD FAHRI (19.3018)','2021055055','Jahratul Jannah','2020000046',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:51:11',0,0),(901,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ACHMAD FAHRI (19.3018)','2021055055','Jahratul Jannah','2020000047',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:52:42',0,0),(902,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ADELLO (19.3019)','2021055055','Jahratul Jannah','2020000048',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:53:11',0,0),(903,'2021-04-05','Pelunasan SPP Bulanan MTs siswa ADELLO (19.3019)','2021055055','Jahratul Jannah','2020000049',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 07:56:23',0,0),(904,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD RIZKY MAULANA (20.3436)','2021007007','Rika Erliani Harahap S. Hum','2020000050',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:02:41',0,0),(905,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ADITYA PRATAMA (19.3020)','2021055055','Jahratul Jannah','2020000051',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:04:50',0,0),(906,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ADITYA PRATAMA (19.3020)','2021055055','Jahratul Jannah','2020000052',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:07:49',0,0),(907,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AIDIL FITRAH WAHYUDA (20.3437)','2021007007','Rika Erliani Harahap S. Hum','2020000053',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:13:11',0,0),(908,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AIDIL FITRAH WAHYUDA (20.3437)','2021007007','Rika Erliani Harahap S. Hum','2020000054',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:15:58',0,0),(909,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AFRIYANTO (19.3022)','2021055055','Jahratul Jannah','2020000055',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:16:14',0,0),(910,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AIYDIL ROHMAN (20.3438)','2021007007','Rika Erliani Harahap S. Hum','2020000056',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:17:04',0,0),(911,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AIYDIL ROHMAN (20.3438)','2021007007','Rika Erliani Harahap S. Hum','2020000057',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:21:14',0,0),(912,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AJA M. RAIS ALI S (20.3439)','2021007007','Rika Erliani Harahap S. Hum','2020000058',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:22:08',0,0),(913,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AJA M. RAIS ALI S (20.3439)','2021007007','Rika Erliani Harahap S. Hum','2020000059',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:28:47',0,0),(914,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AL FARIDZY INDRA TANJUNG (20.3440)','2021007007','Rika Erliani Harahap S. Hum','2020000060',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:30:45',0,0),(915,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AFRIYANTO (19.3022)','2021055055','Jahratul Jannah','2020000061',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:31:00',0,0),(916,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AFRIZUL HAFIZ (19.3023)','2021055055','Jahratul Jannah','2020000062',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:31:33',0,0),(917,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AL FARIDZY INDRA TANJUNG (20.3440)','2021007007','Rika Erliani Harahap S. Hum','2020000063',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:32:57',0,0),(918,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALDI FADLAN (20.3441)','2021007007','Rika Erliani Harahap S. Hum','2020000064',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:33:36',0,0),(919,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALDI FADLAN (20.3441)','2021007007','Rika Erliani Harahap S. Hum','2020000065',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:35:38',0,0),(920,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALFI CAHAYA HASIBUAN (20.3442)','2021007007','Rika Erliani Harahap S. Hum','2020000066',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:36:11',0,0),(921,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AFRIZUL HAFIZ (19.3023)','2021055055','Jahratul Jannah','2020000067',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:36:57',0,0),(922,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALFI CAHAYA HASIBUAN (20.3442)','2021007007','Rika Erliani Harahap S. Hum','2020000068',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:37:57',0,0),(923,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALI AKBAR HASIBUAN (20.3443)','2021007007','Rika Erliani Harahap S. Hum','2020000069',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:38:25',0,0),(924,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALI AKBAR HASIBUAN (20.3443)','2021007007','Rika Erliani Harahap S. Hum','2020000070',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:40:12',0,0),(925,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALIF DZULJALALI (20.3444)','2021007007','Rika Erliani Harahap S. Hum','2020000071',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:42:02',0,0),(926,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALIF DZULJALALI (20.3444)','2021007007','Rika Erliani Harahap S. Hum','2020000072',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:43:24',0,0),(927,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALVIN SURURI SIREGAR (20.3445)','2021007007','Rika Erliani Harahap S. Hum','2020000073',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:44:22',0,0),(928,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALVIN SURURI SIREGAR (20.3445)','2021007007','Rika Erliani Harahap S. Hum','2020000074',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:46:10',0,0),(929,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ANGGA PRATAMA (20.3446)','2021007007','Rika Erliani Harahap S. Hum','2020000075',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 08:56:58',0,0),(930,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANGGA PRATAMA (20.3446)','2021007007','Rika Erliani Harahap S. Hum','2020000076',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:28:40',0,0),(931,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ANGGA PRAYUDHA (20.3447)','2021007007','Rika Erliani Harahap S. Hum','2020000077',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:29:15',0,0),(932,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANGGA PRAYUDHA (20.3447)','2021007007','Rika Erliani Harahap S. Hum','2020000078',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:30:29',0,0),(933,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARGA PATAMA PASARIBU (20.3448)','2021007007','Rika Erliani Harahap S. Hum','2020000079',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:31:08',0,0),(934,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARGA PATAMA PASARIBU (20.3448)','2021007007','Rika Erliani Harahap S. Hum','2020000080',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:32:19',0,0),(935,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARGASYAPUTRA (20.3449)','2021007007','Rika Erliani Harahap S. Hum','2020000081',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:36:06',0,0),(936,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARGASYAPUTRA (20.3449)','2021007007','Rika Erliani Harahap S. Hum','2020000082',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:37:34',0,0),(937,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARHABURRIZQI FADLAN (20.3450)','2021007007','Rika Erliani Harahap S. Hum','2020000083',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:38:26',0,0),(938,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARHABURRIZQI FADLAN (20.3450)','2021007007','Rika Erliani Harahap S. Hum','2020000084',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:39:38',0,0),(939,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARIF FIRMANSYAH (20.3451)','2021007007','Rika Erliani Harahap S. Hum','2020000085',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:42:43',0,0),(940,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARIF FIRMANSYAH (20.3451)','2021007007','Rika Erliani Harahap S. Hum','2020000086',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:44:17',0,0),(941,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARLIN RIZKY ALZUHAIRO HARAHAP (20.3452)','2021007007','Rika Erliani Harahap S. Hum','2020000087',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:44:37',0,0),(942,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARLIN RIZKY ALZUHAIRO HARAHAP (20.3452)','2021007007','Rika Erliani Harahap S. Hum','2020000088',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:46:06',0,0),(943,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARYA ADENATA (20.3453)','2021007007','Rika Erliani Harahap S. Hum','2020000089',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:47:05',0,0),(944,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARYA ADENATA (20.3453)','2021007007','Rika Erliani Harahap S. Hum','2020000090',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:48:31',0,0),(945,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARYA RANGGA (20.3454)','2021007007','Rika Erliani Harahap S. Hum','2020000091',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:49:20',0,0),(946,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARYA RANGGA (20.3454)','2021007007','Rika Erliani Harahap S. Hum','2020000092',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:51:19',0,0),(947,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARYA RIZKI AFFAN DALIMUNTE (20.3455)','2021007007','Rika Erliani Harahap S. Hum','2020000093',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:52:16',0,0),(948,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARYA RIZKI AFFAN DALIMUNTE (20.3455)','2021007007','Rika Erliani Harahap S. Hum','2020000094',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:54:07',0,0),(949,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ASRAFI HADIN HARAHAP (20.3456)','2021007007','Rika Erliani Harahap S. Hum','2020000095',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:54:51',0,0),(950,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ASRAFI HADIN HARAHAP (20.3456)','2021007007','Rika Erliani Harahap S. Hum','2020000096',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:56:22',0,0),(951,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa HARY PERWIRA HASIBUAN (20.3626)','2021007007','Rika Erliani Harahap S. Hum','2020000097',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:56:55',0,0),(952,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa HARY PERWIRA HASIBUAN (20.3626)','2021007007','Rika Erliani Harahap S. Hum','2020000098',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:58:42',0,0),(953,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa NAZARUDDIN LUBIS (20.3836)','2021007007','Rika Erliani Harahap S. Hum','2020000099',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 09:59:19',0,0),(954,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa NAZARUDDIN LUBIS (20.3836)','2021007007','Rika Erliani Harahap S. Hum','2020000100',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 10:02:05',0,0),(955,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MA siswa ABDUL MANAN HSB (20.2433)','2021006006','Jahratul Jannah S.Pd','2020000037',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 10:29:35',0,0),(956,'2021-04-05','Pembayaran ke-1 SPP Bulanan MA siswa ABDUL MANAN HSB (20.2433)','2021006006','Jahratul Jannah S.Pd','2020000038',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 10:31:58',0,0),(957,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ADHELIA PUTTY FAIZZA ANDIATRI (19.3209)','2021055055','Jahratul Jannah','2020000101',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:50:40',0,0),(958,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ADHELIA PUTTY FAIZZA ANDIATRI (19.3209)','2021055055','Jahratul Jannah','2020000102',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:53:46',0,0),(959,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AIDIL AKBAR (19.3026)','2021055055','Jahratul Jannah','2020000103',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:54:35',0,0),(960,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AIDIL AKBAR (19.3026)','2021055055','Jahratul Jannah','2020000104',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:56:19',0,0),(961,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AJI BAHYU DERMAWAN (19.3027)','2021055055','Jahratul Jannah','2020000105',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:57:21',0,0),(962,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AJI BAHYU DERMAWAN (19.3027)','2021055055','Jahratul Jannah','2020000106',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:58:34',0,0),(963,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALFARIZ RIZKI SIKUMBANG (19.3028)','2021055055','Jahratul Jannah','2020000107',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 19:59:11',0,0),(964,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALFARIZ RIZKI SIKUMBANG (19.3028)','2021055055','Jahratul Jannah','2020000108',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:00:37',0,0),(965,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALI ARDIANSYAH (19.3029)','2021055055','Jahratul Jannah','2020000109',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:01:07',0,0),(966,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALI ARDIANSYAH (19.3029)','2021055055','Jahratul Jannah','2020000110',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:02:38',0,0),(967,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALIP ALFARIZI DAMANIK (19.3031)','2021055055','Jahratul Jannah','2020000111',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:02:58',0,0),(968,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALIP ALFARIZI DAMANIK (19.3031)','2021055055','Jahratul Jannah','2020000112',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:04:32',0,0),(969,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ALVIN RAMADONI NASUTION (19.3032)','2021055055','Jahratul Jannah','2020000113',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:08:25',0,0),(970,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AMAR FAISZ (19.3033)','2021055055','Jahratul Jannah','2020000114',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:11:05',0,0),(971,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AMAR FAISZ (19.3033)','2021055055','Jahratul Jannah','2020000115',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:12:40',0,0),(972,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AMIN AL-BANA (19.3034)','2021055055','Jahratul Jannah','2020000116',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:13:18',0,0),(973,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AMIN AL-BANA (19.3034)','2021055055','Jahratul Jannah','2020000117',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:14:36',0,0),(974,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ANDI FAKHRI LUBIS (193413)','2021055055','Jahratul Jannah','2020000118',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:15:26',0,0),(975,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANDI FAKHRI LUBIS (193413)','2021055055','Jahratul Jannah','2020000119',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:16:38',0,0),(976,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ANDI GUNAWAN (19.3036)','2021055055','Jahratul Jannah','2020000120',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:34:13',0,0),(977,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANDI GUNAWAN (19.3036)','2021055055','Jahratul Jannah','2020000121',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:36:35',0,0),(978,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ANDI SAHPUTRA (19.3037)','2021055055','Jahratul Jannah','2020000122',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:37:03',0,0),(979,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANDI SAHPUTRA (19.3037)','2021055055','Jahratul Jannah','2020000123',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:38:34',0,0),(980,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARDIANSYAH PUTRA (19.3040)','2021055055','Jahratul Jannah','2020000124',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:39:11',0,0),(981,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARDIANSYAH PUTRA (19.3040)','2021055055','Jahratul Jannah','2020000125',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:48:20',0,0),(982,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARDIANSYAH SIAGIAN (19.3039)','2021055055','Jahratul Jannah','2020000126',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:52:52',0,0),(983,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARDIANSYAH SIAGIAN (19.3039)','2021055055','Jahratul Jannah','2020000127',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:55:16',0,0),(984,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARIEF YORDAN FAIRUZHA (19.3041)','2021055055','Jahratul Jannah','2020000128',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 20:59:47',0,0),(985,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARIEF YORDAN FAIRUZHA (19.3041)','2021055055','Jahratul Jannah','2020000129',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:02:41',0,0),(986,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa ARIFIN SYAPUTRA (19.3042)','2021055055','Jahratul Jannah','2020000130',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:03:51',0,0),(987,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AWI FEBRIAN (19.3043)','2021055055','Jahratul Jannah','2020000131',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:05:21',0,0),(988,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AWI FEBRIAN (19.3043)','2021055055','Jahratul Jannah','2020000132',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:06:40',0,0),(989,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AZHAR RITONGA (19.3044)','2021055055','Jahratul Jannah','2020000133',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:08:39',0,0),(990,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AZHAR RITONGA (19.3044)','2021055055','Jahratul Jannah','2020000134',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:11:25',0,0),(991,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AZMI HALIM HASIBUAN (19.3045)','2021055055','Jahratul Jannah','2020000135',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:13:13',0,0),(992,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AZMI HALIM HASIBUAN (19.3045)','2021055055','Jahratul Jannah','2020000136',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:16:09',0,0),(993,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AZMY HILAL WALVYD (19.3046)','2021055055','Jahratul Jannah','2020000137',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:17:03',0,0),(994,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AZMY HILAL WALVYD (19.3046)','2021055055','Jahratul Jannah','2020000138',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:18:50',0,0),(995,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa FAUZAN DARMAWANSYAH PULUNGAN (19.3078)','2021055055','Jahratul Jannah','2020000139',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:19:35',0,0),(996,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa FAUZAN DARMAWANSYAH PULUNGAN (19.3078)','2021055055','Jahratul Jannah','2020000140',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:23:09',0,0),(997,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa MUHAMMAD HAFIZH (20.3841)','2021055055','Jahratul Jannah','2020000141',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:25:24',0,0),(998,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa MUHAMMAD HAFIZH (20.3841)','2021055055','Jahratul Jannah','2020000142',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:26:20',0,0),(999,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AGIL PUTRI AGUSTIN (19.3210)','2021055055','Jahratul Jannah','2020000143',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:31:30',0,0),(1000,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AGIL PUTRI AGUSTIN (19.3210)','2021055055','Jahratul Jannah','2020000144',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:34:13',0,0),(1001,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AILA ADHANI SAMPURNA HSB (19.3211)','2021055055','Jahratul Jannah','2020000145',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:34:41',0,0),(1002,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AILA ADHANI SAMPURNA HSB (19.3211)','2021055055','Jahratul Jannah','2020000146',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:36:38',0,0),(1003,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AINAYA AZZAHRA MALINI HASIBUAN (19.3212)','2021055055','Jahratul Jannah','2020000147',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:37:24',0,0),(1004,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AINAYA AZZAHRA MALINI HASIBUAN (19.3212)','2021055055','Jahratul Jannah','2020000148',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:41:17',0,0),(1005,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AINI (19.3213)','2021055055','Jahratul Jannah','2020000149',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:47:25',0,0),(1006,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AINI (19.3213)','2021055055','Jahratul Jannah','2020000150',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:50:39',0,0),(1007,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AINI AQILA SIREGAR (19.3214)','2021055055','Jahratul Jannah','2020000151',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 21:55:16',0,0),(1008,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AINI AQILA SIREGAR (19.3214)','2021055055','Jahratul Jannah','2020000152',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 22:00:03',0,0),(1009,'2021-04-05','Pendataan besar pembayaran SPP Bulanan MTs siswa AISYAH MAULIDA HARAHAP (19.3215)','2021055055','Jahratul Jannah','2020000153',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 22:01:22',0,0),(1010,'2021-04-05','Pelunasan SPP Bulanan MTs siswa AISYAH MAULIDA HARAHAP (19.3215)','2021055055','Jahratul Jannah','2020000154',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-05 22:04:37',0,0),(1011,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa ABDUL KHOLIK JAILANI HARAHAP (20.3416)','2021007007','Rika Erliani Harahap S. Hum','2020000155',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 09:38:59',0,0),(1012,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL KHOLIK JAILANI HARAHAP (20.3416)','2021007007','Rika Erliani Harahap S. Hum','2020000156',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 09:41:12',0,0),(1013,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa ATTHA RICK ALFA REZA (20.3457)','2021007007','Rika Erliani Harahap S. Hum','2020000157',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 09:42:02',0,0),(1014,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa ATTHA RICK ALFA REZA (20.3457)','2021007007','Rika Erliani Harahap S. Hum','2020000158',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 09:49:50',0,0),(1015,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa AULIA IKHSAN MUNTHE (20.3458)','2021007007','Rika Erliani Harahap S. Hum','2020000159',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:37:55',0,0),(1016,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa AULIA IKHSAN MUNTHE (20.3458)','2021007007','Rika Erliani Harahap S. Hum','2020000160',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:39:19',0,0),(1017,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa AWALUDDIN PASARIBU (20.3459)','2021007007','Rika Erliani Harahap S. Hum','2020000161',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:39:58',0,0),(1018,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa AWALUDDIN PASARIBU (20.3459)','2021007007','Rika Erliani Harahap S. Hum','2020000162',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:41:17',0,0),(1019,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa AZI SURYA ANGGORO (20.3460)','2021007007','Rika Erliani Harahap S. Hum','2020000163',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:42:12',0,0),(1020,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa AZI SURYA ANGGORO (20.3460)','2021007007','Rika Erliani Harahap S. Hum','2020000164',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:47:06',0,0),(1021,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa AZMI RIVALDI ALHAVIZ (20.3461)','2021007007','Rika Erliani Harahap S. Hum','2020000165',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:47:31',0,0),(1022,'2021-04-06','Pelunasan SPP Bulanan MTs siswa AZMI RIVALDI ALHAVIZ (20.3461)','2021007007','Rika Erliani Harahap S. Hum','2020000166',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:50:29',0,0),(1023,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa BAGUS SATRIA PRATAMA (20.3462)','2021007007','Rika Erliani Harahap S. Hum','2020000167',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 10:59:46',0,0),(1024,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa BAGUS SATRIA PRATAMA (20.3462)','2021007007','Rika Erliani Harahap S. Hum','2020000168',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 11:10:15',0,0),(1025,'2021-04-06','Pendataan besar pembayaran SPP Bulanan MTs siswa BAYU ALDIANSYAH (20.3463)','2021007007','Rika Erliani Harahap S. Hum','2020000169',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 11:12:29',0,0),(1026,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa BAYU ALDIANSYAH (20.3463)','2021007007','Rika Erliani Harahap S. Hum','2020000170',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-06 11:14:45',0,0),(1027,'2021-04-07','Pembayaran ke-1 SPP Bulanan MTs siswa ALVIN RAMADONI NASUTION (19.3032)','2021055055','Jahratul Jannah','2020000171',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:22:07',0,0),(1028,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ABDUL GHANI AMENDA (19.3012)','2021055055','Jahratul Jannah','2020000172',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:23:46',0,0),(1029,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ABDULLAH AL FARUQ NST (19.3017)','2021055055','Jahratul Jannah','2020000173',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:24:48',0,0),(1030,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AFRIZUL HAFIZ (19.3023)','2021055055','Jahratul Jannah','2020000174',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:27:18',0,0),(1031,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AJI BAHYU DERMAWAN (19.3027)','2021055055','Jahratul Jannah','2020000175',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:29:03',0,0),(1032,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ARDIANSYAH SIAGIAN (19.3039)','2021055055','Jahratul Jannah','2020000176',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:30:44',0,0),(1033,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ARDIANSYAH PUTRA (19.3040)','2021055055','Jahratul Jannah','2020000177',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:33:09',0,0),(1034,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ARIEF YORDAN FAIRUZHA (19.3041)','2021055055','Jahratul Jannah','2020000178',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:34:11',0,0),(1035,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ANDI FAKHRI LUBIS (193413)','2021055055','Jahratul Jannah','2020000179',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:35:24',0,0),(1036,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AINAYA AZZAHRA MALINI HASIBUAN (19.3212)','2021055055','Jahratul Jannah','2020000180',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:37:44',0,0),(1037,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AINI (19.3213)','2021055055','Jahratul Jannah','2020000181',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:39:01',0,0),(1038,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AINI AQILA SIREGAR (19.3214)','2021055055','Jahratul Jannah','2020000182',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:39:44',0,0),(1039,'2021-04-07','Pendataan besar pembayaran SPP Bulanan MTs siswa DELLA FAHRIKA ADHA (19.3247)','2021055055','Jahratul Jannah','2020000183',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:40:58',0,0),(1040,'2021-04-07','Pembayaran ke-1 SPP Bulanan MTs siswa DELLA FAHRIKA ADHA (19.3247)','2021055055','Jahratul Jannah','2020000184',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:43:04',0,0),(1041,'2021-04-07','Pendataan besar pembayaran SPP Bulanan MTs siswa DELIA PARAMITA (19.3246)','2021055055','Jahratul Jannah','2020000185',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:44:03',0,0),(1042,'2021-04-07','Pembayaran ke-1 SPP Bulanan MTs siswa DELIA PARAMITA (19.3246)','2021055055','Jahratul Jannah','2020000186',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-07 15:46:08',0,0),(1043,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AL ZANNAH NAYLA PUTRI (19.3216)','2021055055','Jahratul Jannah','2020000187',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:08:40',0,0),(1044,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AL ZANNAH NAYLA PUTRI (19.3216)','2021055055','Jahratul Jannah','2020000188',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:10:10',0,0),(1045,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ALYA KIRANI SIREGAR (19.3217)','2021055055','Jahratul Jannah','2020000189',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:11:36',0,0),(1046,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ALYA KIRANI SIREGAR (19.3217)','2021055055','Jahratul Jannah','2020000190',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:14:17',0,0),(1047,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ALYA SYAHPUTRI HASIBUAN (19.3218)','2021055055','Jahratul Jannah','2020000191',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:14:42',0,0),(1048,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ALYA SYAHPUTRI HASIBUAN (19.3218)','2021055055','Jahratul Jannah','2020000192',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:16:13',0,0),(1049,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AMELIA AYATIKA (19.3219)','2021055055','Jahratul Jannah','2020000193',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:16:52',0,0),(1050,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AMELIA AYATIKA (19.3219)','2021055055','Jahratul Jannah','2020000194',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:18:26',0,0),(1051,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ANDIENY FITRIA KIRANY (19.3220)','2021055055','Jahratul Jannah','2020000195',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:18:46',0,0),(1052,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANDIENY FITRIA KIRANY (19.3220)','2021055055','Jahratul Jannah','2020000196',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:20:15',0,0),(1053,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ANISA SUCI ARTIKA (19.3221)','2021055055','Jahratul Jannah','2020000197',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:20:40',0,0),(1054,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANISA SUCI ARTIKA (19.3221)','2021055055','Jahratul Jannah','2020000198',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:21:58',0,0),(1055,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ANNISA KHUMAIROH (19.3223)','2021055055','Jahratul Jannah','2020000199',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:22:21',0,0),(1056,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANNISA KHUMAIROH (19.3223)','2021055055','Jahratul Jannah','2020000200',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:23:26',0,0),(1057,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ANNISA SHAFIRA (19.3224)','2021055055','Jahratul Jannah','2020000201',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:23:46',0,0),(1058,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANNISA SHAFIRA (19.3224)','2021055055','Jahratul Jannah','2020000202',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:25:12',0,0),(1059,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ANNISA THOYYIBA HARAHAP (19.3225)','2021055055','Jahratul Jannah','2020000203',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:25:36',0,0),(1060,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANNISA THOYYIBA HARAHAP (19.3225)','2021055055','Jahratul Jannah','2020000204',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:26:28',0,0),(1061,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa APRIANI AULIA RAHMI (19.3226)','2021055055','Jahratul Jannah','2020000205',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:29:28',0,0),(1062,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa APRIANI AULIA RAHMI (19.3226)','2021055055','Jahratul Jannah','2020000206',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:32:07',0,0),(1063,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ARDWI YANTI (19.3228)','2021055055','Jahratul Jannah','2020000207',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:32:23',0,0),(1064,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ARDWI YANTI (19.3228)','2021055055','Jahratul Jannah','2020000208',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:34:08',0,0),(1065,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ARUM MITA SALSABILA (19.3229)','2021055055','Jahratul Jannah','2020000209',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:34:28',0,0),(1066,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ARUM MITA SALSABILA (19.3229)','2021055055','Jahratul Jannah','2020000210',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:35:38',0,0),(1067,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AS-SALWAH (19.3230)','2021055055','Jahratul Jannah','2020000211',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:36:12',0,0),(1068,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AS-SALWAH (19.3230)','2021055055','Jahratul Jannah','2020000212',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:37:25',0,0),(1069,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ATHAYA ZABRINA (19.3231)','2021055055','Jahratul Jannah','2020000213',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:37:58',0,0),(1070,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ATHAYA ZABRINA (19.3231)','2021055055','Jahratul Jannah','2020000214',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:41:41',0,0),(1071,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ATHAYA ZHARIFAH (19.3232)','2021055055','Jahratul Jannah','2020000215',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:43:28',0,0),(1072,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ATHAYA ZHARIFAH (19.3232)','2021055055','Jahratul Jannah','2020000216',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:44:25',0,0),(1073,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ATIKAH SYAHPUTRY HENKI (19.3233)','2021055055','Jahratul Jannah','2020000217',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:44:42',0,0),(1074,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ATIKAH SYAHPUTRY HENKI (19.3233)','2021055055','Jahratul Jannah','2020000218',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:45:38',0,0),(1075,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AULIA AZZAHRA (19.3235)','2021055055','Jahratul Jannah','2020000219',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:45:58',0,0),(1076,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AULIA AZZAHRA (19.3235)','2021055055','Jahratul Jannah','2020000220',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:47:08',0,0),(1077,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AZKIA SAKINAH (19.3237)','2021055055','Jahratul Jannah','2020000221',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:47:37',0,0),(1078,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZKIA SAKINAH (19.3237)','2021055055','Jahratul Jannah','2020000222',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:47:52',0,0),(1079,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AZRA SASKIA LAISYALIN PANE (19.3236)','2021055055','Jahratul Jannah','2020000223',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:48:21',0,0),(1080,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZRA SASKIA LAISYALIN PANE (19.3236)','2021055055','Jahratul Jannah','2020000224',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:49:14',0,0),(1081,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AZZUHRO AZRA IRHAMI (19.3238)','2021055055','Jahratul Jannah','2020000225',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:49:33',0,0),(1082,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZZUHRO AZRA IRHAMI (19.3238)','2021055055','Jahratul Jannah','2020000226',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:50:41',0,0),(1083,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa CERYAN PUTRI MOIZHA (19.3239)','2021055055','Jahratul Jannah','2020000227',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:51:00',0,0),(1084,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CERYAN PUTRI MOIZHA (19.3239)','2021055055','Jahratul Jannah','2020000228',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:52:06',0,0),(1085,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa CHICHI AULIA IRAWAN (19.3240)','2021055055','Jahratul Jannah','2020000229',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:52:24',0,0),(1086,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHICHI AULIA IRAWAN (19.3240)','2021055055','Jahratul Jannah','2020000230',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:54:12',0,0),(1087,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa CHIKA ALFIRA RYADI (19.3241)','2021055055','Jahratul Jannah','2020000231',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:55:12',0,0),(1088,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHIKA ALFIRA RYADI (19.3241)','2021055055','Jahratul Jannah','2020000232',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:56:08',0,0),(1089,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa CHIKA MEI ROZA (19.3242)','2021055055','Jahratul Jannah','2020000233',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:56:31',0,0),(1090,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHIKA MEI ROZA (19.3242)','2021055055','Jahratul Jannah','2020000234',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:57:27',0,0),(1091,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa CHINDY FRIKA OKTAPIA (19.3243)','2021055055','Jahratul Jannah','2020000235',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:57:44',0,0),(1092,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHINDY FRIKA OKTAPIA (19.3243)','2021055055','Jahratul Jannah','2020000236',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:59:28',0,0),(1093,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa CITRA DEWI LESTARI (19.3244)','2021055055','Jahratul Jannah','2020000237',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 13:59:46',0,0),(1094,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CITRA DEWI LESTARI (19.3244)','2021055055','Jahratul Jannah','2020000238',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 14:00:58',0,0),(1095,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa DEBY TASYA (19.3245)','2021055055','Jahratul Jannah','2020000239',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 14:01:22',0,0),(1096,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa DEBY TASYA (19.3245)','2021055055','Jahratul Jannah','2020000240',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 14:02:37',0,0),(1097,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AZRIL BURHAN KURNIADI (19.3049)','2021055055','Jahratul Jannah','2020000241',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:18:48',0,0),(1098,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZRIL BURHAN KURNIADI (19.3049)','2021055055','Jahratul Jannah','2020000242',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:21:09',0,0),(1099,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa AZRIL DWI SAPUTRA (19.3050)','2021055055','Jahratul Jannah','2020000243',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:21:29',0,0),(1100,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZRIL DWI SAPUTRA (19.3050)','2021055055','Jahratul Jannah','2020000244',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:23:42',0,0),(1101,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa BANGUN GEMILANG SUDIRYO (19.3051)','2021055055','Jahratul Jannah','2020000245',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:23:55',0,0),(1102,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BANGUN GEMILANG SUDIRYO (19.3051)','2021055055','Jahratul Jannah','2020000246',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:25:08',0,0),(1103,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa BAYU ARIA FATTAH (19.3052)','2021055055','Jahratul Jannah','2020000247',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:25:31',0,0),(1104,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BAYU ARIA FATTAH (19.3052)','2021055055','Jahratul Jannah','2020000248',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:27:09',0,0),(1105,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa BILLAL AL HABSHI SIAGIAN (19.3053)','2021055055','Jahratul Jannah','2020000249',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:27:36',0,0),(1106,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BILLAL AL HABSHI SIAGIAN (19.3053)','2021055055','Jahratul Jannah','2020000250',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:28:51',0,0),(1107,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa BILLI RAHMADI (19.3054)','2021055055','Jahratul Jannah','2020000251',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:29:03',0,0),(1108,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BILLI RAHMADI (19.3054)','2021055055','Jahratul Jannah','2020000252',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:30:37',0,0),(1109,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa BIMA RAY ANGGARA (19.3055)','2021055055','Jahratul Jannah','2020000253',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:31:04',0,0),(1110,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BIMA RAY ANGGARA (19.3055)','2021055055','Jahratul Jannah','2020000254',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:32:10',0,0),(1111,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa BREMA KHAIRIL ALFI SYAHRI (19.3056)','2021055055','Jahratul Jannah','2020000255',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:32:54',0,0),(1112,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BREMA KHAIRIL ALFI SYAHRI (19.3056)','2021055055','Jahratul Jannah','2020000256',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:35:54',0,0),(1113,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa ZESSYCA VANEZA (19.3401)','2021055055','Jahratul Jannah','2020000257',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:36:38',0,0),(1114,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ZESSYCA VANEZA (19.3401)','2021055055','Jahratul Jannah','2020000258',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:38:42',0,0),(1115,'2021-04-15','Pendataan besar pembayaran SPP Bulanan MTs siswa REGINA CAHYANING ADINDA PANGESTI (20.3842)','2021055055','Jahratul Jannah','2020000259',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:40:31',0,0),(1116,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa REGINA CAHYANING ADINDA PANGESTI (20.3842)','2021055055','Jahratul Jannah','2020000260',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-15 20:53:29',0,0),(1117,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DAHLAN HARAHAP (19.3058)','2021055055','Jahratul Jannah','2020000261',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:07:59',0,0),(1118,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DAHLAN HARAHAP (19.3058)','2021055055','Jahratul Jannah','2020000262',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:09:06',0,0),(1119,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DEDY FIRMANSYAH PUTRA (19.3060)','2021055055','Jahratul Jannah','2020000263',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:09:51',0,0),(1120,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DEDY FIRMANSYAH PUTRA (19.3060)','2021055055','Jahratul Jannah','2020000264',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:13:14',0,0),(1121,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DENY IRWANSYAH (19.3061)','2021055055','Jahratul Jannah','2020000265',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:13:41',0,0),(1122,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DENY IRWANSYAH (19.3061)','2021055055','Jahratul Jannah','2020000266',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:14:57',0,0),(1123,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DESTA SYAPUTRA MALAU (19.3062)','2021055055','Jahratul Jannah','2020000267',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:15:24',0,0),(1124,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DESTA SYAPUTRA MALAU (19.3062)','2021055055','Jahratul Jannah','2020000268',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:16:28',0,0),(1125,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DICKY PRANATA (19.3063)','2021055055','Jahratul Jannah','2020000269',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:18:30',0,0),(1126,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DICKY PRANATA (19.3063)','2021055055','Jahratul Jannah','2020000270',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:20:16',0,0),(1127,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DIMAS NAJMI ALHABSYI (19.3064)','2021055055','Jahratul Jannah','2020000271',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:21:25',0,0),(1128,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIMAS NAJMI ALHABSYI (19.3064)','2021055055','Jahratul Jannah','2020000272',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:22:51',0,0),(1129,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DIMASTHYA (19.3065)','2021055055','Jahratul Jannah','2020000273',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:23:13',0,0),(1130,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIMASTHYA (19.3065)','2021055055','Jahratul Jannah','2020000274',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:25:14',0,0),(1131,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DIMAZ ABDILLAH SHAUQI (19.3066)','2021055055','Jahratul Jannah','2020000275',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:31:20',0,0),(1132,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIMAZ ABDILLAH SHAUQI (19.3066)','2021055055','Jahratul Jannah','2020000276',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:32:21',0,0),(1133,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DIRLAN REVIANSYAH SITOMPUL (19.3067)','2021055055','Jahratul Jannah','2020000277',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:32:53',0,0),(1134,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIRLAN REVIANSYAH SITOMPUL (19.3067)','2021055055','Jahratul Jannah','2020000278',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:33:51',0,0),(1135,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa DWI AL FATH AZZAKI (19.3068)','2021055055','Jahratul Jannah','2020000279',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 19:36:11',0,0),(1136,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DWI AL FATH AZZAKI (19.3068)','2021055055','Jahratul Jannah','2020000280',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:04:23',0,0),(1137,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa ERI RAMADONI MANURUNG (19.3071)','2021055055','Jahratul Jannah','2020000281',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:04:50',0,0),(1138,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa ERI RAMADONI MANURUNG (19.3071)','2021055055','Jahratul Jannah','2020000282',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:06:30',0,0),(1139,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FAJAR RIZKY AKBAR (19.3072)','2021055055','Jahratul Jannah','2020000283',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:08:47',0,0),(1140,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAJAR RIZKY AKBAR (19.3072)','2021055055','Jahratul Jannah','2020000284',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:10:15',0,0),(1141,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FARHAN AINAL PUTRA (19.3073)','2021055055','Jahratul Jannah','2020000285',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:10:44',0,0),(1142,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FARHAN AINAL PUTRA (19.3073)','2021055055','Jahratul Jannah','2020000286',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:11:35',0,0),(1143,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FARHAN FUADI LAOLI (19.3074)','2021055055','Jahratul Jannah','2020000287',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:11:59',0,0),(1144,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FARHAN FUADI LAOLI (19.3074)','2021055055','Jahratul Jannah','2020000288',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:12:58',0,0),(1145,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FARID IZWARY (19.3075)','2021055055','Jahratul Jannah','2020000289',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:15:29',0,0),(1146,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FARID IZWARY (19.3075)','2021055055','Jahratul Jannah','2020000290',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:17:54',0,0),(1147,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FATIH AL BAHRI (19.3077)','2021055055','Jahratul Jannah','2020000291',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:18:54',0,0),(1148,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FATIH AL BAHRI (19.3077)','2021055055','Jahratul Jannah','2020000292',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:20:36',0,0),(1149,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FAUZI AHMAD HARAHAP (19.3079)','2021055055','Jahratul Jannah','2020000293',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:21:11',0,0),(1150,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAUZI AHMAD HARAHAP (19.3079)','2021055055','Jahratul Jannah','2020000294',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:22:19',0,0),(1151,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FAZA ALFARISI HARAHAP (19.3080)','2021055055','Jahratul Jannah','2020000295',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:22:55',0,0),(1152,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAZA ALFARISI HARAHAP (19.3080)','2021055055','Jahratul Jannah','2020000296',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:25:26',0,0),(1153,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FAZRUL RINGGO RITONGA (19.3081)','2021055055','Jahratul Jannah','2020000297',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:27:49',0,0),(1154,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAZRUL RINGGO RITONGA (19.3081)','2021055055','Jahratul Jannah','2020000298',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:29:13',0,0),(1155,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FERDIANSYAH (19.3082)','2021055055','Jahratul Jannah','2020000299',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:29:50',0,0),(1156,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FERDIANSYAH (19.3082)','2021055055','Jahratul Jannah','2020000300',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:31:56',0,0),(1157,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FIKRIE ANSYAH FAHRIZA RITONGA (19.3083)','2021055055','Jahratul Jannah','2020000301',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:32:19',0,0),(1158,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FIKRIE ANSYAH FAHRIZA RITONGA (19.3083)','2021055055','Jahratul Jannah','2020000302',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:33:50',0,0),(1159,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa FRIMA DANI (19.3084)','2021055055','Jahratul Jannah','2020000303',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:34:28',0,0),(1160,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FRIMA DANI (19.3084)','2021055055','Jahratul Jannah','2020000304',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:35:56',0,0),(1161,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa GALANG FEBRIANSYAH (19.3085)','2021055055','Jahratul Jannah','2020000305',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:36:45',0,0),(1162,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa GALANG FEBRIANSYAH (19.3085)','2021055055','Jahratul Jannah','2020000306',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:37:52',0,0),(1163,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa GALU INDRA PRIMAYUDA (19.3086)','2021055055','Jahratul Jannah','2020000307',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:38:13',0,0),(1164,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa GALU INDRA PRIMAYUDA (19.3086)','2021055055','Jahratul Jannah','2020000308',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:39:16',0,0),(1165,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa GHOFAR ISMAIL (19.3087)','2021055055','Jahratul Jannah','2020000309',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:39:41',0,0),(1166,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa GHOFAR ISMAIL (19.3087)','2021055055','Jahratul Jannah','2020000310',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:41:09',0,0),(1167,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa RASYA ARDANA UTAMA (19.3168)','2021055055','Jahratul Jannah','2020000311',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:42:08',0,0),(1168,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa RASYA ARDANA UTAMA (19.3168)','2021055055','Jahratul Jannah','2020000312',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:43:22',0,0),(1169,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa IRHAM MAULANA RITONGA (19.3102)','2021055055','Jahratul Jannah','2020000313',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:43:39',0,0),(1170,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa IRHAM MAULANA RITONGA (19.3102)','2021055055','Jahratul Jannah','2020000314',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:44:47',0,0),(1171,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa ZULPAN EFENDI HARAHAP (20.3840)','2021055055','Jahratul Jannah','2020000315',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:46:02',0,0),(1172,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa ZULPAN EFENDI HARAHAP (20.3840)','2021055055','Jahratul Jannah','2020000316',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:47:19',0,0),(1173,'2021-04-16','Pendataan besar pembayaran SPP Bulanan MTs siswa ABID AL-BANJARI (18.2709)','2021055055','Jahratul Jannah','2020000317',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:48:20',0,0),(1174,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa ABID AL-BANJARI (18.2709)','2021055055','Jahratul Jannah','2020000318',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-16 21:49:14',0,0),(1175,'2021-04-17','Pendataan besar pembayaran SPP Bulanan MTs siswa DESI RAHMAWATI (19.3248)','2021055055','Jahratul Jannah','2020000319',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 18:40:37',0,0),(1176,'2021-04-17','Pelunasan SPP Bulanan MTs siswa DESI RAHMAWATI (19.3248)','2021055055','Jahratul Jannah','2020000320',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 18:42:26',0,0),(1177,'2021-04-17','Pendataan besar pembayaran SPP Bulanan MTs siswa DEVINA ALFANI (19.3249)','2021055055','Jahratul Jannah','2020000321',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 18:42:50',0,0),(1178,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DEVINA ALFANI (19.3249)','2021055055','Jahratul Jannah','2020000322',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 18:43:43',0,0),(1179,'2021-04-17','Pendataan besar pembayaran SPP Bulanan MTs siswa DHEA RAMA FITRIANI (19.3250)','2021055055','Jahratul Jannah','2020000323',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 18:52:17',0,0),(1180,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DHEA RAMA FITRIANI (19.3250)','2021055055','Jahratul Jannah','2020000324',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 19:47:08',0,0),(1181,'2021-04-17','Pendataan besar pembayaran SPP Bulanan MTs siswa DINA LESTARI HARAHAP (19.3251)','2021055055','Jahratul Jannah','2020000325',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 19:50:10',0,0),(1182,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DINA LESTARI HARAHAP (19.3251)','2021055055','Jahratul Jannah','2020000326',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 19:53:05',0,0),(1183,'2021-04-17','Pendataan besar pembayaran SPP Bulanan MTs siswa DINDA AYU ALANDIN (19.3253)','2021055055','Jahratul Jannah','2020000327',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 20:39:28',0,0),(1184,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DINDA AYU ALANDIN (19.3253)','2021055055','Jahratul Jannah','2020000328',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-17 20:41:03',0,0),(1185,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DINDA NURUL HIZZA PANE (19.3254)','2021055055','Jahratul Jannah','2020000329',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:22:59',0,0),(1186,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DINDA NURUL HIZZA PANE (19.3254)','2021055055','Jahratul Jannah','2020000330',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:25:21',0,0),(1187,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DINI AUDIRA NASUTION (19.3255)','2021055055','Jahratul Jannah','2020000331',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:25:43',0,0),(1188,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DINI AUDIRA NASUTION (19.3255)','2021055055','Jahratul Jannah','2020000332',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:26:01',0,0),(1189,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DIVA ILYASHA (19.3256)','2021055055','Jahratul Jannah','2020000333',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:27:02',0,0),(1190,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DIVA ILYASHA (19.3256)','2021055055','Jahratul Jannah','2020000334',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:28:16',0,0),(1191,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DIVA JAGAD INDRALOKA (19.3257)','2021055055','Jahratul Jannah','2020000335',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:32:20',0,0),(1192,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DIVA JAGAD INDRALOKA (19.3257)','2021055055','Jahratul Jannah','2020000336',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:33:29',0,0),(1193,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DONA AGNESIA (19.3258)','2021055055','Jahratul Jannah','2020000337',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:36:32',0,0),(1194,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DONA AGNESIA (19.3258)','2021055055','Jahratul Jannah','2020000338',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:38:04',0,0),(1195,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DWI ASRI RAMADHANI WIDODO (19.3259)','2021055055','Jahratul Jannah','2020000339',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:39:03',0,0),(1196,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DWI ASRI RAMADHANI WIDODO (19.3259)','2021055055','Jahratul Jannah','2020000340',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:40:22',0,0),(1197,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa DYAH USWATUN HASANAH (19.3260)','2021055055','Jahratul Jannah','2020000341',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:40:43',0,0),(1198,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DYAH USWATUN HASANAH (19.3260)','2021055055','Jahratul Jannah','2020000342',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:42:06',0,0),(1199,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa EKA SARY HUTABARAT (19.3415)','2021055055','Jahratul Jannah','2020000343',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:43:01',0,0),(1200,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa EKA SARY HUTABARAT (19.3415)','2021055055','Jahratul Jannah','2020000344',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:48:01',0,0),(1201,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa ELISA JULIYANTI (19.3261)','2021055055','Jahratul Jannah','2020000345',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:48:43',0,0),(1202,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa ELISA JULIYANTI (19.3261)','2021055055','Jahratul Jannah','2020000346',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 09:50:27',0,0),(1203,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa ESYA TRIAHANI HASIBUAN (19.3262)','2021055055','Jahratul Jannah','2020000347',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:16:59',0,0),(1204,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa ESYA TRIAHANI HASIBUAN (19.3262)','2021055055','Jahratul Jannah','2020000348',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:17:51',0,0),(1205,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FADHILAH ANA YUSUF (19.3264)','2021055055','Jahratul Jannah','2020000349',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:18:34',0,0),(1206,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FADHILAH ANA YUSUF (19.3264)','2021055055','Jahratul Jannah','2020000350',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:19:34',0,0),(1207,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FASHA SYAVIRA (19.3266)','2021055055','Jahratul Jannah','2020000351',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:20:17',0,0),(1208,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FASHA SYAVIRA (19.3266)','2021055055','Jahratul Jannah','2020000352',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:21:32',0,0),(1209,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FATHAN ULFAH (19.3267)','2021055055','Jahratul Jannah','2020000353',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:22:01',0,0),(1210,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FATHAN ULFAH (19.3267)','2021055055','Jahratul Jannah','2020000354',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:23:18',0,0),(1211,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa PATIMAH INDIRA PUTRI (19.3268)','2021055055','Jahratul Jannah','2020000355',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:25:00',0,0),(1212,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa PATIMAH INDIRA PUTRI (19.3268)','2021055055','Jahratul Jannah','2020000356',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:26:15',0,0),(1213,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FAZHIRA NASYWA RAMZY (19.3269)','2021055055','Jahratul Jannah','2020000357',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:26:57',0,0),(1214,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FAZHIRA NASYWA RAMZY (19.3269)','2021055055','Jahratul Jannah','2020000358',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:28:55',0,0),(1215,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FEBRIYANI SAFITRI (19.3270)','2021055055','Jahratul Jannah','2020000359',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:29:32',0,0),(1216,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FEBRIYANI SAFITRI (19.3270)','2021055055','Jahratul Jannah','2020000360',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:31:07',0,0),(1217,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FITRIA ZAHRO HASIBUAN (19.3271)','2021055055','Jahratul Jannah','2020000361',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:37:14',0,0),(1218,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FITRIA ZAHRO HASIBUAN (19.3271)','2021055055','Jahratul Jannah','2020000362',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:38:29',0,0),(1219,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa FITRIANA SIREGAR (19.3272)','2021055055','Jahratul Jannah','2020000363',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:39:13',0,0),(1220,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FITRIANA SIREGAR (19.3272)','2021055055','Jahratul Jannah','2020000364',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:40:55',0,0),(1221,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa GHEFIRA KHOLILY (19.3273)','2021055055','Jahratul Jannah','2020000365',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:41:40',0,0),(1222,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa GHEFIRA KHOLILY (19.3273)','2021055055','Jahratul Jannah','2020000366',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:42:52',0,0),(1223,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa HENI NOVIA SILALAHI (19.3274)','2021055055','Jahratul Jannah','2020000367',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:48:12',0,0),(1224,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HENI NOVIA SILALAHI (19.3274)','2021055055','Jahratul Jannah','2020000368',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:51:11',0,0),(1225,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa HENISYA NAZWA NST (19.3275)','2021055055','Jahratul Jannah','2020000369',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:51:54',0,0),(1226,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HENISYA NAZWA NST (19.3275)','2021055055','Jahratul Jannah','2020000370',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:52:59',0,0),(1227,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa HENNY FITRI HASANAH (19.3276)','2021055055','Jahratul Jannah','2020000371',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:53:28',0,0),(1228,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HENNY FITRI HASANAH (19.3276)','2021055055','Jahratul Jannah','2020000372',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 10:54:22',0,0),(1229,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa INDHY FEBRIYANTI ARYUNDA SUKMA (19.3278)','2021055055','Jahratul Jannah','2020000373',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:15:08',0,0),(1230,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa INDHY FEBRIYANTI ARYUNDA SUKMA (19.3278)','2021055055','Jahratul Jannah','2020000374',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:16:58',0,0),(1231,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa INTAN FITRIANI (19.3279)','2021055055','Jahratul Jannah','2020000375',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:17:28',0,0),(1232,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa INTAN FITRIANI (19.3279)','2021055055','Jahratul Jannah','2020000376',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:18:37',0,0),(1233,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa ISMA DUIYANI (19.3280)','2021055055','Jahratul Jannah','2020000377',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:19:00',0,0),(1234,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa ISMA DUIYANI (19.3280)','2021055055','Jahratul Jannah','2020000378',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:19:52',0,0),(1235,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa JANNATUL SAKDIAH HASIBUAN (19.3281)','2021055055','Jahratul Jannah','2020000379',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:20:51',0,0),(1236,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa JANNATUL SAKDIAH HASIBUAN (19.3281)','2021055055','Jahratul Jannah','2020000380',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:22:22',0,0),(1237,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa KADHZIYAH ALFIRANI SYAHPUTRI (19.3282)','2021055055','Jahratul Jannah','2020000381',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:22:43',0,0),(1238,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KADHZIYAH ALFIRANI SYAHPUTRI (19.3282)','2021055055','Jahratul Jannah','2020000382',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:23:54',0,0),(1239,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa KARINDA EKA APRILA (19.3283)','2021055055','Jahratul Jannah','2020000383',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:24:24',0,0),(1240,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KARINDA EKA APRILA (19.3283)','2021055055','Jahratul Jannah','2020000384',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:25:21',0,0),(1241,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa KAYLA JOEYA ARTIFA (19.3284)','2021055055','Jahratul Jannah','2020000385',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:25:48',0,0),(1242,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KAYLA JOEYA ARTIFA (19.3284)','2021055055','Jahratul Jannah','2020000386',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:27:08',0,0),(1243,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa KESYA ANDIRA BR DAMANIK (19.3285)','2021055055','Jahratul Jannah','2020000387',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:27:41',0,0),(1244,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KESYA ANDIRA BR DAMANIK (19.3285)','2021055055','Jahratul Jannah','2020000388',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:28:47',0,0),(1245,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa KESYA AURA NADINE (19.3286)','2021055055','Jahratul Jannah','2020000389',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:29:08',0,0),(1246,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KESYA AURA NADINE (19.3286)','2021055055','Jahratul Jannah','2020000390',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:30:56',0,0),(1247,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa AZRA TIFFATUL PARAPAT (19.3048)','2021055055','Jahratul Jannah','2020000391',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:32:33',0,0),(1248,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa AZRA TIFFATUL PARAPAT (19.3048)','2021055055','Jahratul Jannah','2020000392',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:33:23',0,0),(1249,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa HABIB ALBAR NASUTION (19.3088)','2021055055','Jahratul Jannah','2020000393',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:33:42',0,0),(1250,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HABIB ALBAR NASUTION (19.3088)','2021055055','Jahratul Jannah','2020000394',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:34:37',0,0),(1251,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa HABIB AZHARI (19.3089)','2021055055','Jahratul Jannah','2020000395',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:34:47',0,0),(1252,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HABIB AZHARI (19.3089)','2021055055','Jahratul Jannah','2020000396',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:35:37',0,0),(1253,'2021-04-18','Pendataan besar pembayaran SPP Bulanan MTs siswa HABIBI ILHAM (19.3090)','2021055055','Jahratul Jannah','2020000397',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:35:51',0,0),(1254,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HABIBI ILHAM (19.3090)','2021055055','Jahratul Jannah','2020000398',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-18 11:37:11',0,0),(1255,'2021-04-19','Pembayaran ke-2 SPP Bulanan MTs siswa ADITYA PRATAMA (19.3020)','2021055055','Jahratul Jannah','2020000399',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 09:22:50',0,0),(1256,'2021-04-19','Pembayaran ke-2 SPP Bulanan MTs siswa ALI ARDIANSYAH (19.3029)','2021055055','Jahratul Jannah','2020000400',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 09:23:47',0,0),(1257,'2021-04-19','Pembayaran ke-2 SPP Bulanan MTs siswa AMAR FAISZ (19.3033)','2021055055','Jahratul Jannah','2020000401',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 09:24:28',0,0),(1258,'2021-04-19','Pendataan besar pembayaran SPP Bulanan MTs siswa HABIBI MAULANA (19.3091)','2021055055','Jahratul Jannah','2020000402',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 11:16:09',0,0),(1259,'2021-04-19','Pembayaran ke-1 SPP Bulanan MTs siswa HABIBI MAULANA (19.3091)','2021055055','Jahratul Jannah','2020000403',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 11:22:18',0,0),(1260,'2021-04-19','Pendataan besar pembayaran SPP Bulanan MTs siswa HANIF ALFATA (19.3092)','2021055055','Jahratul Jannah','2020000404',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 11:22:53',0,0),(1261,'2021-04-19','Pembayaran ke-1 SPP Bulanan MTs siswa HANIF ALFATA (19.3092)','2021055055','Jahratul Jannah','2020000405',2,'','penerimaanjtt',NULL,NULL,NULL,'2021-04-19 11:24:14',0,0),(1262,'2021-07-12','Pendataan besar pembayaran SPP Bulanan MA siswa NURFARAHIM (19.2368)','2021006006','Jahratul Jannah S.Pd','2020000039',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 20:50:24',0,0),(1263,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa NURFARAHIM (19.2368)','2021006006','Jahratul Jannah S.Pd','2020000040',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 20:52:50',0,0),(1264,'2021-07-12','Pendataan besar pembayaran SPP Bulanan MA siswa RIZAL SYAHDANI SIREGAR (20.2531)','2021006006','Jahratul Jannah S.Pd','2020000041',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 20:55:07',0,0),(1265,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa RIZAL SYAHDANI SIREGAR (20.2531)','2021006006','Jahratul Jannah S.Pd','2020000042',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 20:57:09',0,0),(1266,'2021-07-12','Pendataan besar pembayaran SPP Bulanan MA siswa CINDY BUDI MALIHAH (19.2394)','2021006006','Jahratul Jannah S.Pd','2020000043',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 21:33:48',0,0),(1267,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa CINDY BUDI MALIHAH (19.2394)','2021006006','Jahratul Jannah S.Pd','2020000044',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 21:33:59',0,0),(1268,'2021-07-12','Pendataan besar pembayaran SPP Bulanan MA siswa RIO ARDANA HARAHAP (20.2493)','2021006006','Jahratul Jannah S.Pd','2020000045',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 21:34:34',0,0),(1269,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa RIO ARDANA HARAHAP (20.2493)','2021006006','Jahratul Jannah S.Pd','2020000046',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 21:35:08',0,0),(1270,'2021-07-12','Pendataan besar pembayaran SPP Bulanan MA siswa MUHAMMAD RASYID RIDHO (20.2484)','2021006006','Jahratul Jannah S.Pd','2020000047',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 21:35:40',0,0),(1271,'2021-07-12','Pelunasan SPP Bulanan MA siswa MUHAMMAD RASYID RIDHO (20.2484)','2021006006','Jahratul Jannah S.Pd','2020000048',1,'','penerimaanjtt',NULL,NULL,NULL,'2021-07-12 21:37:25',0,0);

#
# Structure for table "tabunganp"
#

DROP TABLE IF EXISTS `jbsfina`.`tabunganp`;
CREATE TABLE `jbsfina`.`tabunganp` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idtabungan` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `nip` varchar(30) CHARACTER SET utf8 NOT NULL,
  `debet` decimal(15,0) NOT NULL,
  `kredit` decimal(15,0) NOT NULL,
  `petugas` varchar(30) CHARACTER SET utf8 NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `ispayment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_tabunganp_datatabungan` (`idtabungan`),
  KEY `FK_tabunganp_jurnal` (`idjurnal`),
  KEY `FK_tabunganp_pegawai` (`nip`),
  CONSTRAINT `FK_tabunganp_datatabungan` FOREIGN KEY (`idtabungan`) REFERENCES `jbsfina`.`datatabungan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_tabunganp_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_tabunganp_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "tabunganp"
#


#
# Structure for table "tabungan"
#

DROP TABLE IF EXISTS `jbsfina`.`tabungan`;
CREATE TABLE `jbsfina`.`tabungan` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idtabungan` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` datetime NOT NULL,
  `nis` varchar(20) CHARACTER SET utf8 NOT NULL,
  `debet` decimal(15,0) NOT NULL,
  `kredit` decimal(15,0) NOT NULL,
  `petugas` varchar(30) CHARACTER SET utf8 NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `ispayment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_tabungan_datatabungan` (`idtabungan`),
  KEY `FK_tabungan_jurnal` (`idjurnal`),
  KEY `FK_tabungan_siswa` (`nis`),
  CONSTRAINT `FK_tabungan_datatabungan` FOREIGN KEY (`idtabungan`) REFERENCES `jbsfina`.`datatabungan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_tabungan_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_tabungan_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "tabungan"
#


#
# Structure for table "penerimaanjtt"
#

DROP TABLE IF EXISTS `jbsfina`.`penerimaanjtt`;
CREATE TABLE `jbsfina`.`penerimaanjtt` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idbesarjtt` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT ' ',
  `paymentid` varchar(20) DEFAULT NULL,
  `isschoolpay` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pembayaranjtt_besatjtt` (`idbesarjtt`),
  KEY `FK_pembayaranjtt_jurnal` (`idjurnal`),
  KEY `IX_penerimaanjtt_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pembayaranjtt_besatjtt` FOREIGN KEY (`idbesarjtt`) REFERENCES `jbsfina`.`besarjtt` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pembayaranjtt_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=496 DEFAULT CHARSET=utf8;

#
# Data for table "penerimaanjtt"
#

INSERT INTO `penerimaanjtt` VALUES (36,36,72,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',19074,0),(37,37,74,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',39395,0),(38,38,76,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',52596,0),(39,39,78,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',54986,0),(40,40,80,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',47125,0),(41,41,82,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',7312,0),(42,42,84,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',42443,0),(43,43,86,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',19785,0),(44,44,88,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',59456,0),(45,45,90,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',34180,0),(46,46,92,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',48780,0),(47,47,94,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',29431,0),(48,48,96,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',54635,0),(49,49,98,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',52355,0),(50,50,100,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',44320,0),(51,51,102,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',43227,0),(52,52,104,'2021-04-01',0,'','Supria Ningsih',' ',NULL,1,'0',NULL,NULL,'2021-04-01 23:07:10',29241,0),(53,53,106,'2021-04-03',5400000,'pembyarn bulan juli s. maret 2021 ( 8/8/20, 12/9/20, 10/10/20, 20/11/20, 14/12/20, 21/01/21, 17/2/21, 16/3/21 )','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:11:50',39229,0),(54,54,108,'2021-04-03',5400000,'pembyran juli s. d maret 2021 ( 8/10/20, 15/9/20, 10/10/20, 27/11/20, 18/12/21, 5/2/21, 23/2/21, 16/3/21 )','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:17:54',48245,0),(55,55,110,'2021-04-03',5400000,'sudah bayar dari juli s.d maret 2021 (15/7/20, 26/7/20, 8/8/20, 4/10/20, 3/11/20, 29/11/20, 21/1-21, 5/2/21, 6/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:26:01',31136,0),(283,56,793,'2021-04-03',5400000,'sudah bayar dari bulan juli s.d maret 2021 (15/7/20, 8/8/20, 12/9/20, 19/10/20, 17/11/20, 16/12/20, 27/1/21, 13/2/21, 24/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:36:10',52516,0),(284,511,796,'2021-04-03',5400000,'sudah bayar dari bulan juli s.d maret 2021 (15/7/20, 20/7/20, 3/9/20, 01/10/20, 11/11/20, 29/11/20, 21/1/21, 11/2/21, 13/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:39:15',64545,0),(285,512,865,'2021-04-03',4500000,'pembayaran juli s/d maret (25/7/20, 26/10/20, 26/10/21, 10/12/20, 10/12/20, 13/3/21,  13/3/21,  13/3/21,','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:43:47',9197,0),(286,581,867,'2021-04-03',5100000,'pembayaran juli s/d maret (25/7/20, 19/8/20, 10/9/20, 23/10/20, 13/11/20, 10/12/20, 21/1/21, 17/2/21, 16/3/21','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-03 11:51:38',25027,0),(287,582,869,'2021-04-03',2100000,'PEMBAYARAN DARI BULAN JULI S.D OKTOBER 2020 (15/7/20, 11/10/20, 14/12/20)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:02:53',29037,0),(288,513,871,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 (15/7/20, 20/7/20, 12/9/20, 10/10/20, 11/11/20, 4/12/20, 21/1/21, 5/2/21, 13/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:24:46',7186,0),(289,584,873,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d  MARET 2021 (15/7/20, 8/8/20, 19/9/20, 12/10/20, 7/11/20, 16/12/20, 2/2/21, 27/2/21, 27/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:30:40',49429,0),(290,585,875,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 (15/7/20, 12/8/20, 19/9/20, 17/10/20, 7/11/20, 7/11/20, 21/1/21, 11/2/21, 24/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:34:43',31388,0),(291,586,877,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 (15/7/20, 9/8/20, 03/10/20, 12/09/20, 4/11/20, 21/1/21/ 13/2/21, 6/3/21 ','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:39:15',52609,0),(292,587,879,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 (15/7/20, 9/8/20, 19/9/20, 9/10/20, 11/11/20, 10/12/20, 21/1/21, 13/2/21, 16/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:44:08',48271,0),(293,588,881,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 (15/7/20, 8/8/20, 19/9/20, 10/10/20, 11/11/20, 10/12/20, 21/1/21/ 13/2/21, 8/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:49:22',37213,0),(294,589,883,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 (15/7/20, 8/8/20, 19/9/20, 16/10/20, 11/11/20, 16/12/20, 30/1/21, 17/2/21, 25/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 12:56:41',37583,0),(295,590,885,'2021-04-03',5400000,'SUDAH BAYAR DARI BULAN JULI s.d MARET 2021 ( 15/7/20, 9/8/20, 12/9/20, 09/10/20, 17/11/2O, 28/12/21, 11/2/21, 11/2/21, 6/3/21','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-03 14:11:24',59416,0),(296,591,887,'2021-04-03',5400000,'sudah bayar dari bulan juli s.d maret 2021 (21/7/20, 12/8/20, 15/9/20, 15/11/20, 16/12/21, 18/1/21, 24/2/21, 20/3/21)','Rika Erliani Harahap',' ',NULL,1,'0',NULL,NULL,'2021-04-03 23:04:22',13186,0),(297,592,889,'2021-04-04',5400000,'sudah bayar dari bulan juli s.d bulan maret 2021, (15/7/20, 8/8/20, 8/9/20, 7/10/20, 5/11/20, 9/12/20, 21/1/21, 8/2/21, 8/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-04 09:12:45',55550,0),(298,593,891,'2021-04-04',5400000,'sudah bayar dari bulan juli s.d bulan maret 2021 (15/7/20, 12/8/20, 20/9/20, 12/10/20, 11/11/20, 10/12/20, 21/1/21, 11/2/21, 13/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-04 09:17:10',48152,0),(299,594,893,'2021-04-04',5400000,'sudah bayar dari bulan juli sampai dengan bulan maret 2021 (15/7/20, 8/8/20, 19/9/20, 10/10/20, 11/11/20, 4/12/20, 21/1/21/ 13/2/21, 8/3/21) ','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-04 09:22:52',44497,0),(300,583,895,'2021-04-05',2700000,'PEMBAYARAN BULAN JULI S/D DESEMBER (2/9/20, 2/9/20,17/11/20, 17/11/20, 17/11/20, 17/11/20)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 07:37:40',41170,0),(301,596,897,'2021-04-05',5100000,'PEMBAYARAN BULAN JULI S/D MARET (25/7/20, 22/8, 24/9, 29/10, 22/11, 10/12, 24/1/21, 6/3, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 07:48:42',27781,0),(302,597,899,'2021-04-05',5100000,'PEMBAYARAN BULAN JULI S/D MARET (19/7/20, 19/8, 12/9, 19/10, 11/11, 10/12, 27/1/21, 11/2, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 07:50:31',33277,0),(303,598,901,'2021-04-05',5100000,'PEMBAYARAN BULAN JULI S/D MARET (25/7/20, 19/8, 24/9, 26/10, 24/11, 23/2/21, 23/2, 27/2, 25/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 07:52:42',62307,0),(304,599,903,'2021-04-05',6900000,'PEMBAYARAN JULI 2020 S/D JUNI 2021 ( 27/11/20 BAYAR RP. 4.500.000, 3/3/21 BAYAR RP. 1.600.000, 27/3/21 BAYAR RP. 800.000','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 07:56:23',9820,0),(305,595,904,'2021-04-05',5400000,'SUDAH MEMBAYAR DARI BULAN JULI S.D BULAN MARET 2021 (15-7-20/ 10-8-20/ 14-9-20/ 09-10-20/ 11-11-20/ 13-12-20/ 21-1-21/ 11-2-21/\t20-3-21)\r\n','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:02:41',59921,0),(306,600,906,'2021-04-05',4500000,'PEMBAYARAN BULAN JULI S/D MARET FEBRUARI (22/8/20 BAYAR 900.000,  14/12/20 BAYAR RP. 1.800.000, 27/12/20 RP. 600.000, 24/3/21 RP. 1.200.000 ','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:07:49',35293,0),(307,601,908,'2021-04-05',4800000,'SUDAH MEMBAYAR DARI BULAN JULI S.D FEBRUARI 2021 (15-7-20/\t12-8-20/\t29-10-20/\t11-11-20/\t29-11-20/\t28-12-20/ 2-2-21/ 2-2-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:15:58',58949,0),(308,603,911,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 12-8-20/ 12-9-20/ 07-10-20/ 11-11-20/ 4-12-20/ 21-21/ 11-2-21/ 8-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:21:14',43451,0),(309,604,913,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/\t8-8-20/ 10-9-20/ 10-10-20/\t4-11-20/ 8-12-20/ 21-1-21/ 17-2-21/ 27-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:28:47',37021,0),(310,602,915,'2021-04-05',5060000,'PEMBAYARAN BULAN JULI S/D MARET (19/8/20, 28/8, 6/9, 19/10, 8/11, 20/11, 31/1/21, 31/1/, 6/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:31:00',55428,0),(311,605,917,'2021-04-05',4800000,'Sudah Bayar dari Bulan Juli s.d februari 2021 (15-7-20/ 8-8-20/ 29-09-20/ 09-10-20/  6-11-20/ 16-12-20/ 13-2-21/ 13-2-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:32:57',16045,0),(312,607,919,'2021-04-05',4800000,'Sudah Bayar dari Bulan Juli s.d Februari 2021 (15-7-20/ 29-8-20/ 09-11-20/ 09-11-20/ 14-12-20/ 14-12-20/ 3-3-21/ 3-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:35:38',45377,0),(313,606,921,'2021-04-05',4500000,'PEMBAYARAN BULAN JULI S/D FEBRUARI (10/7/20, 12/8, 10/9, 13/10, 11/11, 10/12, 13/2, 13/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:36:57',58147,0),(314,608,922,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 10/8-20/ 29-8-20/ 04-10-20/ 11-11-20/ 4-12-20/ 21-1-21/ 30-1-21/ 13-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:37:57',25090,0),(315,609,924,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 8-Aug-20/ 06-9-20/ 14-10-20/ 11-11-20/ 8-12-20/ 30-1-21/ 17-2-21/ 13-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:40:12',30655,0),(316,610,926,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/\t24-8-20/ 12-9-20\t16-10-20/ 7-11-20/ 16-12-20/ 30-1-21/ 30-1-21/ 20-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:43:24',21509,0),(317,611,928,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 10-8-20/ 12-9-20/ 19-10-20/ 29-11-20/ 10-12-20/ 21-1-21/ 3-3-21/ 13-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 08:46:10',56551,0),(318,612,930,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 8-Aug-20/ 19-09-20/ 17-10-20/ 11-11-20/ 16-12-20/ 21-1-21/ 11-2-21/ 24-11-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:28:40',62312,0),(319,613,932,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 20-7-20/ 07-9-20/ 07-10-20/ 11-11-20/ 9-12-20/ 21-1-21/ 11-2-21/ 8-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:30:29',47577,0),(320,614,934,'2021-04-05',4800000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/\t31-8-20/ 23-09-20/ 29-10-20/ 29-11-20/ 3-1-21/ 30-1-21/ 3-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:32:19',36205,0),(321,615,936,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 8-Aug-20/ 12-9-20/ 13-10-20/ 13-11-20/ 10-12-20/ 13-2-21/ 13-2-21/ 13-2-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:37:34',15707,0),(322,616,938,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 8-Aug-20/ 12-9-20/ 07-10-20/ 11-11-20/ 10-12-20/ 21-1-21/ 5-2-21/ 16-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:39:38',30184,0),(323,617,940,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 2-8-20/ 19-9-20/ 19-10-20/ 11-11-20/ 10-12-20/ 21-1-21\t8-2-2/ -3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:44:17',47193,0),(324,618,942,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 9-8-20/ 14-9-20/ 19-9-20/ 20-11-20/ 4-12-20/ 21-1-21/ 5-2-21/ 16-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:46:06',56527,0),(325,619,944,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 24-8-20/ 12-9-20/ 10-10-20/ 11-11-20/ 11-11-20/ 21-1-21/ 13-2-21/ 3-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:48:31',8849,0),(326,620,946,'2021-04-05',4800000,'Sudah Bayar dari Bulan Juli s.d Februari 2021\t(15-7-20/ 02-8-20/ 4-9-20/ 29-10-20/ 29-11-20/ 16-12-20/ 30-1-21/ 3-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:51:19',20726,0),(327,621,948,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 07-8-20/ 11-9-20/ 10-10-20/ 11-11-20/ 13-12-20/ 21-1-21/ 5-2-21/ 13-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:54:07',6816,0),(328,622,950,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 05-8-20/ 14-9-20/ 15-10-20/ 11-11-20/ 16-12-20/ 21-1-21/ 23-2-21/ 26-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:56:22',8399,0),(329,623,952,'2021-04-05',5400000,'Sudah Bayar dari Bulan Juli s.d Maret 2021\t(15-7-20/ 25-8-20/ 16-9-20/ 16-10-20/ 11-11-20/ 16-12-20/ 1-1-21/ 17-2-21/ 16-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 09:58:42',49201,0),(330,624,954,'2021-04-05',4200000,'Sudah Bayar dari Bulan Agustus s.d Februari 2021 (05-8-20/ 12-9-20/ 13-10-20/ 17-11-20/ 18-12-20/ 23-2-21/ 3-3-21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-05 10:02:05',35558,0),(331,625,956,'2021-04-05',5400000,'PEMBAYARAN BULAN JULI S/D MARET (8/7/20, 15/8, 3/9, 4/10, 7/11, 8/12, 21/1/21, 11/2, 16/3)','Jahratul Jannah S.Pd',' ',NULL,1,'0',NULL,NULL,'2021-04-05 10:31:58',6570,0),(332,626,958,'2021-04-05',5100000,'Pembayaran bulan juli sampai maret (19/7/20, 15/8, 16/9, 15/10, 7/11, 4/12, 21/1/21, 11/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 19:53:46',47241,0),(333,627,960,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 25/7/20, 31/8, 24/9, 26/10, 24/11, 13/12, 21/1/21, 20/2, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 19:56:19',26198,0),(334,628,962,'2021-04-05',4500000,'pembayaran bulan juli sampai februari ( 29/8/20, 29/8, 23/10, 23/10, 10/12, 10/12, 23/2/21, 23/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 19:58:34',61017,0),(335,629,964,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 21/8/20, 21/8, 15/9, 16/10, 11/11, 13/12, 2/2/21, 2/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:00:37',41301,0),(336,630,966,'2021-04-05',5100000,'pembayaran bulan juli sampai maret (25/7/20, 5/8, 3/9, 3/10, 4/11, 29/11, 18/1/21, 11/2/21, 13/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:02:38',20618,0),(337,631,968,'2021-04-05',4500000,'pembayaran bulan juli sampai februari ( 10/9/21, 10/9, 13/12, 13/12, 13/12, 6/3/21, 8/3, 8/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:04:32',41000,0),(338,633,971,'2021-04-05',3300000,'pembayaran bulan juli sampai desember ( 9/10/20 bayar Rp. 2.100.000, 3/1/21 bayar Rp. 1.200.000)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:12:40',1579,0),(339,634,973,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 25/7/20, 19/8, 23/9, 23/10, 20/11, 10/12, 2/2/21, 3/3, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:14:36',47110,0),(340,635,975,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 10/7/20, 25/7, 6/8, 5/9, 5/11, 4/12, 6/3/21, 6/3/21, 6/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:16:38',49242,0),(341,636,977,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 25/7/20, 24/8, 15/9, 9/10, 8/11, 31/12, 30/1, 11/2, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:36:35',57924,0),(342,637,979,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 5/9/20, 5/9, 10/10, 10/10, 10/10, 25/12, 25/12, 24/3/21, 24/3, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:38:34',61717,0),(343,638,981,'2021-04-05',4090000,'pembayaran Bulan juli sampai februari (12/8/2020, 10/9/2020, 15-10-20, 9-11-20, 9/12/20, 21/1/21, 8/2/21, 8/3/21)\r\n','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:48:20',55052,0),(344,639,983,'2021-04-05',4500000,'pembayaran bulan juli sampai februari ( 12/8/20, 12/8, 7/9, 18/10, 4/11, 14/12, 2/2/21, 6/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 20:55:16',58726,0),(345,640,985,'2021-04-05',5100000,'pembayaran bulan juli s/d maret (25/7/20, 19/8, 10/9, 1/10, 4/11, 4/12, 21/1/21, 21/2, 13/2/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:02:41',51485,0),(346,642,988,'2021-04-05',5100000,'pembayaran bulan jul sampai maret ( 25/7/20, 19/8, 10/9, 1/10, 4/11, 4/12, 21/1/21, 21/2, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:06:40',58172,0),(347,643,990,'2021-04-05',5100000,'pembayaran bulan juli sampai maret (25/7/20, 18/8, 26/9, 19/10, 17/11, 13/12, 2/2/21, 27/2, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:11:25',64709,0),(348,644,992,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 25/7/20, 29/8, 15/9, 23/10, 19/11, 28/12, 5/2/21, 3/3, 3/4) ','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:16:09',17053,0),(349,645,994,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 25/7/20, 29/8, 12/9, 10/10, 17/11, 18/12, 2/2/21, 2/2, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:18:50',23431,0),(350,646,996,'2021-04-05',5700000,'pembayaran bulan juli sampai april ( 24/8/20 bayar Rp. 900.000, 5/11/20 bayar Rp. 1.800.000, 21/1/21 bayar Rp. 1.200.000,  27/3/21 bayar Rp. 1.800.000','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:23:09',23807,0),(351,647,998,'2021-04-05',1200000,'pembayaran bulan Februari 8/2/21 dan Maret 30/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:26:20',3213,0),(352,648,1000,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 19/7/21, 31/8, 10/11, 10/11, 3/1/21, 3/1, 27/1, 27/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:34:13',34289,0),(353,649,1002,'2021-04-05',3300000,'pembayaran bulan juli sampai desember ( 18/9/20, 18/9, 21/11, 10/12, 10/12, 10/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:36:38',57751,0),(354,650,1004,'2021-04-05',4500000,'pembayaran bulan juli sampai februari ( 18/8/20, 28/8, 19/10, 13/12, 14/12, 31/12, 5/2/21, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:41:17',19332,0),(355,651,1006,'2021-04-05',4500000,'pembayaran bulan juli sampai maret (27/9/20, 27/9, 10/11, 8/12, 10/12, 31/12, 27/1, 8/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 21:50:39',24421,0),(356,652,1008,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 19/7/20, 7/8, 3/9, 1/10, 4/12, 24/1/21, 5/2, 5/2, 6/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 22:00:03',9898,0),(357,653,1010,'2021-04-05',5100000,'pembayaran bulan juli sampai maret ( 7/10/20, 7/10, 24/11, 31/12, 31/12, 31/12, 2/2/21, 8/3, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-05 22:04:37',31446,0),(358,654,1012,'2021-04-06',3600000,'sudah bayar dari bulan juli s.d bulan desember 2020\t(15-7-20,\t12-Aug-20,\t12-09-20,\t09-10-20,\t09-11-20,\t21/1/20)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 09:41:12',40208,0),(359,655,1014,'2021-04-06',5400000,'Sudah Bayar dari bulan Juli s.d bulan Maret 2021 (15-7-20,\t7-8-20,\t4-9-20,\t08-10-20,\t3-11-20,\t14/12/20,\t18/1/21,\t5/2/21,\t8/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 09:49:50',41002,0),(360,656,1016,'2021-04-06',5400000,'Sudah Bayar dari bulan Juli s.d bulan Maret 2021 (15-7-20,\t15-8-20,\t16-9-20, 26-10-20,\t15/11/20,\t13/12/20,\t2/2/21, 23/2/21, 27/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 10:39:19',4424,0),(361,657,1018,'2021-04-06',5400000,'Sudah Bayar dari bulan Juli s.d bulan Maret 2021 (15-7-20, 8-Feb-20\t4-9-20, 1-10-20, 1-11-20,\t29/11/20, 24/1/21, 8/2/21, 6/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 10:41:17',60808,0),(362,658,1020,'2021-04-06',5400000,'Sudah Bayar dari bulan Juli s.d bulan Maret 2021 (15-7-20, 8-Sep-20,\t08-9-20, 7-10-20, 9/11/20, 9/12/20, 18/1/21, 13/2/21, 8/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 10:47:06',37669,0),(363,659,1022,'2021-04-06',7200000,'Sudah Bayar dari bulan Juli s.d bulan Juni 2021 (15-7-20,\t10-8-20, 4-9-20, 13-10-20, 8-11-20, 9/12/21, 24/1/21, 13/2/21, 13/3/21, 13/3/21, 13/3/21, 13/3/21) LUNAS','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 10:50:29',57888,0),(364,660,1024,'2021-04-06',4650000,'Sudah Bayar dari bulan Juli s.d bulan Februari 2021 (15-7-20, 8-Sep-20, 4-9-20, 11-10-20, 1/12/20, 19/12/20, 13/2/21, 5/3/21)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 11:10:15',60856,0),(365,661,1026,'2021-04-06',4800000,'Sudah Bayar dari bulan Juli s.d bulan Februari 2021\t (5-7-20, 5-8-20, 5-8-20, 5-8-20, 24/11/20, 27/11/20, 25/12/20, 25/12/20)','Rika Erliani Harahap S. Hum',' ',NULL,1,'0',NULL,NULL,'2021-04-06 11:14:45',24326,0),(366,632,1027,'2021-04-07',5100000,'pembayaran bulan juli sampai maret (25/7/20, 8/8, 7/9/20, 16/10, 11/11, 10/12, 30/1/21, 11/2, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:22:07',56139,0),(367,581,1028,'2021-04-07',600000,'ATM (6/4/21 08:58:37) Bulan April ','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:23:46',62299,0),(368,597,1029,'2021-04-07',600000,'ATM ( 6/4/21 07:03:49) APRIL','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:24:48',57776,0),(369,606,1030,'2021-04-07',600000,'ATM ( 5/4/21 10:43:58) MARET','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:27:18',63461,0),(370,628,1031,'2021-04-07',600000,'ATM ( 6/4/21 17:24) MARET','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:29:03',30266,0),(371,639,1032,'2021-04-07',1000000,'ATM ( 6/4/21 14:13:26) APRIL 600.000, MEI 400.000','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:30:44',26380,0),(372,638,1033,'2021-04-07',550000,'BAYAR CASH, TGL 6/4/21','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:33:09',3532,0),(373,640,1034,'2021-04-07',600000,'ATM (6/4/21 10:37) APRIL','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:34:11',26563,0),(374,635,1035,'2021-04-07',600000,'ATM (5/4/21 14:56:19) APRIL ','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:35:24',21914,0),(375,650,1036,'2021-04-07',600000,'ATM (6/4/21 20:10:14) MARET','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:37:44',47680,0),(376,651,1037,'2021-04-07',600000,'ATM ( 5/4/21 08:41) MARET','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:39:01',20382,0),(377,652,1038,'2021-04-07',600000,'ATM ( 5/4/21 15:24:34) APRIL','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:39:44',25997,0),(378,662,1040,'2021-04-07',5100000,'PEMBAYARAN BULAN JULI-MARET ( 11/7/20, 10/8, 7/10, 15/10, 13/12, 18/1, 21/1, 11/2, 8/3) ','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:43:04',39006,0),(379,663,1042,'2021-04-07',5100000,'PEMABAYARAN BULAN JULI - MARET ( 19/7/21, 25/8, 22/9, 10/10, 21/11, 13/12, 24/1/21, 13/2, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-07 15:46:08',55768,0),(380,664,1044,'2021-04-15',5100000,'pembayaran bulan juli sampai maret ( 31/8/20, 15/11, 15/11, 15/11, 13/12, 13/12, 3/4/21, 3/4, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:10:10',21674,0),(381,665,1046,'2021-04-15',3300000,'pembayaran bulan juli sampai desember  (8/8/20, 18/8, 10/9, 18/10, 22/11, 14/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:14:17',58843,0),(382,666,1048,'2021-04-15',5100000,'pembayaran bulan juli sampai maret ( 28/8/20, 28/8, 20/10, 10/11,10/11, 10/12, 31/1/21, 8/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:16:13',45424,0),(383,667,1050,'2021-04-15',5100000,'pembayaran bulan juli sampai maret ( 19/7/20, 7/10, 16/10, 16/10, 13/12, 13/12, 3/3/21, 3/3/21, 27/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:18:26',43910,0),(384,668,1052,'2021-04-15',5100000,'pembayaran bulan juli sampai maret (19/7/20, 9/10, 9/10, 18/10, 22/11, 13/12, 24/1/21, 3/3, 20/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:20:15',61627,0),(385,669,1054,'2021-04-15',5100000,'pembayaran juli sampai maret ( 3/8/20, 18/8, 6/10, 12/10, 3/11, 29/11, 24/1/21, 13/3, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:21:58',10280,0),(386,670,1056,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 29/10, 29/10, 13/12, 13/12, 13/12, 27/3, 27/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:23:26',12753,0),(387,671,1058,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 25/8, 29/9, 9/11, 4/12, 4/12, 21/1/21, 20/2, 20/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:25:12',35299,0),(388,672,1060,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 28/8, 10/10, 8/11, 8/11, 2/2/21, 2/2, 2/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:26:28',32367,0),(389,673,1062,'2021-04-15',4600000,'juli sampai maret ( 19/7/20, 9/8, 12/9, 7/10, 9/11, 9/12, 18/1/21, 11/2, 8/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:32:07',32612,0),(390,674,1064,'2021-04-15',5100000,'juli sampai maret ( 21/8/20, 21/8, 7/10, 9/10, 13/11, 13/12, 30/1/21, 11/2, 13/3/21) ','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:34:08',42875,0),(391,675,1066,'2021-04-15',4500000,'juli sampai februari ( 3/10/21, 3/10, 29/11, 13/12, 13/12, 2/2/21, 13/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:35:38',54682,0),(392,676,1068,'2021-04-15',4500000,'bulan juli sampai februari ( 18/8/20, 12/9, 15/10, 11/11, 14/12, 24/1/21, 23/2, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:37:25',6573,0),(393,677,1070,'2021-04-15',600000,'juli sampai april ( 19/7/20, 6/10, 6/10, 24/11, 29/11, 13/12, 23/2/21, 3/3, 13/3, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:41:41',52075,0),(394,678,1072,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 31/8, 31/8, 23/10, 23/10, 18/12, 24/1/21, 3/3, 3/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:44:25',43111,0),(395,679,1074,'2021-04-15',5100000,'juli sampai maret ( 20/7/20, 20/9, 20/9,  19/11, 19/11, 10/12,  2/2, 3/3, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:45:38',61564,0),(396,680,1076,'2021-04-15',4500000,'juli sampai februari ( 26/7/20, 24/8, 1/10, 1/11, 29/11, 22/12, 24/3/21, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:47:08',64602,0),(397,681,1078,'2021-04-15',4500000,'juili sampai februari','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:47:52',2517,0),(398,682,1080,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 31/8, 31/8, 8/10, 8/11, 10/12, 18/1/21, 23/2, 25/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:49:14',57121,0),(399,683,1082,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 12/8, 7/10, 13/10, 19/11, 13/12, 18/1/21, 31/1, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:50:41',22451,0),(400,684,1084,'2021-04-15',5100000,'juli sampai maret ( 28/7/20, 31/8, 10/10, 8/11, 24/11, 20/12, 5/2/21, 23/2, 3/4/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:52:06',50461,0),(401,685,1086,'2021-04-15',2700000,'juli sampai nopember ( 8/12/20, 22/12, 13/2/21, 6/4, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:54:12',61372,0),(402,686,1088,'2021-04-15',4500000,'juli sampai februari ( 19/7/20, 18/8, 12/9, 16/10, 11/11, 13/12, 20/1/21, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:56:08',48839,0),(403,687,1090,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 18/8, 12/9, 12/10, 10/11, 10/11, 20/1/21, 20/1, 10/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:57:27',32031,0),(404,688,1092,'2021-04-15',5100000,'juli sampai maret ( 19/7/20, 7/9, 21/9, 14/12, 14/12, 27/2/21, 27/2, 27/2, 8/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 13:59:28',23207,0),(405,689,1094,'2021-04-15',4500000,'juli sampai februari (8/8/20, 19/7, 8/8, 6/10, 23/10, 27/11, 30/1/21, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 14:00:58',24891,0),(406,690,1096,'2021-04-15',3300000,'juli sampai desember ( 19/7/20, 8/8/20, 6/9/20, 6/9/20, 6/9/20, 13/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 14:02:37',2706,0),(407,691,1098,'2021-04-15',4640000,'juli sampai maret ( 1/8/20, 5/9, 28/9, 26/10, 29/11, 22/12, 30/1, 3/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:21:09',22812,0),(408,692,1100,'2021-04-15',3900000,'juli sampai januari ( 25/7, 24/8, 4/10, 28/10, 28/11, 22/12, 30/1, 3/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:23:42',31413,0),(409,693,1102,'2021-04-15',5100000,'juli sampai maret ( 12/10, 12/10, 12/10, 15/11, 15/11, 27/2, 27/2, 6/4, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:25:08',33794,0),(410,694,1104,'2021-04-15',5100000,'juli sampai maret ( 25/7/20, 25/7, 11/10, 1/12, 1/12, 27/1, 27/1, 27/1, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:27:09',35572,0),(411,695,1106,'2021-04-15',4500000,'juli sampai februari (29/8, 29/8, 29/9, 11/11, 4/12, 21/1, 6/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:28:51',490,0),(412,696,1108,'2021-04-15',5700000,'juli sampai april ( 8/9/20, 8/8, 26/8, 26/9, 28/10, 4/12, 1/2, 27/2, 27/2, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:30:37',46691,0),(413,697,1110,'2021-04-15',4500000,'juli sampai februari ( 10/8/20, 10/8, 10/9, 8/10, 5/11, 9/12, 18/1, 13/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:32:10',59897,0),(414,698,1112,'2021-04-15',5100000,'juli sampai maret ( 25/7/20, 5/9, 5/9, 29/11, 29/11, 10/12, 27/1, 23/2, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:35:54',7689,0),(415,699,1114,'2021-04-15',3900000,'juli sampai januari ( 20/9/20, 20/9, 20/9, 29/11, 29/11, 14/12, 20/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:38:42',7099,0),(416,700,1116,'2021-04-15',2400000,'masuk bulan september (12/9, 1/12, 1/12, 10/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-15 20:53:29',15469,0),(417,701,1118,'2021-04-16',4500000,'juli sampai februari ( 25/7/20, 1/9, 17/9, 15/10, 18/12, 21/1/21, 20/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:09:06',57386,0),(418,702,1120,'2021-04-16',4660000,'juli sampai maret ( 4/9/20, 4/9, 11/10, 28/11, 28/11, 19/12, 13/2, 5/3, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:13:14',41692,0),(419,703,1122,'2021-04-16',5100000,'juli sampai maret ( 25/7/20, 1/9, 23/10, 23/10, 15/11, 30/1/21, 30/1, 24/3, 24/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:14:57',62591,0),(420,704,1124,'2021-04-16',5100000,'juli sampai maret ( 25/7/20, 19/10, 19/10, 24/11, 31/12, 31/12, 3/4, 3/4, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:16:28',63143,0),(421,705,1126,'2021-04-16',5700000,'juli sampai april ( 3/8/20, 15/11, 15/11, 15/11, 20/3, 20/3, 20/3, 20/3, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:20:16',2502,0),(422,706,1128,'2021-04-16',5100000,'juli sampai maret ( 25/7/20, 23/9, 13/10, 13/10, 11/11, 13/12, 18/1/21, 27/2, 25/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:22:51',53128,0),(423,707,1130,'2021-04-16',3300000,'juli sampai januari ( juli (bu kokom) 1/9/20, 6/10, 5/11, 4/12, 11/2/21, 6/4/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:25:14',36237,0),(424,708,1132,'2021-04-16',4500000,'juli sampai februari (25/7/20, 12/8, 6/9, 13/10, 9/12, 9/12, 21/1/21, 13/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:32:21',18230,0),(425,709,1134,'2021-04-16',5100000,'juli sampai maret ( 25/7/20, 1/9, 9/10, 4/11, 4/12, 27/3/21, 27/3, 27/3, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 19:33:51',35788,0),(426,710,1136,'2021-04-16',4500000,'JULI SAMPAI FEBRUARI ( 29/8/20, 15/11, 3/1, 3/1, 3/1, 3/1, 27/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:04:23',11227,0),(427,711,1138,'2021-04-16',5100000,'JULI SAMPAI MARET ( 11/6/20, 8/7, 10/10, 10/10, 11/11, 13/12, 13/2, 13/2, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:06:30',7902,0),(428,712,1140,'2021-04-16',4500000,'JULI- FEBRUARI ( 25/7/20, 15/10, 15/10, 13/2, 13/2, 13/2, 13/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:10:15',56457,0),(429,713,1142,'2021-04-16',3300000,'JULI SAMPAI DESEMBER ( 25/7/20, 1/10, 4/10, 29/10, 18/12, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:11:35',11913,0),(430,714,1144,'2021-04-16',3900000,'JULI SAMPAI JANUARI ( 4/10/20, 22/9, 23/9, 6/10, 11/11, 9/12, 27/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:12:58',59638,0),(431,715,1146,'2021-04-16',4500000,'JULI SAMPAI FEBRUARI ( 25/7/20, 1/9, 7/10, 13/11, 3/1/21, 3/1, 6/3, 6/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:17:54',50549,0),(432,716,1148,'2021-04-16',5700000,'JULI SAMPAI APRIL ( 25/7/20, 12/8, 5/9, 1/10, 5/11, 29/11, 18/1, 11/2, 27/3, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:20:36',38618,0),(433,717,1150,'2021-04-16',3900000,'JULI SAMPAI JANUARI ( 25/7/20, 1/9, 6/10, 6/10, 18/12, 25/3, 25/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:22:19',1488,0),(434,718,1152,'2021-04-16',4500000,'JULI SAMPAI FEBRUARI (25/7/20, 29/8, 1/10, 31/10, 4/12, 21/1/21, 21/1, 13/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:25:26',41037,0),(435,719,1154,'2021-04-16',4500000,'JULI SAMPAI FEBRUARI (25/7/20, 20/8, 10/10, 3/1/21, 3/1, 27/1, 6/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:29:13',41475,0),(436,720,1156,'2021-04-16',920000,'JULI - SEPTEMBER ( 4/10/20, 21/1/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:31:56',6329,0),(437,721,1158,'2021-04-16',5700000,'JULI SAMPAI APRIL ( 25/7/20, 3/1/21, 3/1, 3/1, 3/1,25/3, 25/3, 25/3, 25/3, 25/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:33:50',54004,0),(438,722,1160,'2021-04-16',5100000,'JULI SAMPAI MARET ( 6/10/20, 6/10, 6/10, 6/10, 25/3/21, 25/3, 25/3, 25/3, 25/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:35:56',42705,0),(439,723,1162,'2021-04-16',3300000,'JULI SAMPAI DESEMBER ( 23/8/20, 29/9, 29/9, 28/12, 28/12, 28/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:37:52',42247,0),(440,724,1164,'2021-04-16',5100000,'JULI SAMPAI MARET ( 10/8/20, 27/9, 3/1/21, 3/1, 3/1, 18/1, 27/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:39:16',39388,0),(441,725,1166,'2021-04-16',4500000,'JULI SAMPAI FEBRUARI ( 25/7/20, 12/8, 9/10, 10/10, 3/1/21, 21/1, 17/2, 8/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:41:09',36266,0),(442,726,1168,'2021-04-16',5100000,'JULI SAMPAI MARET ( 25/7/20, 23/8, 19/9, 19/10, 18/12, 18/12, 21/1/21, 17/2, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:43:22',58123,0),(443,727,1170,'2021-04-16',5100000,'JULI SAMPAI MARET ( 25/7/20, 24/9, 29/10, 27/11, 8/12, 25/12, 24/1, 20/2, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:44:47',36764,0),(444,728,1172,'2021-04-16',3000000,'MASUK BULAN NOPEMBER S/D MARET ( 7/11, 1/12, 27/1, 17/2, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:47:19',39619,0),(445,729,1174,'2021-04-16',2100000,'JULI SAMPAI OKTOBER ( 25/7/20, 24/8/20, 14/9/20, 5/10)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-16 21:49:14',61249,0),(446,730,1176,'2021-04-17',6900000,'juli sampai juni (27/1/21, 27/1, 27/1, 4/12, 4/12, 28/12, 27/1,/27/12, 27/1, 27/1, 27/1, 27/1)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-17 18:42:26',48617,0),(447,731,1178,'2021-04-17',3900000,'juli sampai januari ( 19/9/20, 19/9, 1/10, 29/11, 3/1, 3/1, 8/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-17 18:43:43',49211,0),(448,732,1180,'2021-04-17',3560000,'juli sampai januari ( 28/8/20, 28/8, 23/10, 27/12, 27/12, 3/3/21, 3/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-17 19:47:08',5037,0),(449,733,1182,'2021-04-17',5100000,'juli sampai maret ( 18/9/20, 18/9, 18/9, 19/12, 19/12, 19/12, 8/3, 8/3, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-17 19:53:05',29383,0),(450,734,1184,'2021-04-17',4500000,'juli sampai februari (19/7/20, 27/8, 28/9, 26/10, 15/11, 30/1, 3/3, 30/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-17 20:41:03',12,0),(451,735,1186,'2021-04-18',3900000,'juli sampai januari ( 21/7/20, 26/8, 6/10, 24/10, 14/11, 25/12, 3/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:25:21',59039,0),(452,736,1188,'2021-04-18',5100000,'','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:26:01',4271,0),(453,737,1190,'2021-04-18',4500000,'juli sampai februari ( 1/8/20, 26/8, 10/10, 4/12, 16/3/21, 16/3/21, 30/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:28:16',56237,0),(454,738,1192,'2021-04-18',4500000,'juli sampai februari ( 19/7/20, 31/8, 29/11, 29/11, 14/12, 14/12, 8/2/21, 27/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:33:29',4919,0),(455,739,1194,'2021-04-18',3280000,'juli sampai januari ( 1/10, 29/10, 4/12, 16/12, 11/2/21, 3/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:38:04',28525,0),(456,740,1196,'2021-04-18',4500000,'juli sampai frbruari ( 19/7/20, 9/9, 13/11, 13/11, 13/11, 3/1, 18/1, 5/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:40:22',60816,0),(457,741,1198,'2021-04-18',5700000,'juli sampai april ( 19/7/20, 26/10, 26/10, 26/10, 14/12, 14/12, 5/2/21, 5/2, 8/4, 8/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:42:06',3555,0),(458,742,1200,'2021-04-18',2100000,'juli sampai desember ( 28/8/20, 28/8, 16/12, 16/12, 16/12, 16/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:48:01',59283,0),(459,743,1202,'2021-04-18',3900000,'juli sampai januari ( 19/7/20, 6/8, 7/10, 3/11, 11/2/21, 8/2/21, 27/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 09:50:27',16855,0),(460,744,1204,'2021-04-18',2100000,'juli sampai oktober ( 26/9/20, 10/12, 10/12, 10/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:17:51',34809,0),(461,745,1206,'2021-04-18',3300000,'juli sampai desember ( 19/7/20, 4/9, 11/9, 8/11, 8/11, 10/12)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:19:34',29182,0),(462,746,1208,'2021-04-18',1600000,'juli sampai Februari ( 28/8/20, 28/8, 8/11, 8/11, 8/11, 10/12, 13/2, 13/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:21:32',37341,0),(463,747,1210,'2021-04-18',4500000,'juli sampai februari ( 19/7/20, 24/8, 29/8, 1/10, 18/10, 29/11, 30/1, 3/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:23:18',56977,0),(464,748,1212,'2021-04-18',4800000,'agustus sampai maret ( 24/11, 24/11, 31/10, 24/11, 16/12, 2/2/21, 8/3, 8/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:26:15',58286,0),(465,749,1214,'2021-04-18',5700000,'juli sampai april ( 19/7/20, 19/8, 9/9, 8/10, 20/11, 16/12, 30/1/21, 27/2, 27/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:28:55',24594,0),(466,750,1216,'2021-04-18',1800000,'juli sampai maret ( 1/10/20, 1/10, 20/11, 20/11, 14/12, 14/12, 8/2/21, 20/3, 20/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:31:07',1828,0),(467,751,1218,'2021-04-18',4500000,'juli sampai februari ( 31/8/20, 31/8, 13/9, 18/10, 10/11, 20/12, 8/2, 27/2, 27/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:38:29',29015,0),(468,752,1220,'2021-04-18',4620000,'juli sampai april ( 12/8/20, 12/9, 15/10, 9/11, 18/1, 18/1, 11/2, 8/3, 8/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:40:55',30684,0),(469,753,1222,'2021-04-18',5700000,'juli sampai april ( 19/7/20, 18/8, 13/9, 8/10, 17/11, 16/12, 18/1/21, 13/2, 27/3, 17/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:42:52',4348,0),(470,754,1224,'2021-04-18',5100000,'juli sampai maret ( 19/7/20, 27/8, 28/10, 20/11, 20/11, 16/12, 27/1, 3/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:51:11',22530,0),(471,755,1226,'2021-04-18',5100000,'juli sampai maret ( 19/7/20, 12/8, 10/9, 17/11, 17/11, 14/12, 18/1/21, 23/2, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:52:59',43124,0),(472,756,1228,'2021-04-18',5100000,'juli sampai maret ( 21/8/20, 21/8, 19/9, 5/10 4/11, 4/11, 13/2/21, 13/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 10:54:22',47660,0),(473,757,1230,'2021-04-18',5700000,'juli sampai april ( 19/7/20, 12/8, 7/9, 7/10, 5/11, 4/12, 18/1/21, 8/2, 6/3, 6/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:16:58',40366,0),(474,758,1232,'2021-04-18',3900000,'juli sampai januari ( 19/7/20, 11/9, 7/10, 29/9, 8/11, 13/12, 27/2)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:18:37',25375,0),(475,759,1234,'2021-04-18',5100000,'juli sampai maret ( 19/7/20, 1/9, 8/10, 23/11, 23/11, 14/12, 20/2, 20/2, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:19:52',63940,0),(476,760,1236,'2021-04-18',4660000,'juli sampai maret ( 19/7/20, 22/8, 16/9, 11/10, 14/11, 10/12, 20/1/21, 13/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:22:22',21088,0),(477,761,1238,'2021-04-18',4500000,'juli sampai februari ( 23/8/20, 8/10, 4/12, 4/12, 25/12, 2/2/21, 6/3, 8/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:23:54',38399,0),(478,762,1240,'2021-04-18',5100000,'juli sampai maret ( 5/8/20, 28/8, 1/10, 29/10, 24/11, 10/12, 30/1, 16/3, 3/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:25:21',40864,0),(479,763,1242,'2021-04-18',4500000,'jili sampai februari','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:27:08',41239,0),(480,764,1244,'2021-04-18',5100000,'juli sampai maret ( 18/8/20, 9/9, 8/10, 11/11, 14/12, 21/1/21, 13/2, 16/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:28:47',19438,0),(481,765,1246,'2021-04-18',4500000,'juli sampai februari ( 28/7/20, 29/10, 29/10, 29/10, 4/12, 16/12, 16/3, 27/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:30:56',34413,0),(482,766,1248,'2021-04-18',3900000,'juli sampai januari (23/10, 23/10, 23/10, 27/1/21, 27/1, 27/1)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:33:23',35364,0),(483,767,1250,'2021-04-18',4500000,'juli sampai februari ( 15/9/20, 15/9, 3/11, 3/11, 20/12, 20/12, 3/3, 3/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:34:37',20447,0),(484,768,1252,'2021-04-18',5100000,'juli sampai maret ( 12/8/20, 9/9, 9/9, 9/10, 5/11, 29/11, 14/12, 11/2, 6/3)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:35:37',36446,0),(485,769,1254,'2021-04-18',5100000,'juli sampai maret ( 25/7/20, 10/8, 15/9, 29/10, 20/11, 14/12, 11/2, 8/3, 8/4)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-18 11:37:11',9717,0),(486,600,1255,'2021-04-19',1200000,'CASH (19/4/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-19 09:22:50',37797,0),(487,630,1256,'2021-04-19',600000,'17/4/21 ( APRIL)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-19 09:23:47',14860,0),(488,633,1257,'2021-04-19',2400000,'CASH ( 19/4/21) JAN - APRIL','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-19 09:24:28',9486,0),(489,770,1259,'2021-04-19',5100000,'JULI SAMPAI MARET ( 25/7/20, 12/8, 10/9. 7/10, 11/11, 4/12, 18/1/21, 8/2/21, 6/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-19 11:22:18',18441,0),(490,771,1261,'2021-04-19',4500000,'JULI SAMPAI FEBRUARI (29/8/21, 29/8, 27//11, 27/11, 3/1/21, 23/2, 23/2, 6/3/21)','Jahratul Jannah',' ',NULL,1,'0',NULL,NULL,'2021-04-19 11:24:14',6173,0),(491,772,1263,'2021-07-12',6600000,'bulan juli  sampai mei( 2/8/20), 29/8/20, 1/10/20, 1/11, 29/11, 31/12, 27/1, 27/2, 3/4/21, 29/4, 7/6/21','Jahratul Jannah S.Pd',' ',NULL,1,'0',NULL,NULL,'2021-07-12 20:52:50',23543,0),(492,773,1265,'2021-07-12',6600000,'juli sampai juni 2021 ( 15/7/20, 10/8, 6/9, 4/10, 4/11, 4/12, 24/1, 3/3, 31/5/21, 3/6/, 21/6/21)','Jahratul Jannah S.Pd',' ',NULL,1,'0',NULL,NULL,'2021-07-12 20:57:09',38382,0),(493,774,1267,'2021-07-12',6600000,'','Jahratul Jannah S.Pd',' ',NULL,1,'0',NULL,NULL,'2021-07-12 21:33:59',27254,0),(494,775,1269,'2021-07-12',6600000,'','Jahratul Jannah S.Pd',' ',NULL,1,'0',NULL,NULL,'2021-07-12 21:35:08',26169,0),(495,776,1271,'2021-07-12',7200000,'12/7/20, 1/8, 7/9/20, 4/10, 9/11, 4/12, 21/1, 8/2, 8/3, 6/4, 18/5, 7/6','Jahratul Jannah S.Pd',' ',NULL,1,'0',NULL,NULL,'2021-07-12 21:37:25',55989,0);

#
# Structure for table "penerimaanjttcalon"
#

DROP TABLE IF EXISTS `jbsfina`.`penerimaanjttcalon`;
CREATE TABLE `jbsfina`.`penerimaanjttcalon` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idbesarjttcalon` int(10) unsigned NOT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT '" "',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_penerimaanjttcalon_jurnal` (`idjurnal`),
  KEY `FK_penerimaanjttcalon_besarjtt` (`idbesarjttcalon`),
  KEY `IX_penerimaanjttcalon_ts` (`ts`,`issync`),
  CONSTRAINT `FK_penerimaanjttcalon_besarjttcalon` FOREIGN KEY (`idbesarjttcalon`) REFERENCES `jbsfina`.`besarjttcalon` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_penerimaanjttcalon_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "penerimaanjttcalon"
#


#
# Structure for table "penerimaaniuran"
#

DROP TABLE IF EXISTS `jbsfina`.`penerimaaniuran`;
CREATE TABLE `jbsfina`.`penerimaaniuran` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `nis` varchar(20) NOT NULL,
  `alasan` varchar(500) DEFAULT '" "',
  `paymentid` varchar(20) DEFAULT NULL,
  `isschoolpay` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pembayaraniuran_jurnal` (`idjurnal`),
  KEY `FK_pembayaraniuran_datapenerimaan` (`idpenerimaan`),
  KEY `FK_pembayaraniuran_siswa` (`nis`),
  KEY `IX_penerimaaniuran_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pembayaraniuran_datapenerimaan` FOREIGN KEY (`idpenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pembayaraniuran_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pembayaraniuran_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "penerimaaniuran"
#


#
# Structure for table "penerimaaniurancalon"
#

DROP TABLE IF EXISTS `jbsfina`.`penerimaaniurancalon`;
CREATE TABLE `jbsfina`.`penerimaaniurancalon` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `idcalon` int(10) unsigned NOT NULL,
  `alasan` varchar(500) DEFAULT '" "',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_penerimaaniurancalon_datapenerimaan` (`idpenerimaan`),
  KEY `FK_penerimaaniurancalon_calon` (`idcalon`),
  KEY `FK_penerimaaniurancalon_jurnal` (`idjurnal`),
  KEY `IX_penerimaaniurancalon_ts` (`ts`,`issync`),
  CONSTRAINT `FK_penerimaaniurancalon_calon` FOREIGN KEY (`idcalon`) REFERENCES `jbsakad`.`calonsiswa` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_penerimaaniurancalon_datapenerimaan` FOREIGN KEY (`idpenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_penerimaaniurancalon_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "penerimaaniurancalon"
#


#
# Structure for table "penerimaanlain"
#

DROP TABLE IF EXISTS `jbsfina`.`penerimaanlain`;
CREATE TABLE `jbsfina`.`penerimaanlain` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjurnal` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `idpenerimaan` int(10) unsigned NOT NULL,
  `sumber` varchar(100) NOT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pembayaranlain_jurnal` (`idjurnal`),
  KEY `FK_pembayaranlain_datapenerimaan` (`idpenerimaan`),
  KEY `IX_penerimaanlain_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pembayaranlain_datapenerimaan` FOREIGN KEY (`idpenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pembayaranlain_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "penerimaanlain"
#


#
# Structure for table "pengeluaran"
#

DROP TABLE IF EXISTS `jbsfina`.`pengeluaran`;
CREATE TABLE `jbsfina`.`pengeluaran` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idpengeluaran` int(10) unsigned NOT NULL,
  `keperluan` varchar(255) NOT NULL,
  `jenispemohon` tinyint(1) unsigned NOT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `pemohonlain` int(10) unsigned DEFAULT NULL,
  `penerima` varchar(100) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `tanggalkeluar` datetime NOT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `petugas` varchar(45) DEFAULT NULL,
  `idjurnal` int(10) unsigned NOT NULL,
  `keterangan` text,
  `namapemohon` varchar(100) NOT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_pengeluaran_nis` (`nis`),
  KEY `FK_pengeluaran_nip` (`nip`),
  KEY `FK_pengeluaran_jurnal` (`idjurnal`),
  KEY `FK_pengeluaran_pemohonlain` (`pemohonlain`),
  KEY `IX_pengeluaran_ts` (`ts`,`issync`),
  CONSTRAINT `FK_pengeluaran_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pengeluaran_nip` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pengeluaran_nis` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pengeluaran_pemohonlain` FOREIGN KEY (`pemohonlain`) REFERENCES `jbsfina`.`pemohonlain` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "pengeluaran"
#


#
# Structure for table "jurnaldetail"
#

DROP TABLE IF EXISTS `jbsfina`.`jurnaldetail`;
CREATE TABLE `jbsfina`.`jurnaldetail` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idjurnal` int(10) unsigned NOT NULL,
  `koderek` varchar(15) NOT NULL,
  `debet` decimal(15,0) NOT NULL DEFAULT '0',
  `kredit` decimal(15,0) NOT NULL DEFAULT '0',
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_jurnaldetail_jurnal` (`idjurnal`),
  KEY `IX_jurnaldetail_koderek` (`koderek`),
  KEY `IX_jurnaldetail_ts` (`ts`,`issync`),
  CONSTRAINT `FK_jurnaldetail_jurnal` FOREIGN KEY (`idjurnal`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_jurnaldetail_rekakun` FOREIGN KEY (`koderek`) REFERENCES `jbsfina`.`rekakun` (`kode`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2543 DEFAULT CHARSET=utf8;

#
# Data for table "jurnaldetail"
#

INSERT INTO `jurnaldetail` VALUES (141,71,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(142,71,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(143,72,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(144,72,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(145,73,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(146,73,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(147,74,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(148,74,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(149,75,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(150,75,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(151,76,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(152,76,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(153,77,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(154,77,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(155,78,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(156,78,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(157,79,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(158,79,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(159,80,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(160,80,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(161,81,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(162,81,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(163,82,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(164,82,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(165,83,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(166,83,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(167,84,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(168,84,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(169,85,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(170,85,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(171,86,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(172,86,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(173,87,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(174,87,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(175,88,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(176,88,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(177,89,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(178,89,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(179,90,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(180,90,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(181,91,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(182,91,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(183,92,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(184,92,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(185,93,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(186,93,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(187,94,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(188,94,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(189,95,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(190,95,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(191,96,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(192,96,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(193,97,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(194,97,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(195,98,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(196,98,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(197,99,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(198,99,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(199,100,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(200,100,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(201,101,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(202,101,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(203,102,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(204,102,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(205,103,'150',6600000,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(206,103,'411',0,6600000,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(207,104,'111',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(208,104,'150',0,0,NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(209,105,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 11:03:41',0,0),(210,105,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 11:03:41',0,0),(211,106,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 11:11:50',0,0),(212,106,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 11:11:50',0,0),(213,107,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 11:14:51',0,0),(214,107,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 11:14:51',0,0),(215,108,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 11:17:54',0,0),(216,108,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 11:17:54',0,0),(217,109,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 11:21:54',0,0),(218,109,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 11:21:54',0,0),(219,110,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 11:26:01',0,0),(220,110,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 11:26:01',0,0),(221,111,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 11:28:00',0,0),(222,111,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 11:28:00',0,0),(1585,793,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 11:36:10',0,0),(1586,793,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 11:36:10',0,0),(1587,794,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 11:36:53',0,0),(1588,794,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 11:36:53',0,0),(1589,795,'150',6900000,0,NULL,NULL,NULL,'2021-04-03 11:38:48',0,0),(1590,795,'411',0,6900000,NULL,NULL,NULL,'2021-04-03 11:38:48',0,0),(1591,796,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 11:39:15',0,0),(1592,796,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 11:39:15',0,0),(1593,797,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 11:40:05',0,0),(1594,797,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 11:40:05',0,0),(1729,865,'111',4500000,0,NULL,NULL,NULL,'2021-04-03 11:43:47',0,0),(1730,865,'150',0,4500000,NULL,NULL,NULL,'2021-04-03 11:43:47',0,0),(1731,866,'150',6900000,0,NULL,NULL,NULL,'2021-04-03 11:46:51',0,0),(1732,866,'411',0,6900000,NULL,NULL,NULL,'2021-04-03 11:46:51',0,0),(1733,867,'111',5100000,0,NULL,NULL,NULL,'2021-04-03 11:51:38',0,0),(1734,867,'150',0,5100000,NULL,NULL,NULL,'2021-04-03 11:51:38',0,0),(1735,868,'150',4500000,0,NULL,NULL,NULL,'2021-04-03 11:59:14',0,0),(1736,868,'411',0,4500000,NULL,NULL,NULL,'2021-04-03 11:59:14',0,0),(1737,869,'111',2100000,0,NULL,NULL,NULL,'2021-04-03 12:02:53',0,0),(1738,869,'150',0,2100000,NULL,NULL,NULL,'2021-04-03 12:02:53',0,0),(1739,870,'150',5100000,0,NULL,NULL,NULL,'2021-04-03 12:10:09',0,0),(1740,870,'411',0,5100000,NULL,NULL,NULL,'2021-04-03 12:10:09',0,0),(1741,871,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:24:46',0,0),(1742,871,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:24:46',0,0),(1743,872,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 12:25:39',0,0),(1744,872,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 12:25:39',0,0),(1745,873,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:30:40',0,0),(1746,873,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:30:40',0,0),(1747,874,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 12:31:28',0,0),(1748,874,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 12:31:28',0,0),(1749,875,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:34:43',0,0),(1750,875,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:34:43',0,0),(1751,876,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 12:35:46',0,0),(1752,876,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 12:35:46',0,0),(1753,877,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:39:15',0,0),(1754,877,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:39:15',0,0),(1755,878,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 12:41:02',0,0),(1756,878,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 12:41:02',0,0),(1757,879,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:44:08',0,0),(1758,879,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:44:08',0,0),(1759,880,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 12:44:38',0,0),(1760,880,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 12:44:38',0,0),(1761,881,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:49:22',0,0),(1762,881,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:49:22',0,0),(1763,882,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 12:53:07',0,0),(1764,882,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 12:53:07',0,0),(1765,883,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 12:56:41',0,0),(1766,883,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 12:56:41',0,0),(1767,884,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 13:14:36',0,0),(1768,884,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 13:14:36',0,0),(1769,885,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 14:11:24',0,0),(1770,885,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 14:11:24',0,0),(1771,886,'150',7200000,0,NULL,NULL,NULL,'2021-04-03 23:02:18',0,0),(1772,886,'411',0,7200000,NULL,NULL,NULL,'2021-04-03 23:02:18',0,0),(1773,887,'111',5400000,0,NULL,NULL,NULL,'2021-04-03 23:04:22',0,0),(1774,887,'150',0,5400000,NULL,NULL,NULL,'2021-04-03 23:04:22',0,0),(1775,888,'150',7200000,0,NULL,NULL,NULL,'2021-04-04 08:06:38',0,0),(1776,888,'411',0,7200000,NULL,NULL,NULL,'2021-04-04 08:06:38',0,0),(1777,889,'111',5400000,0,NULL,NULL,NULL,'2021-04-04 09:12:45',0,0),(1778,889,'150',0,5400000,NULL,NULL,NULL,'2021-04-04 09:12:45',0,0),(1779,890,'150',7200000,0,NULL,NULL,NULL,'2021-04-04 09:13:59',0,0),(1780,890,'411',0,7200000,NULL,NULL,NULL,'2021-04-04 09:13:59',0,0),(1781,891,'111',5400000,0,NULL,NULL,NULL,'2021-04-04 09:17:10',0,0),(1782,891,'150',0,5400000,NULL,NULL,NULL,'2021-04-04 09:17:10',0,0),(1783,892,'150',7200000,0,NULL,NULL,NULL,'2021-04-04 09:19:52',0,0),(1784,892,'411',0,7200000,NULL,NULL,NULL,'2021-04-04 09:19:52',0,0),(1785,893,'111',5400000,0,NULL,NULL,NULL,'2021-04-04 09:22:52',0,0),(1786,893,'150',0,5400000,NULL,NULL,NULL,'2021-04-04 09:22:52',0,0),(1787,894,'150',7200000,0,NULL,NULL,NULL,'2021-04-04 09:23:26',0,0),(1788,894,'411',0,7200000,NULL,NULL,NULL,'2021-04-04 09:23:26',0,0),(1789,895,'111',2700000,0,NULL,NULL,NULL,'2021-04-05 07:37:40',0,0),(1790,895,'150',0,2700000,NULL,NULL,NULL,'2021-04-05 07:37:40',0,0),(1791,896,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 07:38:24',0,0),(1792,896,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 07:38:24',0,0),(1793,897,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 07:48:42',0,0),(1794,897,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 07:48:42',0,0),(1795,898,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 07:49:12',0,0),(1796,898,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 07:49:12',0,0),(1797,899,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 07:50:31',0,0),(1798,899,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 07:50:31',0,0),(1799,900,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 07:51:11',0,0),(1800,900,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 07:51:11',0,0),(1801,901,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 07:52:42',0,0),(1802,901,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 07:52:42',0,0),(1803,902,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 07:53:11',0,0),(1804,902,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 07:53:11',0,0),(1805,903,'111',6900000,0,NULL,NULL,NULL,'2021-04-05 07:56:23',0,0),(1806,903,'150',0,6900000,NULL,NULL,NULL,'2021-04-05 07:56:23',0,0),(1807,904,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:02:41',0,0),(1808,904,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:02:41',0,0),(1809,905,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 08:04:50',0,0),(1810,905,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 08:04:50',0,0),(1811,906,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 08:07:49',0,0),(1812,906,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 08:07:49',0,0),(1813,907,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:13:11',0,0),(1814,907,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:13:11',0,0),(1815,908,'111',4800000,0,NULL,NULL,NULL,'2021-04-05 08:15:58',0,0),(1816,908,'150',0,4800000,NULL,NULL,NULL,'2021-04-05 08:15:58',0,0),(1817,909,'150',6860000,0,NULL,NULL,NULL,'2021-04-05 08:16:14',0,0),(1818,909,'411',0,6860000,NULL,NULL,NULL,'2021-04-05 08:16:14',0,0),(1819,910,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:17:04',0,0),(1820,910,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:17:04',0,0),(1821,911,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:21:14',0,0),(1822,911,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:21:14',0,0),(1823,912,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:22:08',0,0),(1824,912,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:22:08',0,0),(1825,913,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:28:47',0,0),(1826,913,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:28:47',0,0),(1827,914,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:30:45',0,0),(1828,914,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:30:45',0,0),(1829,915,'111',5060000,0,NULL,NULL,NULL,'2021-04-05 08:31:00',0,0),(1830,915,'150',0,5060000,NULL,NULL,NULL,'2021-04-05 08:31:00',0,0),(1831,916,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 08:31:33',0,0),(1832,916,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 08:31:33',0,0),(1833,917,'111',4800000,0,NULL,NULL,NULL,'2021-04-05 08:32:57',0,0),(1834,917,'150',0,4800000,NULL,NULL,NULL,'2021-04-05 08:32:57',0,0),(1835,918,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:33:36',0,0),(1836,918,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:33:36',0,0),(1837,919,'111',4800000,0,NULL,NULL,NULL,'2021-04-05 08:35:38',0,0),(1838,919,'150',0,4800000,NULL,NULL,NULL,'2021-04-05 08:35:38',0,0),(1839,920,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:36:11',0,0),(1840,920,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:36:11',0,0),(1841,921,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 08:36:57',0,0),(1842,921,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 08:36:57',0,0),(1843,922,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:37:57',0,0),(1844,922,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:37:57',0,0),(1845,923,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:38:25',0,0),(1846,923,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:38:25',0,0),(1847,924,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:40:12',0,0),(1848,924,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:40:12',0,0),(1849,925,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:42:02',0,0),(1850,925,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:42:02',0,0),(1851,926,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:43:24',0,0),(1852,926,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:43:24',0,0),(1853,927,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:44:22',0,0),(1854,927,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:44:22',0,0),(1855,928,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 08:46:10',0,0),(1856,928,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 08:46:10',0,0),(1857,929,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 08:56:58',0,0),(1858,929,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 08:56:58',0,0),(1859,930,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:28:40',0,0),(1860,930,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:28:40',0,0),(1861,931,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:29:15',0,0),(1862,931,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:29:15',0,0),(1863,932,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:30:29',0,0),(1864,932,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:30:29',0,0),(1865,933,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:31:08',0,0),(1866,933,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:31:08',0,0),(1867,934,'111',4800000,0,NULL,NULL,NULL,'2021-04-05 09:32:19',0,0),(1868,934,'150',0,4800000,NULL,NULL,NULL,'2021-04-05 09:32:19',0,0),(1869,935,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:36:06',0,0),(1870,935,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:36:06',0,0),(1871,936,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:37:34',0,0),(1872,936,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:37:34',0,0),(1873,937,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:38:26',0,0),(1874,937,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:38:26',0,0),(1875,938,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:39:38',0,0),(1876,938,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:39:38',0,0),(1877,939,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:42:43',0,0),(1878,939,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:42:43',0,0),(1879,940,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:44:17',0,0),(1880,940,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:44:17',0,0),(1881,941,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:44:37',0,0),(1882,941,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:44:37',0,0),(1883,942,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:46:06',0,0),(1884,942,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:46:06',0,0),(1885,943,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:47:05',0,0),(1886,943,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:47:05',0,0),(1887,944,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:48:31',0,0),(1888,944,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:48:31',0,0),(1889,945,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:49:20',0,0),(1890,945,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:49:20',0,0),(1891,946,'111',4800000,0,NULL,NULL,NULL,'2021-04-05 09:51:19',0,0),(1892,946,'150',0,4800000,NULL,NULL,NULL,'2021-04-05 09:51:19',0,0),(1893,947,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:52:16',0,0),(1894,947,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:52:16',0,0),(1895,948,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:54:07',0,0),(1896,948,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:54:07',0,0),(1897,949,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:54:51',0,0),(1898,949,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:54:51',0,0),(1899,950,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:56:22',0,0),(1900,950,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:56:22',0,0),(1901,951,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 09:56:55',0,0),(1902,951,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 09:56:55',0,0),(1903,952,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 09:58:42',0,0),(1904,952,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 09:58:42',0,0),(1905,953,'150',6600000,0,NULL,NULL,NULL,'2021-04-05 09:59:19',0,0),(1906,953,'411',0,6600000,NULL,NULL,NULL,'2021-04-05 09:59:19',0,0),(1907,954,'111',4200000,0,NULL,NULL,NULL,'2021-04-05 10:02:05',0,0),(1908,954,'150',0,4200000,NULL,NULL,NULL,'2021-04-05 10:02:05',0,0),(1909,955,'150',7200000,0,NULL,NULL,NULL,'2021-04-05 10:29:35',0,0),(1910,955,'411',0,7200000,NULL,NULL,NULL,'2021-04-05 10:29:35',0,0),(1911,956,'111',5400000,0,NULL,NULL,NULL,'2021-04-05 10:31:58',0,0),(1912,956,'150',0,5400000,NULL,NULL,NULL,'2021-04-05 10:31:58',0,0),(1913,957,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 19:50:40',0,0),(1914,957,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 19:50:40',0,0),(1915,958,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 19:53:46',0,0),(1916,958,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 19:53:46',0,0),(1917,959,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 19:54:35',0,0),(1918,959,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 19:54:35',0,0),(1919,960,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 19:56:19',0,0),(1920,960,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 19:56:19',0,0),(1921,961,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 19:57:21',0,0),(1922,961,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 19:57:21',0,0),(1923,962,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 19:58:34',0,0),(1924,962,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 19:58:34',0,0),(1925,963,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 19:59:11',0,0),(1926,963,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 19:59:11',0,0),(1927,964,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 20:00:37',0,0),(1928,964,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 20:00:37',0,0),(1929,965,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:01:07',0,0),(1930,965,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:01:07',0,0),(1931,966,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 20:02:38',0,0),(1932,966,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 20:02:38',0,0),(1933,967,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:02:58',0,0),(1934,967,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:02:58',0,0),(1935,968,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 20:04:32',0,0),(1936,968,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 20:04:32',0,0),(1937,969,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:08:25',0,0),(1938,969,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:08:25',0,0),(1939,970,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:11:05',0,0),(1940,970,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:11:05',0,0),(1941,971,'111',3300000,0,NULL,NULL,NULL,'2021-04-05 20:12:40',0,0),(1942,971,'150',0,3300000,NULL,NULL,NULL,'2021-04-05 20:12:40',0,0),(1943,972,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:13:18',0,0),(1944,972,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:13:18',0,0),(1945,973,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 20:14:36',0,0),(1946,973,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 20:14:36',0,0),(1947,974,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:15:26',0,0),(1948,974,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:15:26',0,0),(1949,975,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 20:16:38',0,0),(1950,975,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 20:16:38',0,0),(1951,976,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:34:13',0,0),(1952,976,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:34:13',0,0),(1953,977,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 20:36:35',0,0),(1954,977,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 20:36:35',0,0),(1955,978,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:37:03',0,0),(1956,978,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:37:03',0,0),(1957,979,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 20:38:34',0,0),(1958,979,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 20:38:34',0,0),(1959,980,'150',6290000,0,NULL,NULL,NULL,'2021-04-05 20:39:11',0,0),(1960,980,'411',0,6290000,NULL,NULL,NULL,'2021-04-05 20:39:11',0,0),(1961,981,'111',4090000,0,NULL,NULL,NULL,'2021-04-05 20:48:20',0,0),(1962,981,'150',0,4090000,NULL,NULL,NULL,'2021-04-05 20:48:20',0,0),(1963,982,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:52:52',0,0),(1964,982,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:52:52',0,0),(1965,983,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 20:55:16',0,0),(1966,983,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 20:55:16',0,0),(1967,984,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 20:59:47',0,0),(1968,984,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 20:59:47',0,0),(1969,985,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 21:02:41',0,0),(1970,985,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 21:02:41',0,0),(1971,986,'150',0,0,NULL,NULL,NULL,'2021-04-05 21:03:51',0,0),(1972,986,'411',0,0,NULL,NULL,NULL,'2021-04-05 21:03:51',0,0),(1973,987,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:05:21',0,0),(1974,987,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:05:21',0,0),(1975,988,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 21:06:40',0,0),(1976,988,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 21:06:40',0,0),(1977,989,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:08:39',0,0),(1978,989,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:08:39',0,0),(1979,990,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 21:11:25',0,0),(1980,990,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 21:11:25',0,0),(1981,991,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:13:13',0,0),(1982,991,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:13:13',0,0),(1983,992,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 21:16:09',0,0),(1984,992,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 21:16:09',0,0),(1985,993,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:17:03',0,0),(1986,993,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:17:03',0,0),(1987,994,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 21:18:50',0,0),(1988,994,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 21:18:50',0,0),(1989,995,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:19:35',0,0),(1990,995,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:19:35',0,0),(1991,996,'111',5700000,0,NULL,NULL,NULL,'2021-04-05 21:23:09',0,0),(1992,996,'150',0,5700000,NULL,NULL,NULL,'2021-04-05 21:23:09',0,0),(1993,997,'150',3000000,0,NULL,NULL,NULL,'2021-04-05 21:25:24',0,0),(1994,997,'411',0,3000000,NULL,NULL,NULL,'2021-04-05 21:25:24',0,0),(1995,998,'111',1200000,0,NULL,NULL,NULL,'2021-04-05 21:26:20',0,0),(1996,998,'150',0,1200000,NULL,NULL,NULL,'2021-04-05 21:26:20',0,0),(1997,999,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:31:30',0,0),(1998,999,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:31:30',0,0),(1999,1000,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 21:34:13',0,0),(2000,1000,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 21:34:13',0,0),(2001,1001,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:34:41',0,0),(2002,1001,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:34:41',0,0),(2003,1002,'111',3300000,0,NULL,NULL,NULL,'2021-04-05 21:36:38',0,0),(2004,1002,'150',0,3300000,NULL,NULL,NULL,'2021-04-05 21:36:38',0,0),(2005,1003,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:37:24',0,0),(2006,1003,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:37:24',0,0),(2007,1004,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 21:41:17',0,0),(2008,1004,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 21:41:17',0,0),(2009,1005,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:47:25',0,0),(2010,1005,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:47:25',0,0),(2011,1006,'111',4500000,0,NULL,NULL,NULL,'2021-04-05 21:50:39',0,0),(2012,1006,'150',0,4500000,NULL,NULL,NULL,'2021-04-05 21:50:39',0,0),(2013,1007,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 21:55:16',0,0),(2014,1007,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 21:55:16',0,0),(2015,1008,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 22:00:03',0,0),(2016,1008,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 22:00:03',0,0),(2017,1009,'150',6900000,0,NULL,NULL,NULL,'2021-04-05 22:01:22',0,0),(2018,1009,'411',0,6900000,NULL,NULL,NULL,'2021-04-05 22:01:22',0,0),(2019,1010,'111',5100000,0,NULL,NULL,NULL,'2021-04-05 22:04:37',0,0),(2020,1010,'150',0,5100000,NULL,NULL,NULL,'2021-04-05 22:04:37',0,0),(2021,1011,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 09:38:59',0,0),(2022,1011,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 09:38:59',0,0),(2023,1012,'111',3600000,0,NULL,NULL,NULL,'2021-04-06 09:41:12',0,0),(2024,1012,'150',0,3600000,NULL,NULL,NULL,'2021-04-06 09:41:12',0,0),(2025,1013,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 09:42:02',0,0),(2026,1013,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 09:42:02',0,0),(2027,1014,'111',5400000,0,NULL,NULL,NULL,'2021-04-06 09:49:50',0,0),(2028,1014,'150',0,5400000,NULL,NULL,NULL,'2021-04-06 09:49:50',0,0),(2029,1015,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 10:37:55',0,0),(2030,1015,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 10:37:55',0,0),(2031,1016,'111',5400000,0,NULL,NULL,NULL,'2021-04-06 10:39:19',0,0),(2032,1016,'150',0,5400000,NULL,NULL,NULL,'2021-04-06 10:39:19',0,0),(2033,1017,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 10:39:58',0,0),(2034,1017,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 10:39:58',0,0),(2035,1018,'111',5400000,0,NULL,NULL,NULL,'2021-04-06 10:41:17',0,0),(2036,1018,'150',0,5400000,NULL,NULL,NULL,'2021-04-06 10:41:17',0,0),(2037,1019,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 10:42:12',0,0),(2038,1019,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 10:42:12',0,0),(2039,1020,'111',5400000,0,NULL,NULL,NULL,'2021-04-06 10:47:06',0,0),(2040,1020,'150',0,5400000,NULL,NULL,NULL,'2021-04-06 10:47:06',0,0),(2041,1021,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 10:47:31',0,0),(2042,1021,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 10:47:31',0,0),(2043,1022,'111',7200000,0,NULL,NULL,NULL,'2021-04-06 10:50:29',0,0),(2044,1022,'150',0,7200000,NULL,NULL,NULL,'2021-04-06 10:50:29',0,0),(2045,1023,'150',6850000,0,NULL,NULL,NULL,'2021-04-06 10:59:46',0,0),(2046,1023,'411',0,6850000,NULL,NULL,NULL,'2021-04-06 10:59:46',0,0),(2047,1024,'111',4650000,0,NULL,NULL,NULL,'2021-04-06 11:10:15',0,0),(2048,1024,'150',0,4650000,NULL,NULL,NULL,'2021-04-06 11:10:15',0,0),(2049,1025,'150',7200000,0,NULL,NULL,NULL,'2021-04-06 11:12:29',0,0),(2050,1025,'411',0,7200000,NULL,NULL,NULL,'2021-04-06 11:12:29',0,0),(2051,1026,'111',4800000,0,NULL,NULL,NULL,'2021-04-06 11:14:45',0,0),(2052,1026,'150',0,4800000,NULL,NULL,NULL,'2021-04-06 11:14:45',0,0),(2053,1027,'111',5100000,0,NULL,NULL,NULL,'2021-04-07 15:22:07',0,0),(2054,1027,'150',0,5100000,NULL,NULL,NULL,'2021-04-07 15:22:07',0,0),(2055,1028,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:23:46',0,0),(2056,1028,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:23:46',0,0),(2057,1029,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:24:48',0,0),(2058,1029,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:24:48',0,0),(2059,1030,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:27:18',0,0),(2060,1030,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:27:18',0,0),(2061,1031,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:29:03',0,0),(2062,1031,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:29:03',0,0),(2063,1032,'111',1000000,0,NULL,NULL,NULL,'2021-04-07 15:30:44',0,0),(2064,1032,'150',0,1000000,NULL,NULL,NULL,'2021-04-07 15:30:44',0,0),(2065,1033,'111',550000,0,NULL,NULL,NULL,'2021-04-07 15:33:09',0,0),(2066,1033,'150',0,550000,NULL,NULL,NULL,'2021-04-07 15:33:09',0,0),(2067,1034,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:34:11',0,0),(2068,1034,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:34:11',0,0),(2069,1035,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:35:24',0,0),(2070,1035,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:35:24',0,0),(2071,1036,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:37:44',0,0),(2072,1036,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:37:44',0,0),(2073,1037,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:39:01',0,0),(2074,1037,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:39:01',0,0),(2075,1038,'111',600000,0,NULL,NULL,NULL,'2021-04-07 15:39:44',0,0),(2076,1038,'150',0,600000,NULL,NULL,NULL,'2021-04-07 15:39:44',0,0),(2077,1039,'150',6900000,0,NULL,NULL,NULL,'2021-04-07 15:40:58',0,0),(2078,1039,'411',0,6900000,NULL,NULL,NULL,'2021-04-07 15:40:58',0,0),(2079,1040,'111',5100000,0,NULL,NULL,NULL,'2021-04-07 15:43:04',0,0),(2080,1040,'150',0,5100000,NULL,NULL,NULL,'2021-04-07 15:43:04',0,0),(2081,1041,'150',6900000,0,NULL,NULL,NULL,'2021-04-07 15:44:03',0,0),(2082,1041,'411',0,6900000,NULL,NULL,NULL,'2021-04-07 15:44:03',0,0),(2083,1042,'111',5100000,0,NULL,NULL,NULL,'2021-04-07 15:46:08',0,0),(2084,1042,'150',0,5100000,NULL,NULL,NULL,'2021-04-07 15:46:08',0,0),(2085,1043,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:08:40',0,0),(2086,1043,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:08:40',0,0),(2087,1044,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:10:10',0,0),(2088,1044,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:10:10',0,0),(2089,1045,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:11:36',0,0),(2090,1045,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:11:36',0,0),(2091,1046,'111',3300000,0,NULL,NULL,NULL,'2021-04-15 13:14:17',0,0),(2092,1046,'150',0,3300000,NULL,NULL,NULL,'2021-04-15 13:14:17',0,0),(2093,1047,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:14:42',0,0),(2094,1047,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:14:42',0,0),(2095,1048,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:16:13',0,0),(2096,1048,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:16:13',0,0),(2097,1049,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:16:52',0,0),(2098,1049,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:16:52',0,0),(2099,1050,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:18:26',0,0),(2100,1050,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:18:26',0,0),(2101,1051,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:18:46',0,0),(2102,1051,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:18:46',0,0),(2103,1052,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:20:15',0,0),(2104,1052,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:20:15',0,0),(2105,1053,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:20:40',0,0),(2106,1053,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:20:40',0,0),(2107,1054,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:21:58',0,0),(2108,1054,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:21:58',0,0),(2109,1055,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:22:21',0,0),(2110,1055,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:22:21',0,0),(2111,1056,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:23:26',0,0),(2112,1056,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:23:26',0,0),(2113,1057,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:23:46',0,0),(2114,1057,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:23:46',0,0),(2115,1058,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:25:12',0,0),(2116,1058,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:25:12',0,0),(2117,1059,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:25:36',0,0),(2118,1059,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:25:36',0,0),(2119,1060,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:26:28',0,0),(2120,1060,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:26:28',0,0),(2121,1061,'150',6250000,0,NULL,NULL,NULL,'2021-04-15 13:29:28',0,0),(2122,1061,'411',0,6250000,NULL,NULL,NULL,'2021-04-15 13:29:28',0,0),(2123,1062,'111',4600000,0,NULL,NULL,NULL,'2021-04-15 13:32:07',0,0),(2124,1062,'150',0,4600000,NULL,NULL,NULL,'2021-04-15 13:32:07',0,0),(2125,1063,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:32:23',0,0),(2126,1063,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:32:23',0,0),(2127,1064,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:34:08',0,0),(2128,1064,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:34:08',0,0),(2129,1065,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:34:28',0,0),(2130,1065,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:34:28',0,0),(2131,1066,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 13:35:38',0,0),(2132,1066,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 13:35:38',0,0),(2133,1067,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:36:12',0,0),(2134,1067,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:36:12',0,0),(2135,1068,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 13:37:25',0,0),(2136,1068,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 13:37:25',0,0),(2137,1069,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:37:58',0,0),(2138,1069,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:37:58',0,0),(2139,1070,'111',600000,0,NULL,NULL,NULL,'2021-04-15 13:41:41',0,0),(2140,1070,'150',0,600000,NULL,NULL,NULL,'2021-04-15 13:41:41',0,0),(2141,1071,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:43:28',0,0),(2142,1071,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:43:28',0,0),(2143,1072,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:44:25',0,0),(2144,1072,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:44:25',0,0),(2145,1073,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:44:42',0,0),(2146,1073,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:44:42',0,0),(2147,1074,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:45:38',0,0),(2148,1074,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:45:38',0,0),(2149,1075,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:45:58',0,0),(2150,1075,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:45:58',0,0),(2151,1076,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 13:47:08',0,0),(2152,1076,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 13:47:08',0,0),(2153,1077,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:47:37',0,0),(2154,1077,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:47:37',0,0),(2155,1078,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 13:47:52',0,0),(2156,1078,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 13:47:52',0,0),(2157,1079,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:48:21',0,0),(2158,1079,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:48:21',0,0),(2159,1080,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:49:14',0,0),(2160,1080,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:49:14',0,0),(2161,1081,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:49:33',0,0),(2162,1081,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:49:33',0,0),(2163,1082,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:50:41',0,0),(2164,1082,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:50:41',0,0),(2165,1083,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:51:00',0,0),(2166,1083,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:51:00',0,0),(2167,1084,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:52:06',0,0),(2168,1084,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:52:06',0,0),(2169,1085,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:52:24',0,0),(2170,1085,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:52:24',0,0),(2171,1086,'111',2700000,0,NULL,NULL,NULL,'2021-04-15 13:54:12',0,0),(2172,1086,'150',0,2700000,NULL,NULL,NULL,'2021-04-15 13:54:12',0,0),(2173,1087,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:55:12',0,0),(2174,1087,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:55:12',0,0),(2175,1088,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 13:56:08',0,0),(2176,1088,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 13:56:08',0,0),(2177,1089,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:56:31',0,0),(2178,1089,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:56:31',0,0),(2179,1090,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:57:27',0,0),(2180,1090,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:57:27',0,0),(2181,1091,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:57:44',0,0),(2182,1091,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:57:44',0,0),(2183,1092,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 13:59:28',0,0),(2184,1092,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 13:59:28',0,0),(2185,1093,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 13:59:46',0,0),(2186,1093,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 13:59:46',0,0),(2187,1094,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 14:00:58',0,0),(2188,1094,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 14:00:58',0,0),(2189,1095,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 14:01:22',0,0),(2190,1095,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 14:01:22',0,0),(2191,1096,'111',3300000,0,NULL,NULL,NULL,'2021-04-15 14:02:37',0,0),(2192,1096,'150',0,3300000,NULL,NULL,NULL,'2021-04-15 14:02:37',0,0),(2193,1097,'150',6290000,0,NULL,NULL,NULL,'2021-04-15 20:18:48',0,0),(2194,1097,'411',0,6290000,NULL,NULL,NULL,'2021-04-15 20:18:48',0,0),(2195,1098,'111',4640000,0,NULL,NULL,NULL,'2021-04-15 20:21:09',0,0),(2196,1098,'150',0,4640000,NULL,NULL,NULL,'2021-04-15 20:21:09',0,0),(2197,1099,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:21:29',0,0),(2198,1099,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:21:29',0,0),(2199,1100,'111',3900000,0,NULL,NULL,NULL,'2021-04-15 20:23:42',0,0),(2200,1100,'150',0,3900000,NULL,NULL,NULL,'2021-04-15 20:23:42',0,0),(2201,1101,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:23:55',0,0),(2202,1101,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:23:55',0,0),(2203,1102,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 20:25:08',0,0),(2204,1102,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 20:25:08',0,0),(2205,1103,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:25:31',0,0),(2206,1103,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:25:31',0,0),(2207,1104,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 20:27:09',0,0),(2208,1104,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 20:27:09',0,0),(2209,1105,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:27:36',0,0),(2210,1105,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:27:36',0,0),(2211,1106,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 20:28:51',0,0),(2212,1106,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 20:28:51',0,0),(2213,1107,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:29:03',0,0),(2214,1107,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:29:03',0,0),(2215,1108,'111',5700000,0,NULL,NULL,NULL,'2021-04-15 20:30:37',0,0),(2216,1108,'150',0,5700000,NULL,NULL,NULL,'2021-04-15 20:30:37',0,0),(2217,1109,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:31:04',0,0),(2218,1109,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:31:04',0,0),(2219,1110,'111',4500000,0,NULL,NULL,NULL,'2021-04-15 20:32:10',0,0),(2220,1110,'150',0,4500000,NULL,NULL,NULL,'2021-04-15 20:32:10',0,0),(2221,1111,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:32:54',0,0),(2222,1111,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:32:54',0,0),(2223,1112,'111',5100000,0,NULL,NULL,NULL,'2021-04-15 20:35:54',0,0),(2224,1112,'150',0,5100000,NULL,NULL,NULL,'2021-04-15 20:35:54',0,0),(2225,1113,'150',6900000,0,NULL,NULL,NULL,'2021-04-15 20:36:38',0,0),(2226,1113,'411',0,6900000,NULL,NULL,NULL,'2021-04-15 20:36:38',0,0),(2227,1114,'111',3900000,0,NULL,NULL,NULL,'2021-04-15 20:38:42',0,0),(2228,1114,'150',0,3900000,NULL,NULL,NULL,'2021-04-15 20:38:42',0,0),(2229,1115,'150',6000000,0,NULL,NULL,NULL,'2021-04-15 20:40:31',0,0),(2230,1115,'411',0,6000000,NULL,NULL,NULL,'2021-04-15 20:40:31',0,0),(2231,1116,'111',2400000,0,NULL,NULL,NULL,'2021-04-15 20:53:29',0,0),(2232,1116,'150',0,2400000,NULL,NULL,NULL,'2021-04-15 20:53:29',0,0),(2233,1117,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:07:59',0,0),(2234,1117,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:07:59',0,0),(2235,1118,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 19:09:06',0,0),(2236,1118,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 19:09:06',0,0),(2237,1119,'150',6310000,0,NULL,NULL,NULL,'2021-04-16 19:09:51',0,0),(2238,1119,'411',0,6310000,NULL,NULL,NULL,'2021-04-16 19:09:51',0,0),(2239,1120,'111',4660000,0,NULL,NULL,NULL,'2021-04-16 19:13:14',0,0),(2240,1120,'150',0,4660000,NULL,NULL,NULL,'2021-04-16 19:13:14',0,0),(2241,1121,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:13:41',0,0),(2242,1121,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:13:41',0,0),(2243,1122,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 19:14:57',0,0),(2244,1122,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 19:14:57',0,0),(2245,1123,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:15:24',0,0),(2246,1123,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:15:24',0,0),(2247,1124,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 19:16:28',0,0),(2248,1124,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 19:16:28',0,0),(2249,1125,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:18:30',0,0),(2250,1125,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:18:30',0,0),(2251,1126,'111',5700000,0,NULL,NULL,NULL,'2021-04-16 19:20:16',0,0),(2252,1126,'150',0,5700000,NULL,NULL,NULL,'2021-04-16 19:20:16',0,0),(2253,1127,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:21:25',0,0),(2254,1127,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:21:25',0,0),(2255,1128,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 19:22:51',0,0),(2256,1128,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 19:22:51',0,0),(2257,1129,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:23:13',0,0),(2258,1129,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:23:13',0,0),(2259,1130,'111',3300000,0,NULL,NULL,NULL,'2021-04-16 19:25:14',0,0),(2260,1130,'150',0,3300000,NULL,NULL,NULL,'2021-04-16 19:25:14',0,0),(2261,1131,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:31:20',0,0),(2262,1131,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:31:20',0,0),(2263,1132,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 19:32:21',0,0),(2264,1132,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 19:32:21',0,0),(2265,1133,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:32:53',0,0),(2266,1133,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:32:53',0,0),(2267,1134,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 19:33:51',0,0),(2268,1134,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 19:33:51',0,0),(2269,1135,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 19:36:11',0,0),(2270,1135,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 19:36:11',0,0),(2271,1136,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 21:04:23',0,0),(2272,1136,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 21:04:23',0,0),(2273,1137,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:04:50',0,0),(2274,1137,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:04:50',0,0),(2275,1138,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 21:06:30',0,0),(2276,1138,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 21:06:30',0,0),(2277,1139,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:08:47',0,0),(2278,1139,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:08:47',0,0),(2279,1140,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 21:10:15',0,0),(2280,1140,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 21:10:15',0,0),(2281,1141,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:10:44',0,0),(2282,1141,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:10:44',0,0),(2283,1142,'111',3300000,0,NULL,NULL,NULL,'2021-04-16 21:11:35',0,0),(2284,1142,'150',0,3300000,NULL,NULL,NULL,'2021-04-16 21:11:35',0,0),(2285,1143,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:11:59',0,0),(2286,1143,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:11:59',0,0),(2287,1144,'111',3900000,0,NULL,NULL,NULL,'2021-04-16 21:12:58',0,0),(2288,1144,'150',0,3900000,NULL,NULL,NULL,'2021-04-16 21:12:58',0,0),(2289,1145,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:15:29',0,0),(2290,1145,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:15:29',0,0),(2291,1146,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 21:17:54',0,0),(2292,1146,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 21:17:54',0,0),(2293,1147,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:18:54',0,0),(2294,1147,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:18:54',0,0),(2295,1148,'111',5700000,0,NULL,NULL,NULL,'2021-04-16 21:20:36',0,0),(2296,1148,'150',0,5700000,NULL,NULL,NULL,'2021-04-16 21:20:36',0,0),(2297,1149,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:21:11',0,0),(2298,1149,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:21:11',0,0),(2299,1150,'111',3900000,0,NULL,NULL,NULL,'2021-04-16 21:22:19',0,0),(2300,1150,'150',0,3900000,NULL,NULL,NULL,'2021-04-16 21:22:19',0,0),(2301,1151,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:22:55',0,0),(2302,1151,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:22:55',0,0),(2303,1152,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 21:25:26',0,0),(2304,1152,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 21:25:26',0,0),(2305,1153,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:27:49',0,0),(2306,1153,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:27:49',0,0),(2307,1154,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 21:29:13',0,0),(2308,1154,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 21:29:13',0,0),(2309,1155,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:29:50',0,0),(2310,1155,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:29:50',0,0),(2311,1156,'111',920000,0,NULL,NULL,NULL,'2021-04-16 21:31:56',0,0),(2312,1156,'150',0,920000,NULL,NULL,NULL,'2021-04-16 21:31:56',0,0),(2313,1157,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:32:19',0,0),(2314,1157,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:32:19',0,0),(2315,1158,'111',5700000,0,NULL,NULL,NULL,'2021-04-16 21:33:50',0,0),(2316,1158,'150',0,5700000,NULL,NULL,NULL,'2021-04-16 21:33:50',0,0),(2317,1159,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:34:28',0,0),(2318,1159,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:34:28',0,0),(2319,1160,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 21:35:56',0,0),(2320,1160,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 21:35:56',0,0),(2321,1161,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:36:45',0,0),(2322,1161,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:36:45',0,0),(2323,1162,'111',3300000,0,NULL,NULL,NULL,'2021-04-16 21:37:52',0,0),(2324,1162,'150',0,3300000,NULL,NULL,NULL,'2021-04-16 21:37:52',0,0),(2325,1163,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:38:13',0,0),(2326,1163,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:38:13',0,0),(2327,1164,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 21:39:16',0,0),(2328,1164,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 21:39:16',0,0),(2329,1165,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:39:41',0,0),(2330,1165,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:39:41',0,0),(2331,1166,'111',4500000,0,NULL,NULL,NULL,'2021-04-16 21:41:09',0,0),(2332,1166,'150',0,4500000,NULL,NULL,NULL,'2021-04-16 21:41:09',0,0),(2333,1167,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:42:08',0,0),(2334,1167,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:42:08',0,0),(2335,1168,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 21:43:22',0,0),(2336,1168,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 21:43:22',0,0),(2337,1169,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:43:39',0,0),(2338,1169,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:43:39',0,0),(2339,1170,'111',5100000,0,NULL,NULL,NULL,'2021-04-16 21:44:47',0,0),(2340,1170,'150',0,5100000,NULL,NULL,NULL,'2021-04-16 21:44:47',0,0),(2341,1171,'150',4800000,0,NULL,NULL,NULL,'2021-04-16 21:46:02',0,0),(2342,1171,'411',0,4800000,NULL,NULL,NULL,'2021-04-16 21:46:02',0,0),(2343,1172,'111',3000000,0,NULL,NULL,NULL,'2021-04-16 21:47:19',0,0),(2344,1172,'150',0,3000000,NULL,NULL,NULL,'2021-04-16 21:47:19',0,0),(2345,1173,'150',6900000,0,NULL,NULL,NULL,'2021-04-16 21:48:21',0,0),(2346,1173,'411',0,6900000,NULL,NULL,NULL,'2021-04-16 21:48:21',0,0),(2347,1174,'111',2100000,0,NULL,NULL,NULL,'2021-04-16 21:49:14',0,0),(2348,1174,'150',0,2100000,NULL,NULL,NULL,'2021-04-16 21:49:14',0,0),(2349,1175,'150',6900000,0,NULL,NULL,NULL,'2021-04-17 18:40:37',0,0),(2350,1175,'411',0,6900000,NULL,NULL,NULL,'2021-04-17 18:40:37',0,0),(2351,1176,'111',6900000,0,NULL,NULL,NULL,'2021-04-17 18:42:26',0,0),(2352,1176,'150',0,6900000,NULL,NULL,NULL,'2021-04-17 18:42:26',0,0),(2353,1177,'150',6900000,0,NULL,NULL,NULL,'2021-04-17 18:42:50',0,0),(2354,1177,'411',0,6900000,NULL,NULL,NULL,'2021-04-17 18:42:50',0,0),(2355,1178,'111',3900000,0,NULL,NULL,NULL,'2021-04-17 18:43:43',0,0),(2356,1178,'150',0,3900000,NULL,NULL,NULL,'2021-04-17 18:43:43',0,0),(2357,1179,'150',6310000,0,NULL,NULL,NULL,'2021-04-17 18:52:17',0,0),(2358,1179,'411',0,6310000,NULL,NULL,NULL,'2021-04-17 18:52:17',0,0),(2359,1180,'111',3560000,0,NULL,NULL,NULL,'2021-04-17 19:47:08',0,0),(2360,1180,'150',0,3560000,NULL,NULL,NULL,'2021-04-17 19:47:08',0,0),(2361,1181,'150',6900000,0,NULL,NULL,NULL,'2021-04-17 19:50:10',0,0),(2362,1181,'411',0,6900000,NULL,NULL,NULL,'2021-04-17 19:50:10',0,0),(2363,1182,'111',5100000,0,NULL,NULL,NULL,'2021-04-17 19:53:05',0,0),(2364,1182,'150',0,5100000,NULL,NULL,NULL,'2021-04-17 19:53:05',0,0),(2365,1183,'150',6900000,0,NULL,NULL,NULL,'2021-04-17 20:39:28',0,0),(2366,1183,'411',0,6900000,NULL,NULL,NULL,'2021-04-17 20:39:28',0,0),(2367,1184,'111',4500000,0,NULL,NULL,NULL,'2021-04-17 20:41:03',0,0),(2368,1184,'150',0,4500000,NULL,NULL,NULL,'2021-04-17 20:41:03',0,0),(2369,1185,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:22:59',0,0),(2370,1185,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:22:59',0,0),(2371,1186,'111',3900000,0,NULL,NULL,NULL,'2021-04-18 09:25:21',0,0),(2372,1186,'150',0,3900000,NULL,NULL,NULL,'2021-04-18 09:25:21',0,0),(2373,1187,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:25:43',0,0),(2374,1187,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:25:43',0,0),(2375,1188,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 09:26:01',0,0),(2376,1188,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 09:26:01',0,0),(2377,1189,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:27:02',0,0),(2378,1189,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:27:02',0,0),(2379,1190,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 09:28:16',0,0),(2380,1190,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 09:28:16',0,0),(2381,1191,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:32:20',0,0),(2382,1191,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:32:20',0,0),(2383,1192,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 09:33:29',0,0),(2384,1192,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 09:33:29',0,0),(2385,1193,'150',6310000,0,NULL,NULL,NULL,'2021-04-18 09:36:32',0,0),(2386,1193,'411',0,6310000,NULL,NULL,NULL,'2021-04-18 09:36:32',0,0),(2387,1194,'111',3280000,0,NULL,NULL,NULL,'2021-04-18 09:38:04',0,0),(2388,1194,'150',0,3280000,NULL,NULL,NULL,'2021-04-18 09:38:04',0,0),(2389,1195,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:39:03',0,0),(2390,1195,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:39:03',0,0),(2391,1196,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 09:40:22',0,0),(2392,1196,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 09:40:22',0,0),(2393,1197,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:40:43',0,0),(2394,1197,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:40:43',0,0),(2395,1198,'111',5700000,0,NULL,NULL,NULL,'2021-04-18 09:42:06',0,0),(2396,1198,'150',0,5700000,NULL,NULL,NULL,'2021-04-18 09:42:06',0,0),(2397,1199,'150',4200000,0,NULL,NULL,NULL,'2021-04-18 09:43:01',0,0),(2398,1199,'411',0,4200000,NULL,NULL,NULL,'2021-04-18 09:43:01',0,0),(2399,1200,'111',2100000,0,NULL,NULL,NULL,'2021-04-18 09:48:01',0,0),(2400,1200,'150',0,2100000,NULL,NULL,NULL,'2021-04-18 09:48:01',0,0),(2401,1201,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 09:48:43',0,0),(2402,1201,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 09:48:43',0,0),(2403,1202,'111',3900000,0,NULL,NULL,NULL,'2021-04-18 09:50:27',0,0),(2404,1202,'150',0,3900000,NULL,NULL,NULL,'2021-04-18 09:50:27',0,0),(2405,1203,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:16:59',0,0),(2406,1203,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:16:59',0,0),(2407,1204,'111',2100000,0,NULL,NULL,NULL,'2021-04-18 10:17:51',0,0),(2408,1204,'150',0,2100000,NULL,NULL,NULL,'2021-04-18 10:17:51',0,0),(2409,1205,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:18:34',0,0),(2410,1205,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:18:34',0,0),(2411,1206,'111',3300000,0,NULL,NULL,NULL,'2021-04-18 10:19:34',0,0),(2412,1206,'150',0,3300000,NULL,NULL,NULL,'2021-04-18 10:19:34',0,0),(2413,1207,'150',2400000,0,NULL,NULL,NULL,'2021-04-18 10:20:17',0,0),(2414,1207,'411',0,2400000,NULL,NULL,NULL,'2021-04-18 10:20:17',0,0),(2415,1208,'111',1600000,0,NULL,NULL,NULL,'2021-04-18 10:21:32',0,0),(2416,1208,'150',0,1600000,NULL,NULL,NULL,'2021-04-18 10:21:32',0,0),(2417,1209,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:22:01',0,0),(2418,1209,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:22:01',0,0),(2419,1210,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 10:23:18',0,0),(2420,1210,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 10:23:18',0,0),(2421,1211,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:25:00',0,0),(2422,1211,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:25:00',0,0),(2423,1212,'111',4800000,0,NULL,NULL,NULL,'2021-04-18 10:26:15',0,0),(2424,1212,'150',0,4800000,NULL,NULL,NULL,'2021-04-18 10:26:15',0,0),(2425,1213,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:26:57',0,0),(2426,1213,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:26:57',0,0),(2427,1214,'111',5700000,0,NULL,NULL,NULL,'2021-04-18 10:28:55',0,0),(2428,1214,'150',0,5700000,NULL,NULL,NULL,'2021-04-18 10:28:55',0,0),(2429,1215,'150',2400000,0,NULL,NULL,NULL,'2021-04-18 10:29:32',0,0),(2430,1215,'411',0,2400000,NULL,NULL,NULL,'2021-04-18 10:29:32',0,0),(2431,1216,'111',1800000,0,NULL,NULL,NULL,'2021-04-18 10:31:07',0,0),(2432,1216,'150',0,1800000,NULL,NULL,NULL,'2021-04-18 10:31:07',0,0),(2433,1217,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:37:14',0,0),(2434,1217,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:37:14',0,0),(2435,1218,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 10:38:29',0,0),(2436,1218,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 10:38:29',0,0),(2437,1219,'150',5580000,0,NULL,NULL,NULL,'2021-04-18 10:39:13',0,0),(2438,1219,'411',0,5580000,NULL,NULL,NULL,'2021-04-18 10:39:13',0,0),(2439,1220,'111',4620000,0,NULL,NULL,NULL,'2021-04-18 10:40:55',0,0),(2440,1220,'150',0,4620000,NULL,NULL,NULL,'2021-04-18 10:40:55',0,0),(2441,1221,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:41:40',0,0),(2442,1221,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:41:40',0,0),(2443,1222,'111',5700000,0,NULL,NULL,NULL,'2021-04-18 10:42:52',0,0),(2444,1222,'150',0,5700000,NULL,NULL,NULL,'2021-04-18 10:42:52',0,0),(2445,1223,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:48:12',0,0),(2446,1223,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:48:12',0,0),(2447,1224,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 10:51:11',0,0),(2448,1224,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 10:51:11',0,0),(2449,1225,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:51:54',0,0),(2450,1225,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:51:54',0,0),(2451,1226,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 10:52:59',0,0),(2452,1226,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 10:52:59',0,0),(2453,1227,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 10:53:28',0,0),(2454,1227,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 10:53:28',0,0),(2455,1228,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 10:54:22',0,0),(2456,1228,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 10:54:22',0,0),(2457,1229,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:15:08',0,0),(2458,1229,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:15:08',0,0),(2459,1230,'111',5700000,0,NULL,NULL,NULL,'2021-04-18 11:16:58',0,0),(2460,1230,'150',0,5700000,NULL,NULL,NULL,'2021-04-18 11:16:58',0,0),(2461,1231,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:17:28',0,0),(2462,1231,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:17:28',0,0),(2463,1232,'111',3900000,0,NULL,NULL,NULL,'2021-04-18 11:18:37',0,0),(2464,1232,'150',0,3900000,NULL,NULL,NULL,'2021-04-18 11:18:37',0,0),(2465,1233,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:19:00',0,0),(2466,1233,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:19:00',0,0),(2467,1234,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 11:19:52',0,0),(2468,1234,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 11:19:52',0,0),(2469,1235,'150',6310000,0,NULL,NULL,NULL,'2021-04-18 11:20:51',0,0),(2470,1235,'411',0,6310000,NULL,NULL,NULL,'2021-04-18 11:20:51',0,0),(2471,1236,'111',4660000,0,NULL,NULL,NULL,'2021-04-18 11:22:22',0,0),(2472,1236,'150',0,4660000,NULL,NULL,NULL,'2021-04-18 11:22:22',0,0),(2473,1237,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:22:43',0,0),(2474,1237,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:22:43',0,0),(2475,1238,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 11:23:54',0,0),(2476,1238,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 11:23:54',0,0),(2477,1239,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:24:24',0,0),(2478,1239,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:24:24',0,0),(2479,1240,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 11:25:21',0,0),(2480,1240,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 11:25:21',0,0),(2481,1241,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:25:48',0,0),(2482,1241,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:25:48',0,0),(2483,1242,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 11:27:08',0,0),(2484,1242,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 11:27:08',0,0),(2485,1243,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:27:41',0,0),(2486,1243,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:27:41',0,0),(2487,1244,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 11:28:47',0,0),(2488,1244,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 11:28:47',0,0),(2489,1245,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:29:08',0,0),(2490,1245,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:29:08',0,0),(2491,1246,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 11:30:56',0,0),(2492,1246,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 11:30:56',0,0),(2493,1247,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:32:33',0,0),(2494,1247,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:32:33',0,0),(2495,1248,'111',3900000,0,NULL,NULL,NULL,'2021-04-18 11:33:23',0,0),(2496,1248,'150',0,3900000,NULL,NULL,NULL,'2021-04-18 11:33:23',0,0),(2497,1249,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:33:42',0,0),(2498,1249,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:33:42',0,0),(2499,1250,'111',4500000,0,NULL,NULL,NULL,'2021-04-18 11:34:37',0,0),(2500,1250,'150',0,4500000,NULL,NULL,NULL,'2021-04-18 11:34:37',0,0),(2501,1251,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:34:47',0,0),(2502,1251,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:34:47',0,0),(2503,1252,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 11:35:37',0,0),(2504,1252,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 11:35:37',0,0),(2505,1253,'150',6900000,0,NULL,NULL,NULL,'2021-04-18 11:35:51',0,0),(2506,1253,'411',0,6900000,NULL,NULL,NULL,'2021-04-18 11:35:51',0,0),(2507,1254,'111',5100000,0,NULL,NULL,NULL,'2021-04-18 11:37:11',0,0),(2508,1254,'150',0,5100000,NULL,NULL,NULL,'2021-04-18 11:37:11',0,0),(2509,1255,'111',1200000,0,NULL,NULL,NULL,'2021-04-19 09:22:50',0,0),(2510,1255,'150',0,1200000,NULL,NULL,NULL,'2021-04-19 09:22:50',0,0),(2511,1256,'111',600000,0,NULL,NULL,NULL,'2021-04-19 09:23:47',0,0),(2512,1256,'150',0,600000,NULL,NULL,NULL,'2021-04-19 09:23:47',0,0),(2513,1257,'111',2400000,0,NULL,NULL,NULL,'2021-04-19 09:24:28',0,0),(2514,1257,'150',0,2400000,NULL,NULL,NULL,'2021-04-19 09:24:28',0,0),(2515,1258,'150',6900000,0,NULL,NULL,NULL,'2021-04-19 11:16:09',0,0),(2516,1258,'411',0,6900000,NULL,NULL,NULL,'2021-04-19 11:16:09',0,0),(2517,1259,'111',5100000,0,NULL,NULL,NULL,'2021-04-19 11:22:18',0,0),(2518,1259,'150',0,5100000,NULL,NULL,NULL,'2021-04-19 11:22:18',0,0),(2519,1260,'150',6900000,0,NULL,NULL,NULL,'2021-04-19 11:22:53',0,0),(2520,1260,'411',0,6900000,NULL,NULL,NULL,'2021-04-19 11:22:53',0,0),(2521,1261,'111',4500000,0,NULL,NULL,NULL,'2021-04-19 11:24:14',0,0),(2522,1261,'150',0,4500000,NULL,NULL,NULL,'2021-04-19 11:24:14',0,0),(2523,1262,'150',7200000,0,NULL,NULL,NULL,'2021-07-12 20:50:24',0,0),(2524,1262,'411',0,7200000,NULL,NULL,NULL,'2021-07-12 20:50:24',0,0),(2525,1263,'111',6600000,0,NULL,NULL,NULL,'2021-07-12 20:52:50',0,0),(2526,1263,'150',0,6600000,NULL,NULL,NULL,'2021-07-12 20:52:50',0,0),(2527,1264,'150',7200000,0,NULL,NULL,NULL,'2021-07-12 20:55:07',0,0),(2528,1264,'411',0,7200000,NULL,NULL,NULL,'2021-07-12 20:55:07',0,0),(2529,1265,'111',6600000,0,NULL,NULL,NULL,'2021-07-12 20:57:09',0,0),(2530,1265,'150',0,6600000,NULL,NULL,NULL,'2021-07-12 20:57:09',0,0),(2531,1266,'150',7200000,0,NULL,NULL,NULL,'2021-07-12 21:33:48',0,0),(2532,1266,'411',0,7200000,NULL,NULL,NULL,'2021-07-12 21:33:48',0,0),(2533,1267,'111',6600000,0,NULL,NULL,NULL,'2021-07-12 21:33:59',0,0),(2534,1267,'150',0,6600000,NULL,NULL,NULL,'2021-07-12 21:33:59',0,0),(2535,1268,'150',7200000,0,NULL,NULL,NULL,'2021-07-12 21:34:34',0,0),(2536,1268,'411',0,7200000,NULL,NULL,NULL,'2021-07-12 21:34:34',0,0),(2537,1269,'111',6600000,0,NULL,NULL,NULL,'2021-07-12 21:35:08',0,0),(2538,1269,'150',0,6600000,NULL,NULL,NULL,'2021-07-12 21:35:08',0,0),(2539,1270,'150',7200000,0,NULL,NULL,NULL,'2021-07-12 21:35:40',0,0),(2540,1270,'411',0,7200000,NULL,NULL,NULL,'2021-07-12 21:35:40',0,0),(2541,1271,'111',7200000,0,NULL,NULL,NULL,'2021-07-12 21:37:25',0,0),(2542,1271,'150',0,7200000,NULL,NULL,NULL,'2021-07-12 21:37:25',0,0);

#
# Structure for table "transaksilog"
#

DROP TABLE IF EXISTS `jbsfina`.`transaksilog`;
CREATE TABLE `jbsfina`.`transaksilog` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sumber` varchar(45) NOT NULL,
  `idsumber` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `transaksi` varchar(255) NOT NULL,
  `petugas` varchar(100) NOT NULL,
  `nokas` varchar(100) NOT NULL,
  `idtahunbuku` int(10) unsigned NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `debet` decimal(15,0) NOT NULL DEFAULT '0',
  `kredit` decimal(15,0) NOT NULL DEFAULT '0',
  `departemen` varchar(50) NOT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  `info3` varchar(255) DEFAULT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` smallint(5) unsigned NOT NULL DEFAULT '0',
  `issync` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_transaksilog_departemen` (`departemen`),
  KEY `IX_transaksilog_ts` (`ts`,`issync`),
  CONSTRAINT `FK_transaksilog_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=496 DEFAULT CHARSET=utf8;

#
# Data for table "transaksilog"
#

INSERT INTO `transaksilog` VALUES (36,'penerimaanjtt',36,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ADNAN HALIM HUSNI (19.2243)','Supria Ningsih','2021000002',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(37,'penerimaanjtt',37,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD DANI (19.2245)','Supria Ningsih','2021000004',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(38,'penerimaanjtt',38,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD HASROH SIREGAR (19.2246)','Supria Ningsih','2021000006',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(39,'penerimaanjtt',39,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AHMAD RIZKY FAHLEVI HARAHAP (19.2247)','Supria Ningsih','2021000008',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(40,'penerimaanjtt',40,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AL HAYDI FAUZAN NASUTION (19.2250)','Supria Ningsih','2021000010',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(41,'penerimaanjtt',41,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa AWALUDDIN AHMAD (19.2254)','Supria Ningsih','2021000012',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(42,'penerimaanjtt',42,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa DANANG FERIAWAN (19.2256)','Supria Ningsih','2021000014',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(43,'penerimaanjtt',43,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ERI GUNTUR MANURUNG (19.2259)','Supria Ningsih','2021000016',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(44,'penerimaanjtt',44,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FAISAL (19.2260)','Supria Ningsih','2021000018',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(45,'penerimaanjtt',45,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FARIS ANWAR (19.2261)','Supria Ningsih','2021000020',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(46,'penerimaanjtt',46,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa FIKRI ADTYA PRANANTA (19.2263)','Supria Ningsih','2021000022',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(47,'penerimaanjtt',47,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIDHO KURNIA (19.2278)','Supria Ningsih','2021000024',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(48,'penerimaanjtt',48,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIO BARUARA TAMBUNAN (19.2281)','Supria Ningsih','2021000026',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(49,'penerimaanjtt',49,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RIZKY ARDIANSYAH SIREGAR (19.2283)','Supria Ningsih','2021000028',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(50,'penerimaanjtt',50,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa RAMADANI SYAFITRA SIREGAR (19.2288)','Supria Ningsih','2021000030',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(51,'penerimaanjtt',51,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ABDUL KHALIQ LUBIS (19.2290)','Supria Ningsih','2021000032',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(52,'penerimaanjtt',52,'2021-04-01','Pendataan besar pembayaran SPP Bulanan MA siswa ASBI NASUTION (19.2298)','Supria Ningsih','2021000034',1,'',0,0,'ALIYAH',NULL,NULL,NULL,'2021-04-01 23:07:10',0,0),(53,'penerimaanjtt',53,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL HAFIZ (20.3415)','Rika Erliani Harahap S. Hum','2020000002',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:11:50',0,0),(54,'penerimaanjtt',54,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABGI MALLDANO KESUMA (20.3417)','Rika Erliani Harahap S. Hum','2020000004',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:17:54',0,0),(55,'penerimaanjtt',55,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABI HAQQI AZZUHDA (20.3418)','Rika Erliani Harahap S. Hum','2020000006',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:26:01',0,0),(283,'penerimaanjtt',283,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABY FERDINAL ROHENDY (20.3420)','Rika Erliani Harahap S. Hum','2020000008',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:36:10',0,0),(284,'penerimaanjtt',284,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ACHMAD SATRIA (20.3421)','Rika Erliani Harahap S. Hum','2020000011',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:39:15',0,0),(285,'penerimaanjtt',285,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL AZIS DAULAY (19.3010)','Jahratul Jannah','2020000013',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:43:47',0,0),(286,'penerimaanjtt',286,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL GHANI AMENDA (19.3012)','Jahratul Jannah','2020000015',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 11:51:38',0,0),(287,'penerimaanjtt',287,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AFRIZAL ARBI (20.3425)','Rika Erliani Harahap S. Hum','2020000017',2,'',2100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:02:53',0,0),(288,'penerimaanjtt',288,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ADIMAS PRISKA (20.3422)','Rika Erliani Harahap S. Hum','2020000019',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:24:46',0,0),(289,'penerimaanjtt',289,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa ADITIYA FREDDY WINATA (20.3423)','Rika Erliani Harahap S. Hum','2020000021',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:30:40',0,0),(290,'penerimaanjtt',290,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AFIQ ALFIANSYAH (20.3424)','Rika Erliani Harahap S. Hum','2020000023',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:34:43',0,0),(291,'penerimaanjtt',291,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AFWAN FAKHRI RAMADHAN (20.3426)','Rika Erliani Harahap S. Hum','2020000025',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:39:15',0,0),(292,'penerimaanjtt',292,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FAISAL (20.3428)','Rika Erliani Harahap S. Hum','2020000027',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:44:08',0,0),(293,'penerimaanjtt',293,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FAISAL (20.3427)','Rika Erliani Harahap S. Hum','2020000029',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:49:22',0,0),(294,'penerimaanjtt',294,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FAISAL HARAHAP (20.3429)','Rika Erliani Harahap S. Hum','2020000031',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 12:56:41',0,0),(295,'penerimaanjtt',295,'2021-04-03','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FARID AHYAR SIREGAR (20.3430)','Rika Erliani Harahap S. Hum','2020000033',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-03 14:11:24',0,0),(296,'penerimaanjtt',296,'2021-04-03','Pembayaran ke-1 SPP Bulanan MA siswa ANNISA DWI AMALIA (18.2155)','Rika Erliani Harahap','2020000036',1,'',5400000,0,'ALIYAH',NULL,NULL,NULL,'2021-04-03 23:04:22',0,0),(297,'penerimaanjtt',297,'2021-04-04','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD FIKRI (20.3431)','Rika Erliani Harahap S. Hum','2020000035',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-04 09:12:45',0,0),(298,'penerimaanjtt',298,'2021-04-04','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD HUSAIN SIMBOLON (20.3433)','Rika Erliani Harahap S. Hum','2020000037',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-04 09:17:10',0,0),(299,'penerimaanjtt',299,'2021-04-04','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD KOMARUDDIN (20.3435)','Rika Erliani Harahap S. Hum','2020000039',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-04 09:22:52',0,0),(300,'penerimaanjtt',300,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL KHALIQ PINEM (19.3013)','Jahratul Jannah','2020000041',2,'',2700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 07:37:40',0,0),(301,'penerimaanjtt',301,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ABDULLAH ABROR TAMBAK (19.3016)','Jahratul Jannah','2020000043',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 07:48:42',0,0),(302,'penerimaanjtt',302,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ABDULLAH AL FARUQ NST (19.3017)','Jahratul Jannah','2020000045',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 07:50:31',0,0),(303,'penerimaanjtt',303,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ACHMAD FAHRI (19.3018)','Jahratul Jannah','2020000047',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 07:52:42',0,0),(304,'penerimaanjtt',304,'2021-04-05','Pelunasan SPP Bulanan MTs siswa ADELLO (19.3019)','Jahratul Jannah','2020000049',2,'',6900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 07:56:23',0,0),(305,'penerimaanjtt',305,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AHMAD RIZKY MAULANA (20.3436)','Rika Erliani Harahap S. Hum','2020000050',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:02:41',0,0),(306,'penerimaanjtt',306,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ADITYA PRATAMA (19.3020)','Jahratul Jannah','2020000052',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:07:49',0,0),(307,'penerimaanjtt',307,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AIDIL FITRAH WAHYUDA (20.3437)','Rika Erliani Harahap S. Hum','2020000054',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:15:58',0,0),(308,'penerimaanjtt',308,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AIYDIL ROHMAN (20.3438)','Rika Erliani Harahap S. Hum','2020000057',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:21:14',0,0),(309,'penerimaanjtt',309,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AJA M. RAIS ALI S (20.3439)','Rika Erliani Harahap S. Hum','2020000059',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:28:47',0,0),(310,'penerimaanjtt',310,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AFRIYANTO (19.3022)','Jahratul Jannah','2020000061',2,'',5060000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:31:00',0,0),(311,'penerimaanjtt',311,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AL FARIDZY INDRA TANJUNG (20.3440)','Rika Erliani Harahap S. Hum','2020000063',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:32:57',0,0),(312,'penerimaanjtt',312,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALDI FADLAN (20.3441)','Rika Erliani Harahap S. Hum','2020000065',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:35:38',0,0),(313,'penerimaanjtt',313,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AFRIZUL HAFIZ (19.3023)','Jahratul Jannah','2020000067',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:36:57',0,0),(314,'penerimaanjtt',314,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALFI CAHAYA HASIBUAN (20.3442)','Rika Erliani Harahap S. Hum','2020000068',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:37:57',0,0),(315,'penerimaanjtt',315,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALI AKBAR HASIBUAN (20.3443)','Rika Erliani Harahap S. Hum','2020000070',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:40:12',0,0),(316,'penerimaanjtt',316,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALIF DZULJALALI (20.3444)','Rika Erliani Harahap S. Hum','2020000072',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:43:24',0,0),(317,'penerimaanjtt',317,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALVIN SURURI SIREGAR (20.3445)','Rika Erliani Harahap S. Hum','2020000074',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 08:46:10',0,0),(318,'penerimaanjtt',318,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANGGA PRATAMA (20.3446)','Rika Erliani Harahap S. Hum','2020000076',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:28:40',0,0),(319,'penerimaanjtt',319,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANGGA PRAYUDHA (20.3447)','Rika Erliani Harahap S. Hum','2020000078',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:30:29',0,0),(320,'penerimaanjtt',320,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARGA PATAMA PASARIBU (20.3448)','Rika Erliani Harahap S. Hum','2020000080',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:32:19',0,0),(321,'penerimaanjtt',321,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARGASYAPUTRA (20.3449)','Rika Erliani Harahap S. Hum','2020000082',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:37:34',0,0),(322,'penerimaanjtt',322,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARHABURRIZQI FADLAN (20.3450)','Rika Erliani Harahap S. Hum','2020000084',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:39:38',0,0),(323,'penerimaanjtt',323,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARIF FIRMANSYAH (20.3451)','Rika Erliani Harahap S. Hum','2020000086',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:44:17',0,0),(324,'penerimaanjtt',324,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARLIN RIZKY ALZUHAIRO HARAHAP (20.3452)','Rika Erliani Harahap S. Hum','2020000088',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:46:06',0,0),(325,'penerimaanjtt',325,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARYA ADENATA (20.3453)','Rika Erliani Harahap S. Hum','2020000090',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:48:31',0,0),(326,'penerimaanjtt',326,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARYA RANGGA (20.3454)','Rika Erliani Harahap S. Hum','2020000092',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:51:19',0,0),(327,'penerimaanjtt',327,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARYA RIZKI AFFAN DALIMUNTE (20.3455)','Rika Erliani Harahap S. Hum','2020000094',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:54:07',0,0),(328,'penerimaanjtt',328,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ASRAFI HADIN HARAHAP (20.3456)','Rika Erliani Harahap S. Hum','2020000096',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:56:22',0,0),(329,'penerimaanjtt',329,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa HARY PERWIRA HASIBUAN (20.3626)','Rika Erliani Harahap S. Hum','2020000098',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 09:58:42',0,0),(330,'penerimaanjtt',330,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa NAZARUDDIN LUBIS (20.3836)','Rika Erliani Harahap S. Hum','2020000100',2,'',4200000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 10:02:05',0,0),(331,'penerimaanjtt',331,'2021-04-05','Pembayaran ke-1 SPP Bulanan MA siswa ABDUL MANAN HSB (20.2433)','Jahratul Jannah S.Pd','2020000038',1,'',5400000,0,'ALIYAH',NULL,NULL,NULL,'2021-04-05 10:31:58',0,0),(332,'penerimaanjtt',332,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ADHELIA PUTTY FAIZZA ANDIATRI (19.3209)','Jahratul Jannah','2020000102',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 19:53:46',0,0),(333,'penerimaanjtt',333,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AIDIL AKBAR (19.3026)','Jahratul Jannah','2020000104',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 19:56:19',0,0),(334,'penerimaanjtt',334,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AJI BAHYU DERMAWAN (19.3027)','Jahratul Jannah','2020000106',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 19:58:34',0,0),(335,'penerimaanjtt',335,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALFARIZ RIZKI SIKUMBANG (19.3028)','Jahratul Jannah','2020000108',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:00:37',0,0),(336,'penerimaanjtt',336,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALI ARDIANSYAH (19.3029)','Jahratul Jannah','2020000110',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:02:38',0,0),(337,'penerimaanjtt',337,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ALIP ALFARIZI DAMANIK (19.3031)','Jahratul Jannah','2020000112',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:04:32',0,0),(338,'penerimaanjtt',338,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AMAR FAISZ (19.3033)','Jahratul Jannah','2020000115',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:12:40',0,0),(339,'penerimaanjtt',339,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AMIN AL-BANA (19.3034)','Jahratul Jannah','2020000117',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:14:36',0,0),(340,'penerimaanjtt',340,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANDI FAKHRI LUBIS (193413)','Jahratul Jannah','2020000119',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:16:38',0,0),(341,'penerimaanjtt',341,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANDI GUNAWAN (19.3036)','Jahratul Jannah','2020000121',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:36:35',0,0),(342,'penerimaanjtt',342,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ANDI SAHPUTRA (19.3037)','Jahratul Jannah','2020000123',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:38:34',0,0),(343,'penerimaanjtt',343,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARDIANSYAH PUTRA (19.3040)','Jahratul Jannah','2020000125',2,'',4090000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:48:20',0,0),(344,'penerimaanjtt',344,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARDIANSYAH SIAGIAN (19.3039)','Jahratul Jannah','2020000127',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 20:55:16',0,0),(345,'penerimaanjtt',345,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa ARIEF YORDAN FAIRUZHA (19.3041)','Jahratul Jannah','2020000129',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:02:41',0,0),(346,'penerimaanjtt',346,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AWI FEBRIAN (19.3043)','Jahratul Jannah','2020000132',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:06:40',0,0),(347,'penerimaanjtt',347,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AZHAR RITONGA (19.3044)','Jahratul Jannah','2020000134',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:11:25',0,0),(348,'penerimaanjtt',348,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AZMI HALIM HASIBUAN (19.3045)','Jahratul Jannah','2020000136',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:16:09',0,0),(349,'penerimaanjtt',349,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AZMY HILAL WALVYD (19.3046)','Jahratul Jannah','2020000138',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:18:50',0,0),(350,'penerimaanjtt',350,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa FAUZAN DARMAWANSYAH PULUNGAN (19.3078)','Jahratul Jannah','2020000140',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:23:09',0,0),(351,'penerimaanjtt',351,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa MUHAMMAD HAFIZH (20.3841)','Jahratul Jannah','2020000142',2,'',1200000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:26:20',0,0),(352,'penerimaanjtt',352,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AGIL PUTRI AGUSTIN (19.3210)','Jahratul Jannah','2020000144',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:34:13',0,0),(353,'penerimaanjtt',353,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AILA ADHANI SAMPURNA HSB (19.3211)','Jahratul Jannah','2020000146',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:36:38',0,0),(354,'penerimaanjtt',354,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AINAYA AZZAHRA MALINI HASIBUAN (19.3212)','Jahratul Jannah','2020000148',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:41:17',0,0),(355,'penerimaanjtt',355,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AINI (19.3213)','Jahratul Jannah','2020000150',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 21:50:39',0,0),(356,'penerimaanjtt',356,'2021-04-05','Pembayaran ke-1 SPP Bulanan MTs siswa AINI AQILA SIREGAR (19.3214)','Jahratul Jannah','2020000152',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 22:00:03',0,0),(357,'penerimaanjtt',357,'2021-04-05','Pelunasan SPP Bulanan MTs siswa AISYAH MAULIDA HARAHAP (19.3215)','Jahratul Jannah','2020000154',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-05 22:04:37',0,0),(358,'penerimaanjtt',358,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa ABDUL KHOLIK JAILANI HARAHAP (20.3416)','Rika Erliani Harahap S. Hum','2020000156',2,'',3600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 09:41:12',0,0),(359,'penerimaanjtt',359,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa ATTHA RICK ALFA REZA (20.3457)','Rika Erliani Harahap S. Hum','2020000158',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 09:49:50',0,0),(360,'penerimaanjtt',360,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa AULIA IKHSAN MUNTHE (20.3458)','Rika Erliani Harahap S. Hum','2020000160',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 10:39:19',0,0),(361,'penerimaanjtt',361,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa AWALUDDIN PASARIBU (20.3459)','Rika Erliani Harahap S. Hum','2020000162',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 10:41:17',0,0),(362,'penerimaanjtt',362,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa AZI SURYA ANGGORO (20.3460)','Rika Erliani Harahap S. Hum','2020000164',2,'',5400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 10:47:06',0,0),(363,'penerimaanjtt',363,'2021-04-06','Pelunasan SPP Bulanan MTs siswa AZMI RIVALDI ALHAVIZ (20.3461)','Rika Erliani Harahap S. Hum','2020000166',2,'',7200000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 10:50:29',0,0),(364,'penerimaanjtt',364,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa BAGUS SATRIA PRATAMA (20.3462)','Rika Erliani Harahap S. Hum','2020000168',2,'',4650000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 11:10:15',0,0),(365,'penerimaanjtt',365,'2021-04-06','Pembayaran ke-1 SPP Bulanan MTs siswa BAYU ALDIANSYAH (20.3463)','Rika Erliani Harahap S. Hum','2020000170',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-06 11:14:45',0,0),(366,'penerimaanjtt',366,'2021-04-07','Pembayaran ke-1 SPP Bulanan MTs siswa ALVIN RAMADONI NASUTION (19.3032)','Jahratul Jannah','2020000171',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:22:07',0,0),(367,'penerimaanjtt',367,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ABDUL GHANI AMENDA (19.3012)','Jahratul Jannah','2020000172',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:23:46',0,0),(368,'penerimaanjtt',368,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ABDULLAH AL FARUQ NST (19.3017)','Jahratul Jannah','2020000173',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:24:48',0,0),(369,'penerimaanjtt',369,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AFRIZUL HAFIZ (19.3023)','Jahratul Jannah','2020000174',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:27:18',0,0),(370,'penerimaanjtt',370,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AJI BAHYU DERMAWAN (19.3027)','Jahratul Jannah','2020000175',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:29:03',0,0),(371,'penerimaanjtt',371,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ARDIANSYAH SIAGIAN (19.3039)','Jahratul Jannah','2020000176',2,'',1000000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:30:44',0,0),(372,'penerimaanjtt',372,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ARDIANSYAH PUTRA (19.3040)','Jahratul Jannah','2020000177',2,'',550000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:33:09',0,0),(373,'penerimaanjtt',373,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ARIEF YORDAN FAIRUZHA (19.3041)','Jahratul Jannah','2020000178',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:34:11',0,0),(374,'penerimaanjtt',374,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa ANDI FAKHRI LUBIS (193413)','Jahratul Jannah','2020000179',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:35:24',0,0),(375,'penerimaanjtt',375,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AINAYA AZZAHRA MALINI HASIBUAN (19.3212)','Jahratul Jannah','2020000180',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:37:44',0,0),(376,'penerimaanjtt',376,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AINI (19.3213)','Jahratul Jannah','2020000181',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:39:01',0,0),(377,'penerimaanjtt',377,'2021-04-07','Pembayaran ke-2 SPP Bulanan MTs siswa AINI AQILA SIREGAR (19.3214)','Jahratul Jannah','2020000182',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:39:44',0,0),(378,'penerimaanjtt',378,'2021-04-07','Pembayaran ke-1 SPP Bulanan MTs siswa DELLA FAHRIKA ADHA (19.3247)','Jahratul Jannah','2020000184',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:43:04',0,0),(379,'penerimaanjtt',379,'2021-04-07','Pembayaran ke-1 SPP Bulanan MTs siswa DELIA PARAMITA (19.3246)','Jahratul Jannah','2020000186',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-07 15:46:08',0,0),(380,'penerimaanjtt',380,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AL ZANNAH NAYLA PUTRI (19.3216)','Jahratul Jannah','2020000188',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:10:10',0,0),(381,'penerimaanjtt',381,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ALYA KIRANI SIREGAR (19.3217)','Jahratul Jannah','2020000190',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:14:17',0,0),(382,'penerimaanjtt',382,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ALYA SYAHPUTRI HASIBUAN (19.3218)','Jahratul Jannah','2020000192',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:16:13',0,0),(383,'penerimaanjtt',383,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AMELIA AYATIKA (19.3219)','Jahratul Jannah','2020000194',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:18:26',0,0),(384,'penerimaanjtt',384,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANDIENY FITRIA KIRANY (19.3220)','Jahratul Jannah','2020000196',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:20:15',0,0),(385,'penerimaanjtt',385,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANISA SUCI ARTIKA (19.3221)','Jahratul Jannah','2020000198',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:21:58',0,0),(386,'penerimaanjtt',386,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANNISA KHUMAIROH (19.3223)','Jahratul Jannah','2020000200',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:23:26',0,0),(387,'penerimaanjtt',387,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANNISA SHAFIRA (19.3224)','Jahratul Jannah','2020000202',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:25:12',0,0),(388,'penerimaanjtt',388,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ANNISA THOYYIBA HARAHAP (19.3225)','Jahratul Jannah','2020000204',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:26:28',0,0),(389,'penerimaanjtt',389,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa APRIANI AULIA RAHMI (19.3226)','Jahratul Jannah','2020000206',2,'',4600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:32:07',0,0),(390,'penerimaanjtt',390,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ARDWI YANTI (19.3228)','Jahratul Jannah','2020000208',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:34:08',0,0),(391,'penerimaanjtt',391,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ARUM MITA SALSABILA (19.3229)','Jahratul Jannah','2020000210',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:35:38',0,0),(392,'penerimaanjtt',392,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AS-SALWAH (19.3230)','Jahratul Jannah','2020000212',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:37:25',0,0),(393,'penerimaanjtt',393,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ATHAYA ZABRINA (19.3231)','Jahratul Jannah','2020000214',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:41:41',0,0),(394,'penerimaanjtt',394,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ATHAYA ZHARIFAH (19.3232)','Jahratul Jannah','2020000216',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:44:25',0,0),(395,'penerimaanjtt',395,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ATIKAH SYAHPUTRY HENKI (19.3233)','Jahratul Jannah','2020000218',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:45:38',0,0),(396,'penerimaanjtt',396,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AULIA AZZAHRA (19.3235)','Jahratul Jannah','2020000220',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:47:08',0,0),(397,'penerimaanjtt',397,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZKIA SAKINAH (19.3237)','Jahratul Jannah','2020000222',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:47:52',0,0),(398,'penerimaanjtt',398,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZRA SASKIA LAISYALIN PANE (19.3236)','Jahratul Jannah','2020000224',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:49:14',0,0),(399,'penerimaanjtt',399,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZZUHRO AZRA IRHAMI (19.3238)','Jahratul Jannah','2020000226',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:50:41',0,0),(400,'penerimaanjtt',400,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CERYAN PUTRI MOIZHA (19.3239)','Jahratul Jannah','2020000228',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:52:06',0,0),(401,'penerimaanjtt',401,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHICHI AULIA IRAWAN (19.3240)','Jahratul Jannah','2020000230',2,'',2700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:54:12',0,0),(402,'penerimaanjtt',402,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHIKA ALFIRA RYADI (19.3241)','Jahratul Jannah','2020000232',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:56:08',0,0),(403,'penerimaanjtt',403,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHIKA MEI ROZA (19.3242)','Jahratul Jannah','2020000234',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:57:27',0,0),(404,'penerimaanjtt',404,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CHINDY FRIKA OKTAPIA (19.3243)','Jahratul Jannah','2020000236',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 13:59:28',0,0),(405,'penerimaanjtt',405,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa CITRA DEWI LESTARI (19.3244)','Jahratul Jannah','2020000238',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 14:00:58',0,0),(406,'penerimaanjtt',406,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa DEBY TASYA (19.3245)','Jahratul Jannah','2020000240',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 14:02:37',0,0),(407,'penerimaanjtt',407,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZRIL BURHAN KURNIADI (19.3049)','Jahratul Jannah','2020000242',2,'',4640000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:21:09',0,0),(408,'penerimaanjtt',408,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa AZRIL DWI SAPUTRA (19.3050)','Jahratul Jannah','2020000244',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:23:42',0,0),(409,'penerimaanjtt',409,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BANGUN GEMILANG SUDIRYO (19.3051)','Jahratul Jannah','2020000246',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:25:08',0,0),(410,'penerimaanjtt',410,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BAYU ARIA FATTAH (19.3052)','Jahratul Jannah','2020000248',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:27:09',0,0),(411,'penerimaanjtt',411,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BILLAL AL HABSHI SIAGIAN (19.3053)','Jahratul Jannah','2020000250',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:28:51',0,0),(412,'penerimaanjtt',412,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BILLI RAHMADI (19.3054)','Jahratul Jannah','2020000252',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:30:37',0,0),(413,'penerimaanjtt',413,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BIMA RAY ANGGARA (19.3055)','Jahratul Jannah','2020000254',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:32:10',0,0),(414,'penerimaanjtt',414,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa BREMA KHAIRIL ALFI SYAHRI (19.3056)','Jahratul Jannah','2020000256',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:35:54',0,0),(415,'penerimaanjtt',415,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa ZESSYCA VANEZA (19.3401)','Jahratul Jannah','2020000258',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:38:42',0,0),(416,'penerimaanjtt',416,'2021-04-15','Pembayaran ke-1 SPP Bulanan MTs siswa REGINA CAHYANING ADINDA PANGESTI (20.3842)','Jahratul Jannah','2020000260',2,'',2400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-15 20:53:29',0,0),(417,'penerimaanjtt',417,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DAHLAN HARAHAP (19.3058)','Jahratul Jannah','2020000262',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:09:06',0,0),(418,'penerimaanjtt',418,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DEDY FIRMANSYAH PUTRA (19.3060)','Jahratul Jannah','2020000264',2,'',4660000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:13:14',0,0),(419,'penerimaanjtt',419,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DENY IRWANSYAH (19.3061)','Jahratul Jannah','2020000266',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:14:57',0,0),(420,'penerimaanjtt',420,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DESTA SYAPUTRA MALAU (19.3062)','Jahratul Jannah','2020000268',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:16:28',0,0),(421,'penerimaanjtt',421,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DICKY PRANATA (19.3063)','Jahratul Jannah','2020000270',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:20:16',0,0),(422,'penerimaanjtt',422,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIMAS NAJMI ALHABSYI (19.3064)','Jahratul Jannah','2020000272',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:22:51',0,0),(423,'penerimaanjtt',423,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIMASTHYA (19.3065)','Jahratul Jannah','2020000274',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:25:14',0,0),(424,'penerimaanjtt',424,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIMAZ ABDILLAH SHAUQI (19.3066)','Jahratul Jannah','2020000276',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:32:21',0,0),(425,'penerimaanjtt',425,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DIRLAN REVIANSYAH SITOMPUL (19.3067)','Jahratul Jannah','2020000278',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 19:33:51',0,0),(426,'penerimaanjtt',426,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa DWI AL FATH AZZAKI (19.3068)','Jahratul Jannah','2020000280',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:04:23',0,0),(427,'penerimaanjtt',427,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa ERI RAMADONI MANURUNG (19.3071)','Jahratul Jannah','2020000282',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:06:30',0,0),(428,'penerimaanjtt',428,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAJAR RIZKY AKBAR (19.3072)','Jahratul Jannah','2020000284',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:10:15',0,0),(429,'penerimaanjtt',429,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FARHAN AINAL PUTRA (19.3073)','Jahratul Jannah','2020000286',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:11:35',0,0),(430,'penerimaanjtt',430,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FARHAN FUADI LAOLI (19.3074)','Jahratul Jannah','2020000288',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:12:58',0,0),(431,'penerimaanjtt',431,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FARID IZWARY (19.3075)','Jahratul Jannah','2020000290',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:17:54',0,0),(432,'penerimaanjtt',432,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FATIH AL BAHRI (19.3077)','Jahratul Jannah','2020000292',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:20:36',0,0),(433,'penerimaanjtt',433,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAUZI AHMAD HARAHAP (19.3079)','Jahratul Jannah','2020000294',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:22:19',0,0),(434,'penerimaanjtt',434,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAZA ALFARISI HARAHAP (19.3080)','Jahratul Jannah','2020000296',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:25:26',0,0),(435,'penerimaanjtt',435,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FAZRUL RINGGO RITONGA (19.3081)','Jahratul Jannah','2020000298',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:29:13',0,0),(436,'penerimaanjtt',436,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FERDIANSYAH (19.3082)','Jahratul Jannah','2020000300',2,'',920000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:31:56',0,0),(437,'penerimaanjtt',437,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FIKRIE ANSYAH FAHRIZA RITONGA (19.3083)','Jahratul Jannah','2020000302',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:33:50',0,0),(438,'penerimaanjtt',438,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa FRIMA DANI (19.3084)','Jahratul Jannah','2020000304',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:35:56',0,0),(439,'penerimaanjtt',439,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa GALANG FEBRIANSYAH (19.3085)','Jahratul Jannah','2020000306',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:37:52',0,0),(440,'penerimaanjtt',440,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa GALU INDRA PRIMAYUDA (19.3086)','Jahratul Jannah','2020000308',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:39:16',0,0),(441,'penerimaanjtt',441,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa GHOFAR ISMAIL (19.3087)','Jahratul Jannah','2020000310',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:41:09',0,0),(442,'penerimaanjtt',442,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa RASYA ARDANA UTAMA (19.3168)','Jahratul Jannah','2020000312',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:43:22',0,0),(443,'penerimaanjtt',443,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa IRHAM MAULANA RITONGA (19.3102)','Jahratul Jannah','2020000314',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:44:47',0,0),(444,'penerimaanjtt',444,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa ZULPAN EFENDI HARAHAP (20.3840)','Jahratul Jannah','2020000316',2,'',3000000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:47:19',0,0),(445,'penerimaanjtt',445,'2021-04-16','Pembayaran ke-1 SPP Bulanan MTs siswa ABID AL-BANJARI (18.2709)','Jahratul Jannah','2020000318',2,'',2100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-16 21:49:14',0,0),(446,'penerimaanjtt',446,'2021-04-17','Pelunasan SPP Bulanan MTs siswa DESI RAHMAWATI (19.3248)','Jahratul Jannah','2020000320',2,'',6900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-17 18:42:26',0,0),(447,'penerimaanjtt',447,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DEVINA ALFANI (19.3249)','Jahratul Jannah','2020000322',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-17 18:43:43',0,0),(448,'penerimaanjtt',448,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DHEA RAMA FITRIANI (19.3250)','Jahratul Jannah','2020000324',2,'',3560000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-17 19:47:08',0,0),(449,'penerimaanjtt',449,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DINA LESTARI HARAHAP (19.3251)','Jahratul Jannah','2020000326',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-17 19:53:05',0,0),(450,'penerimaanjtt',450,'2021-04-17','Pembayaran ke-1 SPP Bulanan MTs siswa DINDA AYU ALANDIN (19.3253)','Jahratul Jannah','2020000328',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-17 20:41:03',0,0),(451,'penerimaanjtt',451,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DINDA NURUL HIZZA PANE (19.3254)','Jahratul Jannah','2020000330',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:25:21',0,0),(452,'penerimaanjtt',452,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DINI AUDIRA NASUTION (19.3255)','Jahratul Jannah','2020000332',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:26:01',0,0),(453,'penerimaanjtt',453,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DIVA ILYASHA (19.3256)','Jahratul Jannah','2020000334',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:28:16',0,0),(454,'penerimaanjtt',454,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DIVA JAGAD INDRALOKA (19.3257)','Jahratul Jannah','2020000336',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:33:29',0,0),(455,'penerimaanjtt',455,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DONA AGNESIA (19.3258)','Jahratul Jannah','2020000338',2,'',3280000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:38:04',0,0),(456,'penerimaanjtt',456,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DWI ASRI RAMADHANI WIDODO (19.3259)','Jahratul Jannah','2020000340',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:40:22',0,0),(457,'penerimaanjtt',457,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa DYAH USWATUN HASANAH (19.3260)','Jahratul Jannah','2020000342',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:42:06',0,0),(458,'penerimaanjtt',458,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa EKA SARY HUTABARAT (19.3415)','Jahratul Jannah','2020000344',2,'',2100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:48:01',0,0),(459,'penerimaanjtt',459,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa ELISA JULIYANTI (19.3261)','Jahratul Jannah','2020000346',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 09:50:27',0,0),(460,'penerimaanjtt',460,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa ESYA TRIAHANI HASIBUAN (19.3262)','Jahratul Jannah','2020000348',2,'',2100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:17:51',0,0),(461,'penerimaanjtt',461,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FADHILAH ANA YUSUF (19.3264)','Jahratul Jannah','2020000350',2,'',3300000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:19:34',0,0),(462,'penerimaanjtt',462,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FASHA SYAVIRA (19.3266)','Jahratul Jannah','2020000352',2,'',1600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:21:32',0,0),(463,'penerimaanjtt',463,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FATHAN ULFAH (19.3267)','Jahratul Jannah','2020000354',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:23:18',0,0),(464,'penerimaanjtt',464,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa PATIMAH INDIRA PUTRI (19.3268)','Jahratul Jannah','2020000356',2,'',4800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:26:15',0,0),(465,'penerimaanjtt',465,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FAZHIRA NASYWA RAMZY (19.3269)','Jahratul Jannah','2020000358',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:28:55',0,0),(466,'penerimaanjtt',466,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FEBRIYANI SAFITRI (19.3270)','Jahratul Jannah','2020000360',2,'',1800000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:31:07',0,0),(467,'penerimaanjtt',467,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FITRIA ZAHRO HASIBUAN (19.3271)','Jahratul Jannah','2020000362',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:38:29',0,0),(468,'penerimaanjtt',468,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa FITRIANA SIREGAR (19.3272)','Jahratul Jannah','2020000364',2,'',4620000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:40:55',0,0),(469,'penerimaanjtt',469,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa GHEFIRA KHOLILY (19.3273)','Jahratul Jannah','2020000366',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:42:52',0,0),(470,'penerimaanjtt',470,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HENI NOVIA SILALAHI (19.3274)','Jahratul Jannah','2020000368',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:51:11',0,0),(471,'penerimaanjtt',471,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HENISYA NAZWA NST (19.3275)','Jahratul Jannah','2020000370',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:52:59',0,0),(472,'penerimaanjtt',472,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HENNY FITRI HASANAH (19.3276)','Jahratul Jannah','2020000372',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 10:54:22',0,0),(473,'penerimaanjtt',473,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa INDHY FEBRIYANTI ARYUNDA SUKMA (19.3278)','Jahratul Jannah','2020000374',2,'',5700000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:16:58',0,0),(474,'penerimaanjtt',474,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa INTAN FITRIANI (19.3279)','Jahratul Jannah','2020000376',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:18:37',0,0),(475,'penerimaanjtt',475,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa ISMA DUIYANI (19.3280)','Jahratul Jannah','2020000378',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:19:52',0,0),(476,'penerimaanjtt',476,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa JANNATUL SAKDIAH HASIBUAN (19.3281)','Jahratul Jannah','2020000380',2,'',4660000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:22:22',0,0),(477,'penerimaanjtt',477,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KADHZIYAH ALFIRANI SYAHPUTRI (19.3282)','Jahratul Jannah','2020000382',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:23:54',0,0),(478,'penerimaanjtt',478,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KARINDA EKA APRILA (19.3283)','Jahratul Jannah','2020000384',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:25:21',0,0),(479,'penerimaanjtt',479,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KAYLA JOEYA ARTIFA (19.3284)','Jahratul Jannah','2020000386',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:27:08',0,0),(480,'penerimaanjtt',480,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KESYA ANDIRA BR DAMANIK (19.3285)','Jahratul Jannah','2020000388',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:28:47',0,0),(481,'penerimaanjtt',481,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa KESYA AURA NADINE (19.3286)','Jahratul Jannah','2020000390',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:30:56',0,0),(482,'penerimaanjtt',482,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa AZRA TIFFATUL PARAPAT (19.3048)','Jahratul Jannah','2020000392',2,'',3900000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:33:23',0,0),(483,'penerimaanjtt',483,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HABIB ALBAR NASUTION (19.3088)','Jahratul Jannah','2020000394',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:34:37',0,0),(484,'penerimaanjtt',484,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HABIB AZHARI (19.3089)','Jahratul Jannah','2020000396',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:35:37',0,0),(485,'penerimaanjtt',485,'2021-04-18','Pembayaran ke-1 SPP Bulanan MTs siswa HABIBI ILHAM (19.3090)','Jahratul Jannah','2020000398',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-18 11:37:11',0,0),(486,'penerimaanjtt',486,'2021-04-19','Pembayaran ke-2 SPP Bulanan MTs siswa ADITYA PRATAMA (19.3020)','Jahratul Jannah','2020000399',2,'',1200000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-19 09:22:50',0,0),(487,'penerimaanjtt',487,'2021-04-19','Pembayaran ke-2 SPP Bulanan MTs siswa ALI ARDIANSYAH (19.3029)','Jahratul Jannah','2020000400',2,'',600000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-19 09:23:47',0,0),(488,'penerimaanjtt',488,'2021-04-19','Pembayaran ke-2 SPP Bulanan MTs siswa AMAR FAISZ (19.3033)','Jahratul Jannah','2020000401',2,'',2400000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-19 09:24:28',0,0),(489,'penerimaanjtt',489,'2021-04-19','Pembayaran ke-1 SPP Bulanan MTs siswa HABIBI MAULANA (19.3091)','Jahratul Jannah','2020000403',2,'',5100000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-19 11:22:18',0,0),(490,'penerimaanjtt',490,'2021-04-19','Pembayaran ke-1 SPP Bulanan MTs siswa HANIF ALFATA (19.3092)','Jahratul Jannah','2020000405',2,'',4500000,0,'TSANAWIYAH',NULL,NULL,NULL,'2021-04-19 11:24:14',0,0),(491,'penerimaanjtt',491,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa NURFARAHIM (19.2368)','Jahratul Jannah S.Pd','2020000040',1,'',6600000,0,'ALIYAH',NULL,NULL,NULL,'2021-07-12 20:52:50',0,0),(492,'penerimaanjtt',492,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa RIZAL SYAHDANI SIREGAR (20.2531)','Jahratul Jannah S.Pd','2020000042',1,'',6600000,0,'ALIYAH',NULL,NULL,NULL,'2021-07-12 20:57:09',0,0),(493,'penerimaanjtt',493,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa CINDY BUDI MALIHAH (19.2394)','Jahratul Jannah S.Pd','2020000044',1,'',6600000,0,'ALIYAH',NULL,NULL,NULL,'2021-07-12 21:33:59',0,0),(494,'penerimaanjtt',494,'2021-07-12','Pembayaran ke-1 SPP Bulanan MA siswa RIO ARDANA HARAHAP (20.2493)','Jahratul Jannah S.Pd','2020000046',1,'',6600000,0,'ALIYAH',NULL,NULL,NULL,'2021-07-12 21:35:08',0,0),(495,'penerimaanjtt',495,'2021-07-12','Pelunasan SPP Bulanan MA siswa MUHAMMAD RASYID RIDHO (20.2484)','Jahratul Jannah S.Pd','2020000048',1,'',7200000,0,'ALIYAH',NULL,NULL,NULL,'2021-07-12 21:37:25',0,0);

#
# Structure for table "transgen"
#

DROP TABLE IF EXISTS `jbsfina`.`transgen`;
CREATE TABLE `jbsfina`.`transgen` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transactionid` varchar(20) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `IX_transgen` (`transactionid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "transgen"
#


#
# Structure for table "userpos"
#

DROP TABLE IF EXISTS `jbsfina`.`userpos`;
CREATE TABLE `jbsfina`.`userpos` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `passlength` tinyint(3) unsigned NOT NULL,
  `aktif` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `foto` mediumtext,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `UX_userpos` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "userpos"
#


#
# Structure for table "vendor"
#

DROP TABLE IF EXISTS `jbsfina`.`vendor`;
CREATE TABLE `jbsfina`.`vendor` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` varchar(5) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `terimaiuran` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `kirimpesan` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tanggal` datetime NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `UX_vendor` (`vendorid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

#
# Data for table "vendor"
#

INSERT INTO `vendor` VALUES (1,'KASIR','KASIR SEKOLAH',1,1,1,'2020-10-27 10:06:03',''),(2,'KOPSI','KOPERASI SEKOLAH',1,0,1,'2020-10-27 10:06:20',''),(3,'KANTN','KANTIN SEKOLAH',1,0,0,'2020-10-27 10:06:29','');

#
# Structure for table "userposlog"
#

DROP TABLE IF EXISTS `jbsfina`.`userposlog`;
CREATE TABLE `jbsfina`.`userposlog` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` varchar(5) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `logtime` datetime NOT NULL,
  `sessionid` varchar(15) NOT NULL,
  `localip` varchar(15) NOT NULL,
  `device` varchar(255) NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_userposlog_vendor` (`vendorid`),
  KEY `FK_userposlog_userpos` (`userid`),
  CONSTRAINT `FK_userposlog_userpos` FOREIGN KEY (`userid`) REFERENCES `jbsfina`.`userpos` (`userid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_userposlog_vendor` FOREIGN KEY (`vendorid`) REFERENCES `jbsfina`.`vendor` (`vendorid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "userposlog"
#


#
# Structure for table "refund"
#

DROP TABLE IF EXISTS `jbsfina`.`refund`;
CREATE TABLE `jbsfina`.`refund` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idtahunbuku` int(10) unsigned NOT NULL,
  `vendorid` varchar(5) NOT NULL,
  `waktu` datetime NOT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `idpenerima` varchar(50) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `idjurnalsiswa` int(10) unsigned NOT NULL DEFAULT '0',
  `idjurnalpegawai` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`replid`),
  KEY `FK_refund_tahunbuku` (`idtahunbuku`),
  KEY `FK_refund_vendor` (`vendorid`),
  KEY `FK_refund_pegawai` (`nip`),
  KEY `FK_refund_userpos` (`idpenerima`),
  CONSTRAINT `FK_refund_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_refund_tahunbuku` FOREIGN KEY (`idtahunbuku`) REFERENCES `jbsfina`.`tahunbuku` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_refund_userpos` FOREIGN KEY (`idpenerima`) REFERENCES `jbsfina`.`userpos` (`userid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_refund_vendor` FOREIGN KEY (`vendorid`) REFERENCES `jbsfina`.`vendor` (`vendorid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "refund"
#


#
# Structure for table "refunddate"
#

DROP TABLE IF EXISTS `jbsfina`.`refunddate`;
CREATE TABLE `jbsfina`.`refunddate` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idrefund` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_refunddate_refund` (`idrefund`),
  CONSTRAINT `FK_refunddate_refund` FOREIGN KEY (`idrefund`) REFERENCES `jbsfina`.`refund` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "refunddate"
#


#
# Structure for table "paymenttrans"
#

DROP TABLE IF EXISTS `jbsfina`.`paymenttrans`;
CREATE TABLE `jbsfina`.`paymenttrans` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sessionid` varchar(20) NOT NULL,
  `transactionid` varchar(20) NOT NULL,
  `transactionno` int(10) unsigned NOT NULL DEFAULT '0',
  `waktu` datetime NOT NULL,
  `tanggal` date NOT NULL,
  `vendorid` varchar(5) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `jenis` tinyint(3) unsigned NOT NULL COMMENT '1 Pegawai, 2 Siswa',
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `jumlah` decimal(15,0) NOT NULL,
  `valmethod` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 PIN, 2 Check',
  `keterangan` varchar(255) NOT NULL,
  `idjurnaltabcust` int(10) unsigned NOT NULL,
  `idjurnalvendor` int(10) unsigned NOT NULL,
  `jenistrans` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 Vendor, 1 Iuran Wajib, 2 Iuran Sukarela',
  `idpenerimaanjtt` int(10) unsigned DEFAULT NULL,
  `idpenerimaaniuran` int(10) unsigned DEFAULT NULL,
  `iddatapenerimaan` int(10) unsigned DEFAULT NULL,
  `idrefund` int(10) unsigned DEFAULT NULL,
  `idtabungan` int(10) unsigned DEFAULT NULL,
  `idtabunganp` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`replid`),
  UNIQUE KEY `UX_paymenttrans` (`transactionid`,`transactionno`) USING BTREE,
  KEY `FK_paymenttrans_siswa` (`nis`),
  KEY `FK_paymenttrans_pegawai` (`nip`),
  KEY `FK_paymenttrans_jurnaltabcust` (`idjurnaltabcust`),
  KEY `FK_paymenttrans_jurnalvendor` (`idjurnalvendor`),
  KEY `FK_paymenttrans_penerimaanjtt` (`idpenerimaanjtt`),
  KEY `FK_paymenttrans_penerimaaniuran` (`idpenerimaaniuran`),
  KEY `FK_paymenttrans_datapenerimaan` (`iddatapenerimaan`),
  KEY `FK_paymenttrans_vendor` (`vendorid`),
  KEY `FK_paymenttrans_refund` (`idrefund`),
  KEY `FK_paymenttrans_tabungan` (`idtabungan`),
  KEY `FK_paymenttrans_tabunganp` (`idtabunganp`),
  KEY `IX_paymenttrans` (`userid`,`waktu`,`tanggal`,`jenis`,`jenistrans`) USING BTREE,
  CONSTRAINT `FK_paymenttrans_datapenerimaan` FOREIGN KEY (`iddatapenerimaan`) REFERENCES `jbsfina`.`datapenerimaan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_jurnaltabcust` FOREIGN KEY (`idjurnaltabcust`) REFERENCES `jbsfina`.`jurnal` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_jurnalvendor` FOREIGN KEY (`idjurnalvendor`) REFERENCES `jbsfina`.`jurnal` (`replid`),
  CONSTRAINT `FK_paymenttrans_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_penerimaaniuran` FOREIGN KEY (`idpenerimaaniuran`) REFERENCES `jbsfina`.`penerimaaniuran` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_penerimaanjtt` FOREIGN KEY (`idpenerimaanjtt`) REFERENCES `jbsfina`.`penerimaanjtt` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_refund` FOREIGN KEY (`idrefund`) REFERENCES `jbsfina`.`refund` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_tabungan` FOREIGN KEY (`idtabungan`) REFERENCES `jbsfina`.`tabungan` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_tabunganp` FOREIGN KEY (`idtabunganp`) REFERENCES `jbsfina`.`tabunganp` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_userpos` FOREIGN KEY (`userid`) REFERENCES `jbsfina`.`userpos` (`userid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_paymenttrans_vendor` FOREIGN KEY (`vendorid`) REFERENCES `jbsfina`.`vendor` (`vendorid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "paymenttrans"
#


#
# Structure for table "vendoruser"
#

DROP TABLE IF EXISTS `jbsfina`.`vendoruser`;
CREATE TABLE `jbsfina`.`vendoruser` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vendorid` varchar(5) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `tingkat` tinyint(3) unsigned NOT NULL COMMENT '1 Manager, 2 User',
  PRIMARY KEY (`replid`),
  KEY `FK_vendoruser_vendor` (`vendorid`),
  KEY `FK_vendoruser_userpos` (`userid`),
  CONSTRAINT `FK_vendoruser_userpos` FOREIGN KEY (`userid`) REFERENCES `jbsfina`.`userpos` (`userid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_vendoruser_vendor` FOREIGN KEY (`vendorid`) REFERENCES `jbsfina`.`vendor` (`vendorid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "vendoruser"
#


#
# Trigger "fsync_trdel_20_barang"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_barang`;
jbsfina

#
# Trigger "fsync_trdel_20_besarjtt"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_besarjtt`;
jbsfina

#
# Trigger "fsync_trdel_20_besarjttcalon"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_besarjttcalon`;
jbsfina

#
# Trigger "fsync_trdel_20_datapenerimaan"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_datapenerimaan`;
jbsfina

#
# Trigger "fsync_trdel_20_groupbarang"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_groupbarang`;
jbsfina

#
# Trigger "fsync_trdel_20_kategoripenerimaan"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_kategoripenerimaan`;
jbsfina

#
# Trigger "fsync_trdel_20_kelompokbarang"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_kelompokbarang`;
jbsfina

#
# Trigger "fsync_trdel_20_penerimaaniuran"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_penerimaaniuran`;
jbsfina

#
# Trigger "fsync_trdel_20_penerimaaniurancalon"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_penerimaaniurancalon`;
jbsfina

#
# Trigger "fsync_trdel_20_penerimaanjtt"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_penerimaanjtt`;
jbsfina

#
# Trigger "fsync_trdel_20_penerimaanjttcalon"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_penerimaanjttcalon`;
jbsfina

#
# Trigger "fsync_trdel_20_tahunbuku"
#

DROP TRIGGER IF EXISTS `fsync_trdel_20_tahunbuku`;
jbsfina

#
# Trigger "fsync_trins_20_barang"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_barang`;
jbsfina

#
# Trigger "fsync_trins_20_besarjtt"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_besarjtt`;
jbsfina

#
# Trigger "fsync_trins_20_besarjttcalon"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_besarjttcalon`;
jbsfina

#
# Trigger "fsync_trins_20_datapenerimaan"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_datapenerimaan`;
jbsfina

#
# Trigger "fsync_trins_20_groupbarang"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_groupbarang`;
jbsfina

#
# Trigger "fsync_trins_20_kategoripenerimaan"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_kategoripenerimaan`;
jbsfina

#
# Trigger "fsync_trins_20_kelompokbarang"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_kelompokbarang`;
jbsfina

#
# Trigger "fsync_trins_20_penerimaaniuran"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_penerimaaniuran`;
jbsfina

#
# Trigger "fsync_trins_20_penerimaaniurancalon"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_penerimaaniurancalon`;
jbsfina

#
# Trigger "fsync_trins_20_penerimaanjtt"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_penerimaanjtt`;
jbsfina

#
# Trigger "fsync_trins_20_penerimaanjttcalon"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_penerimaanjttcalon`;
jbsfina

#
# Trigger "fsync_trins_20_tahunbuku"
#

DROP TRIGGER IF EXISTS `fsync_trins_20_tahunbuku`;
jbsfina

#
# Trigger "fsync_trupd_20_barang"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_barang`;
jbsfina

#
# Trigger "fsync_trupd_20_besarjtt"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_besarjtt`;
jbsfina

#
# Trigger "fsync_trupd_20_besarjttcalon"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_besarjttcalon`;
jbsfina

#
# Trigger "fsync_trupd_20_datapenerimaan"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_datapenerimaan`;
jbsfina

#
# Trigger "fsync_trupd_20_groupbarang"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_groupbarang`;
jbsfina

#
# Trigger "fsync_trupd_20_kategoripenerimaan"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_kategoripenerimaan`;
jbsfina

#
# Trigger "fsync_trupd_20_kelompokbarang"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_kelompokbarang`;
jbsfina

#
# Trigger "fsync_trupd_20_penerimaaniuran"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_penerimaaniuran`;
jbsfina

#
# Trigger "fsync_trupd_20_penerimaaniurancalon"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_penerimaaniurancalon`;
jbsfina

#
# Trigger "fsync_trupd_20_penerimaanjtt"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_penerimaanjtt`;
jbsfina

#
# Trigger "fsync_trupd_20_penerimaanjttcalon"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_penerimaanjttcalon`;
jbsfina

#
# Trigger "fsync_trupd_20_tahunbuku"
#

DROP TRIGGER IF EXISTS `fsync_trupd_20_tahunbuku`;
jbsfina

#
# Trigger "trins_penerimaaniuran_100"
#

DROP TRIGGER IF EXISTS `trins_penerimaaniuran_100`;
jbsfina

#
# Trigger "trins_penerimaaniurancalon_100"
#

DROP TRIGGER IF EXISTS `trins_penerimaaniurancalon_100`;
jbsfina

#
# Trigger "trins_penerimaanjtt_100"
#

DROP TRIGGER IF EXISTS `trins_penerimaanjtt_100`;
jbsfina

#
# Trigger "trins_penerimaanjttcalon_100"
#

DROP TRIGGER IF EXISTS `trins_penerimaanjttcalon_100`;
jbsfina

#
# Trigger "trins_penerimaanlain_100"
#

DROP TRIGGER IF EXISTS `trins_penerimaanlain_100`;
jbsfina

#
# Trigger "trins_pengeluaran_100"
#

DROP TRIGGER IF EXISTS `trins_pengeluaran_100`;
jbsfina

#
# Trigger "trins_tabungan_100"
#

DROP TRIGGER IF EXISTS `trins_tabungan_100`;
jbsfina

#
# Trigger "trins_tabunganp_100"
#

DROP TRIGGER IF EXISTS `trins_tabunganp_100`;
jbsfina

#
# Trigger "trupd_besarjtt_101"
#

DROP TRIGGER IF EXISTS `trupd_besarjtt_101`;
jbsfina

#
# Trigger "trupd_besarjttcalon_101"
#

DROP TRIGGER IF EXISTS `trupd_besarjttcalon_101`;
jbsfina

#
# Trigger "trupd_penerimaaniuran_101"
#

DROP TRIGGER IF EXISTS `trupd_penerimaaniuran_101`;
jbsfina

#
# Trigger "trupd_penerimaaniurancalon_101"
#

DROP TRIGGER IF EXISTS `trupd_penerimaaniurancalon_101`;
jbsfina

#
# Trigger "trupd_penerimaanjtt_102"
#

DROP TRIGGER IF EXISTS `trupd_penerimaanjtt_102`;
jbsfina

#
# Trigger "trupd_penerimaanjttcalon_102"
#

DROP TRIGGER IF EXISTS `trupd_penerimaanjttcalon_102`;
jbsfina

#
# Trigger "trupd_penerimaanlain_101"
#

DROP TRIGGER IF EXISTS `trupd_penerimaanlain_101`;
jbsfina

#
# Trigger "trupd_pengeluaran_100"
#

DROP TRIGGER IF EXISTS `trupd_pengeluaran_100`;
jbsfina

#
# Trigger "trupd_tabungan_102"
#

DROP TRIGGER IF EXISTS `trupd_tabungan_102`;
jbsfina

#
# Trigger "trupd_tabunganp_102"
#

DROP TRIGGER IF EXISTS `trupd_tabunganp_102`;
jbsfina
