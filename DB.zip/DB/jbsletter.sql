﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:49:01
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbsletter`;

#
# Structure for table "berkassurat"
#

DROP TABLE IF EXISTS `jbsletter`.`berkassurat`;
CREATE TABLE `jbsletter`.`berkassurat` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `jenis` tinyint(1) unsigned NOT NULL COMMENT '0 Gambar, 1 File',
  `berkas` longblob NOT NULL,
  `w` int(10) unsigned DEFAULT '0',
  `h` int(10) unsigned DEFAULT '0',
  `size` int(10) unsigned DEFAULT '0',
  `sumber` varchar(5) NOT NULL COMMENT 'SCAN, FILE',
  `deskripsi` varchar(255) NOT NULL,
  `petugas` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_gambarsurat_surat` (`idsurat`),
  CONSTRAINT `FK_gambarsurat_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "berkassurat"
#


#
# Structure for table "cclist"
#

DROP TABLE IF EXISTS `jbsletter`.`cclist`;
CREATE TABLE `jbsletter`.`cclist` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `jenis` varchar(3) NOT NULL COMMENT 'IN, OUT',
  `iduser` varchar(30) CHARACTER SET utf8 NOT NULL,
  `aktif` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_cclist_pegawai` (`iduser`),
  KEY `FK_cclist_departemen` (`departemen`),
  CONSTRAINT `FK_cclist_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_cclist_pegawai` FOREIGN KEY (`iduser`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "cclist"
#


#
# Structure for table "kategori"
#

DROP TABLE IF EXISTS `jbsletter`.`kategori`;
CREATE TABLE `jbsletter`.`kategori` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `jenis` varchar(3) NOT NULL COMMENT 'IN OUT',
  `kategori` varchar(100) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `keterangan` varchar(255) DEFAULT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_kategori_departemen` (`departemen`),
  CONSTRAINT `FK_kategori_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "kategori"
#


#
# Structure for table "kelompok"
#

DROP TABLE IF EXISTS `jbsletter`.`kelompok`;
CREATE TABLE `jbsletter`.`kelompok` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(100) NOT NULL,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `deskripsi` varchar(2555) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_kelompok_departemen` (`departemen`),
  CONSTRAINT `FK_kelompok_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "kelompok"
#


#
# Structure for table "anggota"
#

DROP TABLE IF EXISTS `jbsletter`.`anggota`;
CREATE TABLE `jbsletter`.`anggota` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idkelompok` int(10) unsigned NOT NULL,
  `jenis` tinyint(1) unsigned NOT NULL COMMENT '0 Siswa, 1 Pegawai, 2 Other',
  `nis` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `nouser` varchar(30) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_anggota_kelompok` (`idkelompok`),
  KEY `FK_anggota_siswa` (`nis`),
  KEY `FK_anggota_pegawai` (`nip`),
  CONSTRAINT `FK_anggota_kelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbsletter`.`kelompok` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_anggota_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "anggota"
#


#
# Structure for table "sumberin"
#

DROP TABLE IF EXISTS `jbsletter`.`sumberin`;
CREATE TABLE `jbsletter`.`sumberin` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `sumber` varchar(100) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_sumberin_departemen` (`departemen`),
  CONSTRAINT `FK_sumberin_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "sumberin"
#


#
# Structure for table "surat"
#

DROP TABLE IF EXISTS `jbsletter`.`surat`;
CREATE TABLE `jbsletter`.`surat` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `nomor` varchar(100) NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `idkategori` int(10) unsigned NOT NULL,
  `jenis` varchar(3) NOT NULL COMMENT 'IN, OUT',
  `sifat` tinyint(1) unsigned NOT NULL DEFAULT '2' COMMENT '1 Sangat Penting, 2 Penting, 3 Biasa',
  `deskripsi` varchar(2500) NOT NULL,
  `keterangan` varchar(2500) DEFAULT NULL,
  `petugas` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastactive` datetime DEFAULT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_surat_departemen` (`departemen`),
  KEY `FK_surat_pegawai` (`petugas`),
  KEY `FK_surat_kategori` (`idkategori`),
  KEY `IX_surat` (`nomor`,`perihal`,`tanggal`,`deskripsi`(767),`keterangan`(767)) USING BTREE,
  KEY `IX_surat_lastactive` (`lastactive`),
  CONSTRAINT `FK_surat_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_surat_kategori` FOREIGN KEY (`idkategori`) REFERENCES `jbsletter`.`kategori` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_surat_pegawai` FOREIGN KEY (`petugas`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "surat"
#


#
# Structure for table "comment"
#

DROP TABLE IF EXISTS `jbsletter`.`comment`;
CREATE TABLE `jbsletter`.`comment` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `nip` varchar(30) CHARACTER SET utf8 NOT NULL,
  `tanggal` datetime NOT NULL,
  `komen` varchar(500) NOT NULL,
  `fkomen` varchar(1500) NOT NULL,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_comment_surat` (`idsurat`),
  KEY `FK_comment_pegawai` (`nip`),
  CONSTRAINT `FK_comment_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_comment_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "comment"
#


#
# Structure for table "suratindstcc"
#

DROP TABLE IF EXISTS `jbsletter`.`suratindstcc`;
CREATE TABLE `jbsletter`.`suratindstcc` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `iduser` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_suratindstcc_surat` (`idsurat`),
  KEY `FK_suratindstcc_pegawai` (`iduser`),
  CONSTRAINT `FK_suratindstcc_pegawai` FOREIGN KEY (`iduser`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratindstcc_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratindstcc"
#


#
# Structure for table "suratindstgroup"
#

DROP TABLE IF EXISTS `jbsletter`.`suratindstgroup`;
CREATE TABLE `jbsletter`.`suratindstgroup` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `idkelompok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_suratindstgroup_kelompok` (`idkelompok`),
  KEY `FK_suratindstgroup_surat` (`idsurat`),
  CONSTRAINT `FK_suratindstgroup_kelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbsletter`.`kelompok` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratindstgroup_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratindstgroup"
#


#
# Structure for table "suratindstuser"
#

DROP TABLE IF EXISTS `jbsletter`.`suratindstuser`;
CREATE TABLE `jbsletter`.`suratindstuser` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `iduser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idsiswa` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `jenis` varchar(1) DEFAULT NULL COMMENT 'P,S,A',
  PRIMARY KEY (`replid`),
  KEY `FK_suratindstuser_pegawai` (`iduser`),
  KEY `FK_suratindstuser_surat` (`idsurat`),
  KEY `FK_suratindstuser_siswa` (`idsiswa`),
  CONSTRAINT `FK_suratindstuser_pegawai` FOREIGN KEY (`iduser`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratindstuser_siswa` FOREIGN KEY (`idsiswa`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratindstuser_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratindstuser"
#


#
# Structure for table "suratinsrc"
#

DROP TABLE IF EXISTS `jbsletter`.`suratinsrc`;
CREATE TABLE `jbsletter`.`suratinsrc` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `idsumber` int(10) unsigned NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_suratinsrc_sumber` (`idsumber`),
  KEY `FK_suratinsrc_surat` (`idsurat`),
  CONSTRAINT `FK_suratinsrc_sumber` FOREIGN KEY (`idsumber`) REFERENCES `jbsletter`.`sumberin` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratinsrc_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratinsrc"
#


#
# Structure for table "suratoutsrccc"
#

DROP TABLE IF EXISTS `jbsletter`.`suratoutsrccc`;
CREATE TABLE `jbsletter`.`suratoutsrccc` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `iduser` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_suratoutccuser_surat` (`idsurat`),
  KEY `FK_suratoutccuser_pegawai` (`iduser`),
  CONSTRAINT `FK_suratoutccuser_pegawai` FOREIGN KEY (`iduser`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutccuser_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratoutsrccc"
#


#
# Structure for table "suratoutsrcgroup"
#

DROP TABLE IF EXISTS `jbsletter`.`suratoutsrcgroup`;
CREATE TABLE `jbsletter`.`suratoutsrcgroup` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `idkelompok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_suratoutsrcgroup_surat` (`idsurat`),
  KEY `FK_suratoutsrcgroup_kelompok` (`idkelompok`),
  CONSTRAINT `FK_suratoutsrcgroup_kelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbsletter`.`kelompok` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutsrcgroup_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratoutsrcgroup"
#


#
# Structure for table "suratoutsrcuser"
#

DROP TABLE IF EXISTS `jbsletter`.`suratoutsrcuser`;
CREATE TABLE `jbsletter`.`suratoutsrcuser` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `iduser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idsiswa` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `jenis` varchar(1) DEFAULT NULL COMMENT 'P,S,A',
  PRIMARY KEY (`replid`),
  KEY `FK_suratoutsrcuser_pegawai` (`iduser`),
  KEY `FK_suratoutsrcuser_surat` (`idsurat`),
  KEY `FK_suratoutsrcuser_siswa` (`idsiswa`),
  CONSTRAINT `FK_suratoutsrcuser_pegawai` FOREIGN KEY (`iduser`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutsrcuser_siswa` FOREIGN KEY (`idsiswa`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutsrcuser_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratoutsrcuser"
#


#
# Structure for table "tujuanout"
#

DROP TABLE IF EXISTS `jbsletter`.`tujuanout`;
CREATE TABLE `jbsletter`.`tujuanout` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) CHARACTER SET utf8 NOT NULL,
  `tujuan` varchar(100) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `info1` varchar(45) DEFAULT NULL,
  `info2` varchar(45) DEFAULT NULL,
  `info3` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_tujuanout_departemen` (`departemen`),
  CONSTRAINT `FK_tujuanout_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "tujuanout"
#


#
# Structure for table "suratoutdst"
#

DROP TABLE IF EXISTS `jbsletter`.`suratoutdst`;
CREATE TABLE `jbsletter`.`suratoutdst` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsurat` int(10) unsigned NOT NULL,
  `idtujuan` int(10) unsigned DEFAULT NULL,
  `iduser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idsiswa` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idkelompok` int(10) unsigned DEFAULT NULL,
  `jenis` varchar(1) NOT NULL COMMENT 'T,P,S,A,G',
  PRIMARY KEY (`replid`),
  KEY `FK_suratoutdst_tujuanout` (`idtujuan`),
  KEY `FK_suratoutdst_surat` (`idsurat`),
  KEY `FK_suratoutdst_pegawai` (`iduser`),
  KEY `FK_suratoutdst_siswa` (`idsiswa`),
  KEY `FK_suratoutdst_kelompok` (`idkelompok`),
  CONSTRAINT `FK_suratoutdst_kelompok` FOREIGN KEY (`idkelompok`) REFERENCES `jbsletter`.`kelompok` (`replid`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutdst_pegawai` FOREIGN KEY (`iduser`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutdst_siswa` FOREIGN KEY (`idsiswa`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutdst_surat` FOREIGN KEY (`idsurat`) REFERENCES `jbsletter`.`surat` (`replid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_suratoutdst_tujuanout` FOREIGN KEY (`idtujuan`) REFERENCES `jbsletter`.`tujuanout` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratoutdst"
#


#
# Structure for table "user"
#

DROP TABLE IF EXISTS `jbsletter`.`user`;
CREATE TABLE `jbsletter`.`user` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(45) NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `userlevel` tinyint(1) unsigned NOT NULL COMMENT '1 -> Manager, 2 -> Client',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `lastlogin` datetime DEFAULT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_user_pegawai` (`userid`),
  CONSTRAINT `FK_user_pegawai` FOREIGN KEY (`userid`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "user"
#


#
# Structure for table "useraccess"
#

DROP TABLE IF EXISTS `jbsletter`.`useraccess`;
CREATE TABLE `jbsletter`.`useraccess` (
  `replid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iduser` int(10) unsigned NOT NULL,
  `departemen` varchar(45) NOT NULL,
  `info1` varchar(100) DEFAULT NULL,
  `info2` varchar(100) DEFAULT NULL,
  `info3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`replid`),
  KEY `FK_useraccess_fruser` (`iduser`),
  KEY `FK_useraccess_departemen` (`departemen`),
  CONSTRAINT `FK_useraccess_departemen` FOREIGN KEY (`departemen`) REFERENCES `jbsakad`.`departemen` (`departemen`) ON UPDATE CASCADE,
  CONSTRAINT `FK_useraccess_fruser` FOREIGN KEY (`iduser`) REFERENCES `jbsletter`.`user` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "useraccess"
#

