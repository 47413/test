﻿# Host: localhost:3434  (Version 5.6.47)
# Date: 2021-10-04 09:48:36
# Generator: MySQL-Front 6.0  (Build 2.20)


CREATE DATABASE IF NOT EXISTS `jbsel`;

#
# Structure for table "channel"
#

DROP TABLE IF EXISTS `jbsel`.`channel`;
CREATE TABLE `jbsel`.`channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nip` varchar(30) CHARACTER SET utf8 NOT NULL,
  `idpelajaran` int(10) unsigned NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` varchar(2000) NOT NULL,
  `tanggal` datetime NOT NULL,
  `aktif` tinyint(3) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL DEFAULT '1',
  `nfollower` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_channel_pegawai` (`nip`),
  KEY `FK_channel_pelajaran` (`idpelajaran`),
  CONSTRAINT `FK_channel_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_channel_pelajaran` FOREIGN KEY (`idpelajaran`) REFERENCES `jbsakad`.`pelajaran` (`replid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "channel"
#


#
# Structure for table "channelfollow"
#

DROP TABLE IF EXISTS `jbsel`.`channelfollow`;
CREATE TABLE `jbsel`.`channelfollow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idchannel` int(10) unsigned NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_channelfollow_siswa` (`nis`),
  KEY `FK_channelfollow_pegawai` (`nip`),
  KEY `FK_channelfollow_channel` (`idchannel`),
  CONSTRAINT `FK_channelfollow_channel` FOREIGN KEY (`idchannel`) REFERENCES `jbsel`.`channel` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_channelfollow_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_channelfollow_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "channelfollow"
#


#
# Structure for table "ftdatamedia"
#

DROP TABLE IF EXISTS `jbsel`.`ftdatamedia`;
CREATE TABLE `jbsel`.`ftdatamedia` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idmedia` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IX_ftdatamedia` (`idmedia`),
  FULLTEXT KEY `FT_media` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# Data for table "ftdatamedia"
#


#
# Structure for table "media"
#

DROP TABLE IF EXISTS `jbsel`.`media`;
CREATE TABLE `jbsel`.`media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idchannel` int(10) unsigned NOT NULL,
  `judul` varchar(255) NOT NULL,
  `urutan` int(10) unsigned NOT NULL,
  `prioritas` tinyint(3) unsigned NOT NULL,
  `idkategori` int(10) unsigned DEFAULT NULL,
  `cover` mediumtext NOT NULL,
  `videoname` varchar(255) NOT NULL,
  `ovideoname` varchar(255) NOT NULL,
  `videosize` int(10) unsigned NOT NULL,
  `videotype` varchar(10) NOT NULL,
  `videoloc` varchar(255) NOT NULL,
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deskripsi` varchar(1000) NOT NULL,
  `objektif` varchar(1000) NOT NULL,
  `pertanyaan` varchar(1000) NOT NULL,
  `katakunci` varchar(255) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `nview` int(10) unsigned NOT NULL DEFAULT '0',
  `nlike` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_media_channel` (`idchannel`),
  KEY `FK_media_cbekategori` (`idkategori`),
  CONSTRAINT `FK_media_cbekategori` FOREIGN KEY (`idkategori`) REFERENCES `jbscbe`.`kategori` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_media_channel` FOREIGN KEY (`idchannel`) REFERENCES `jbsel`.`channel` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "media"
#


#
# Structure for table "mediafile"
#

DROP TABLE IF EXISTS `jbsel`.`mediafile`;
CREATE TABLE `jbsel`.`mediafile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idmedia` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `ofilename` varchar(255) NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `filetype` varchar(50) NOT NULL,
  `fileinfo` varchar(255) NOT NULL,
  `fileloc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mediafile_media` (`idmedia`),
  CONSTRAINT `FK_mediafile_media` FOREIGN KEY (`idmedia`) REFERENCES `jbsel`.`media` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "mediafile"
#


#
# Structure for table "medialike"
#

DROP TABLE IF EXISTS `jbsel`.`medialike`;
CREATE TABLE `jbsel`.`medialike` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idmedia` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_medialike_siswa` (`nis`),
  KEY `FK_medialike_pegawai` (`nip`),
  KEY `FK_medialike_media` (`idmedia`),
  CONSTRAINT `FK_medialike_media` FOREIGN KEY (`idmedia`) REFERENCES `jbsel`.`media` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_medialike_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_medialike_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "medialike"
#


#
# Structure for table "medianotes"
#

DROP TABLE IF EXISTS `jbsel`.`medianotes`;
CREATE TABLE `jbsel`.`medianotes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idmedia` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_medianotes_siswa` (`nis`),
  KEY `FK_medianotes_pegawai` (`nip`),
  KEY `FK_medianotes_media` (`idmedia`),
  CONSTRAINT `FK_medianotes_media` FOREIGN KEY (`idmedia`) REFERENCES `jbsel`.`media` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_medianotes_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_medianotes_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "medianotes"
#


#
# Structure for table "modul"
#

DROP TABLE IF EXISTS `jbsel`.`modul`;
CREATE TABLE `jbsel`.`modul` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idchannel` int(10) unsigned NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` varchar(1000) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL,
  `nfollower` int(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_modul_channel` (`idchannel`),
  CONSTRAINT `FK_modul_channel` FOREIGN KEY (`idchannel`) REFERENCES `jbsel`.`channel` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "modul"
#


#
# Structure for table "mediamodul"
#

DROP TABLE IF EXISTS `jbsel`.`mediamodul`;
CREATE TABLE `jbsel`.`mediamodul` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idmodul` int(10) unsigned NOT NULL,
  `idmedia` int(10) unsigned NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `aktif` tinyint(1) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mediamodul_modul` (`idmodul`),
  KEY `FK_mediamodul_media` (`idmedia`),
  CONSTRAINT `FK_mediamodul_media` FOREIGN KEY (`idmedia`) REFERENCES `jbsel`.`media` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_mediamodul_modul` FOREIGN KEY (`idmodul`) REFERENCES `jbsel`.`modul` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "mediamodul"
#


#
# Structure for table "modulfollow"
#

DROP TABLE IF EXISTS `jbsel`.`modulfollow`;
CREATE TABLE `jbsel`.`modulfollow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `nip` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `idmodul` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_modulfollow_siswa` (`nis`),
  KEY `FK_modulfollow_pegawai` (`nip`),
  KEY `FK_modulfollow_modul` (`idmodul`),
  CONSTRAINT `FK_modulfollow_modul` FOREIGN KEY (`idmodul`) REFERENCES `jbsel`.`modul` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_modulfollow_pegawai` FOREIGN KEY (`nip`) REFERENCES `jbssdm`.`pegawai` (`nip`) ON UPDATE CASCADE,
  CONSTRAINT `FK_modulfollow_siswa` FOREIGN KEY (`nis`) REFERENCES `jbsakad`.`siswa` (`nis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "modulfollow"
#


#
# Structure for table "viewhistory"
#

DROP TABLE IF EXISTS `jbsel`.`viewhistory`;
CREATE TABLE `jbsel`.`viewhistory` (
  `viewdate` date NOT NULL,
  `sessionid` varchar(30) NOT NULL,
  `idmedia` int(10) unsigned NOT NULL,
  UNIQUE KEY `ux_viewhistory` (`viewdate`,`sessionid`,`idmedia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "viewhistory"
#

