# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import hr_attendance
import hr_timesheet_sheet
import res_company
import project_config_settings