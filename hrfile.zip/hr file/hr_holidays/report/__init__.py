# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import holidays_summary_report
import hr_holidays_leaves_report
