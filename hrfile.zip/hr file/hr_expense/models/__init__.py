# -*- coding: utf-8 -*-

import account_move_line
import hr_department
import hr_expense
import product_template
import res_config
import web_planner
