# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import account_analytic_line
import hr_department
import hr_employee
import hr_timesheet_sheet
import hr_timesheet_sheet_config_settings
import res_company
