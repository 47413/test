# -*- coding: utf-8 -*-

import hr_job
import hr_applicant
