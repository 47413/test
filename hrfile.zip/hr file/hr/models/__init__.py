# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import hr
import mail_alias
import mail_thread
import res_partner
import res_users
