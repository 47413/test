# -*- coding: utf-8 -*-

import hr_attendance
import hr_employee
import res_config
